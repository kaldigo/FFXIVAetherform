using System.Collections.Generic;
using System.Linq;
using Proteus.Services;
using Xunit;

namespace Proteus.Tests;

/// <summary>The pure decisions of a hair port: which races, from where, into which of the author's options.</summary>
public class HairPortPlanTests
{
    private static readonly string Miqote = HairPortPlan.HairPath(801, 130);
    private static readonly string Midlander = HairPortPlan.HairPath(201, 130);

    [Fact]
    public void Parses_only_hair_model_paths()
    {
        Assert.Equal(((ushort)801, 130), HairPortPlan.Parse(Miqote));
        Assert.Equal(((ushort)801, 130), HairPortPlan.Parse(Miqote.Replace('/', '\\')));
        Assert.Null(HairPortPlan.Parse("chara/human/c0801/obj/face/f0001/model/c0801f0001_fac.mdl"));
        Assert.Null(HairPortPlan.Parse("chara/human/c0801/obj/hair/h0130/model/c0201h0130_hir.mdl"));
    }

    [Theory]
    [Trait("Plan", "AC-hair-race-port-5")]
    [InlineData((ushort)101)] [InlineData((ushort)201)] [InlineData((ushort)301)] [InlineData((ushort)401)]
    [InlineData((ushort)501)] [InlineData((ushort)601)] [InlineData((ushort)701)] [InlineData((ushort)801)]
    [InlineData((ushort)901)] [InlineData((ushort)1001)] [InlineData((ushort)1101)] [InlineData((ushort)1201)]
    [InlineData((ushort)1301)] [InlineData((ushort)1401)] [InlineData((ushort)1501)] [InlineData((ushort)1601)]
    [InlineData((ushort)1701)] [InlineData((ushort)1801)]
    public void Only_same_gender_races_are_targets(ushort race)
    {
        var targets = HairPortPlan.SameGenderRaces(race).ToList();
        Assert.Equal(8, targets.Count);
        Assert.DoesNotContain(race, targets);
        Assert.All(targets, t => Assert.Equal(race / 100 % 2, t / 100 % 2));
    }

    [Fact]
    [Trait("Plan", "AC-cross-sex-hair-port-1")]
    public void Other_sex_races_are_every_playable_race_of_the_other_sex()
    {
        Assert.Equal([101, 301, 501, 701, 901, 1101, 1301, 1501, 1701], HairPortPlan.OtherSexRaces(201).Select(r => (int)r).ToArray());
        Assert.Equal([201, 401, 601, 801, 1001, 1201, 1401, 1601, 1801], HairPortPlan.OtherSexRaces(101).Select(r => (int)r).ToArray());
        Assert.Empty(HairPortPlan.OtherSexRaces(9101));
        Assert.Empty(HairPortPlan.OtherSexRaces(0));
    }

    [Fact]
    [Trait("Plan", "EDGE-hair-race-port-2")]
    public void Nearest_race_by_fall_through_then_index()
    {
        // A Highlander woman falls through to Midlander in one step, a Miqo'te woman is two away.
        Assert.Equal([(ushort)201, 801], HairPortPlan.OrderSources(401, [801, 201]).ToArray());
        // Two equally near: the lower number first.
        Assert.Equal([(ushort)801, 1401], HairPortPlan.OrderSources(201, [1401, 801]).ToArray());
    }

    [Fact]
    [Trait("Plan", "EDGE-hair-race-port-3")]
    public void Other_gender_coverage_is_not_a_source()
        => Assert.Empty(HairPortPlan.OrderSources(201, [101, 701, 1501]));

    [Fact]
    [Trait("Plan", "AC-hair-race-port-5")]
    public void Only_the_same_hair_id_is_a_source()
    {
        var owners = new List<HairPortPlan.Owner>
        {
            new("", "", "", new Dictionary<string, string> { [HairPortPlan.HairPath(801, 131)] = "a.mdl", [Miqote] = "b.mdl" }),
        };
        Assert.Equal([(ushort)801], HairPortPlan.AuthoredRaces(owners, 130));
        Assert.Equal([(ushort)801], HairPortPlan.AuthoredRaces(owners, 131));
        Assert.Empty(HairPortPlan.AuthoredRaces(owners, 132));
    }

    private static HairPortPlan.Owner O(string group, string option, string type, params (string Path, string File)[] files)
        => new(group, option, type, files.ToDictionary(f => f.Path, f => f.File));

    [Theory]
    [Trait("Plan", "EDGE-hair-race-port-10")]
    [InlineData("default", false)]
    [InlineData("same", false)]
    [InlineData("otherGroup", false)]
    [InlineData("multiSibling", false)]
    [InlineData("singleSibling", true)]
    [InlineData("ourPortElsewhere", true)]
    [InlineData("none", true)]
    public void CanPortInto_blocks_whatever_is_on_together(string where, bool expected)
    {
        bool multi = where == "multiSibling";
        var into = O("Style", "Long", multi ? "Multi" : "Single", (Miqote, "long.mdl"));
        var owners = new List<HairPortPlan.Owner> { O("", "", ""), into };
        switch (where)
        {
            case "default": owners[0] = O("", "", "", (Midlander, "mid.mdl")); break;
            case "same": owners[1] = into = O("Style", "Long", "Single", (Miqote, "long.mdl"), (Midlander, "mid.mdl")); break;
            case "otherGroup": owners.Add(O("Other", "On", "Single", (Midlander, "mid.mdl"))); break;
            case "multiSibling": owners.Add(O("Style", "Short", "Multi", (Midlander, "mid.mdl"))); break;
            case "singleSibling": owners.Add(O("Style", "Short", "Single", (Midlander, "mid.mdl"))); break;
            case "ourPortElsewhere": owners.Add(O("Style", "Short", "Single", (Midlander, "Hair Ports/x/mid.mdl"))); break;
        }
        Assert.Equal(expected, HairPortPlan.CanPortInto(owners, into, Midlander));
    }

    /// <summary>
    /// Studio opened on a port of ours (LM Orlina's c1601h0102, Startide's c0201h0008 on the user's install): porting it
    /// again refused every race as "the mod does not publish that hairstyle". It stands for the author's hairstyle.
    /// </summary>
    [Fact]
    public void A_port_opened_stands_for_the_hairstyle_it_was_made_from()
    {
        var owners = new List<HairPortPlan.Owner>
        {
            O("", "", "", (Miqote, "default group/miqo.mdl"), (Midlander, "Hair Ports/Default/" + Midlander)),
        };
        var record = new HairPortRecord();
        record.Ports.Add(new HairPortRecord.Entry { SourceGamePath = Miqote, TargetGamePath = Midlander });

        Assert.Equal(Miqote, HairPortPlan.AuthorSource(owners, record, Midlander));
        Assert.Equal(Miqote, HairPortPlan.AuthorSource(owners, record, Midlander.Replace('/', '\\').ToUpperInvariant()));
        // The author's own hairstyle, and a path no port of ours made, are themselves.
        Assert.Equal(Miqote, HairPortPlan.AuthorSource(owners, record, Miqote));
        Assert.Equal(Midlander, HairPortPlan.AuthorSource(owners, new HairPortRecord(), Midlander));
        // Two ports of one target, from the author's race in two options: the file opened says which.
        const string Elezen = "chara/human/c0601/obj/hair/h0130/model/c0601h0130_hir.mdl";
        var two = new HairPortRecord();
        two.Ports.Add(new HairPortRecord.Entry { SourceGamePath = Miqote, TargetGamePath = Midlander, File = "Hair Ports/A/m.mdl" });
        two.Ports.Add(new HairPortRecord.Entry { SourceGamePath = Elezen, TargetGamePath = Midlander, File = "Hair Ports/B/m.mdl" });
        Assert.Equal(Elezen, HairPortPlan.AuthorSource(owners, two, Midlander, "Hair Ports\\B\\m.mdl"));
        Assert.Equal(Miqote, HairPortPlan.AuthorSource(owners, two, Midlander, "Hair Ports/A/m.mdl"));
        Assert.Equal(Miqote, HairPortPlan.AuthorSource(owners, two, Midlander));

        // The author publishing the path from a file of their own wins over a port recorded for it.
        owners.Add(O("Style", "Own", "Single", (Midlander, "mid.mdl")));
        Assert.Equal(Midlander, HairPortPlan.AuthorSource(owners, record, Midlander));
    }

    [Fact]
    [Trait("Plan", "AC-hair-race-port-8")]
    public void Changed_source_or_newer_version_is_stale()
    {
        byte[] source = [1, 2, 3];
        var entry = new HairPortRecord.Entry { SourceSha8 = HairPortPlan.Sha8(source), PortVersion = HairPortBaker.Version };
        Assert.False(HairPortPlan.IsStale(entry, source));
        Assert.True(HairPortPlan.IsStale(entry, [1, 2, 4]));
        entry.PortVersion = HairPortBaker.Version - 1;
        Assert.True(HairPortPlan.IsStale(entry, source));
    }

    [Fact]
    public void Port_files_live_under_the_folder_per_option()
    {
        var a = HairPortPlan.PortFile(O("Style", "Long", "Single"), Midlander);
        var b = HairPortPlan.PortFile(O("Style", "Short", "Single"), Midlander);
        Assert.NotEqual(a, b);
        Assert.True(HairPortPlan.IsPortFile(a));
        Assert.True(HairPortPlan.IsPortFile(a.Replace('/', '\\')));
        Assert.Equal($"Hair Ports/Default/{Midlander}", HairPortPlan.PortFile(O("", "", ""), Midlander));
        Assert.False(HairPortPlan.IsPortFile("hair/c0201h0130_hir.mdl"));
    }

    [Fact]
    public void Port_folders_of_options_whose_names_read_alike_never_collide()
    {
        var a = HairPortPlan.PortFile(O("A - B", "C", "Single"), Midlander);
        var b = HairPortPlan.PortFile(O("A", "B - C", "Single"), Midlander);
        var c = HairPortPlan.PortFile(O("A", "B:C", "Single"), Midlander);
        var d = HairPortPlan.PortFile(O("A", "B?C", "Single"), Midlander);
        Assert.Equal(4, new[] { a, b, c, d }.Distinct().Count());
        Assert.StartsWith("Hair Ports/A - B - C ", a);
        // The same option however its case is written: one folder, as Windows compares folder names.
        Assert.Equal(a, HairPortPlan.PortFile(O("a - b", "c", "Single"), Midlander), System.StringComparer.OrdinalIgnoreCase);
    }

    [Fact]
    public void Every_playable_race_has_head_candidates_starting_with_f0001()
    {
        Assert.Equal("chara/human/c1601/obj/face/f0001/model/c1601f0001_fac.mdl", HairPortPlan.HeadPaths(1601).First());
        Assert.Contains("chara/human/c1601/obj/face/f0101/model/c1601f0101_fac.mdl", HairPortPlan.HeadPaths(1601));
    }

    [Fact]
    public void Skeleton_bones_are_read_as_the_strings_the_file_carries()
    {
        var bytes = System.Text.Encoding.ASCII.GetBytes("xx\0j_ex_h0170_ke_b\0yy j_ex_h0170_ke_c\x01j_kao\0");
        Assert.Equal(["j_ex_h0170_ke_b", "j_ex_h0170_ke_c"], HairPortPlan.SkeletonBones(bytes).Order());
        Assert.Empty(HairPortPlan.SkeletonBones(null));
    }

    /// <summary>Newer skeletons ("blks0031") put each name's length, doubled, before it — a printable byte, as the game's
    /// skl_c0201h0221 does — instead of ending it with a NUL: the names are read apart, not as one.</summary>
    [Fact]
    [Trait("Plan", "AC-hair-skeleton-infer-2")]
    public void Skeleton_bones_of_the_newer_layout_are_read_by_their_lengths()
    {
        var bytes = System.Text.Encoding.ASCII.GetBytes(
            "blks0031\x0aj_kao\"j_ex_h0177_ke_f_a\"j_ex_h0177_ke_f_b&j_ex_h0220_back_b_l$j_ex_h0220_front_c\x01\x02");
        Assert.Equal(["j_ex_h0177_ke_f_a", "j_ex_h0177_ke_f_b", "j_ex_h0220_back_b_l", "j_ex_h0220_front_c"],
                     HairPortPlan.SkeletonBones(bytes).Order());
    }

    [Fact]
    public void A_hair_est_is_read_however_it_is_spelled_and_never_for_a_race_that_cannot_exist()
    {
        var lower = System.Text.Json.JsonSerializer.Deserialize<System.Text.Json.JsonElement>(
            "{\"Type\":\"est\",\"Manipulation\":{\"Gender\":\"female\",\"Race\":\"miqote\",\"SetId\":130,\"Slot\":\"hair\",\"Entry\":170}}");
        Assert.Equal(170, HairPortPlan.HairEstEntry(lower, 801, 130));
        Assert.Null(HairPortPlan.HairEstEntry(lower, 801, 131));
        Assert.Null(HairPortPlan.HairEstEntry(lower, 9104, 130));
        Assert.Null(HairPortPlan.HairEstEntry(lower, 0, 130));
    }
}
