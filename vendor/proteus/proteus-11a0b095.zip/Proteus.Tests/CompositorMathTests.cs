using System;
using System.Collections.Generic;
using System.Linq;
using Proteus.Services;
using Xunit;

namespace Proteus.Tests;

/// <summary>
/// Tests for the pure math / pixel-operation static methods on CompositorService.
/// These methods are internal so access is granted via InternalsVisibleTo("Proteus.Tests").
/// No Dalamud, Penumbra, or game data is needed; all inputs are raw byte arrays.
/// </summary>
public class CompositorMathTests
{
    // ── ParseHex ─────────────────────────────────────────────────────────────

    [Theory]
    [InlineData("#FF0000", 1.000f, 0.000f, 0.000f)]
    [InlineData("#00FF00", 0.000f, 1.000f, 0.000f)]
    [InlineData("#0000FF", 0.000f, 0.000f, 1.000f)]
    [InlineData("#000000", 0.000f, 0.000f, 0.000f)]
    [InlineData("#FFFFFF", 1.000f, 1.000f, 1.000f)]
    [InlineData("#ff0000", 1.000f, 0.000f, 0.000f)] // lowercase
    [InlineData("FF0000",  1.000f, 0.000f, 0.000f)] // no leading #
    [InlineData("#F00",    1.000f, 0.000f, 0.000f)] // 3-digit shorthand
    [InlineData("F00",     1.000f, 0.000f, 0.000f)] // 3-digit without #
    [InlineData("#080808", 0.031f, 0.031f, 0.031f)] // near-black
    public void ParseHex_VariousFormats_ReturnsCorrectFloats(
        string hex, float expectedR, float expectedG, float expectedB)
    {
        var (r, g, b) = OverlayBlend.ParseHex(hex);
        Assert.Equal(expectedR, r, precision: 3);
        Assert.Equal(expectedG, g, precision: 3);
        Assert.Equal(expectedB, b, precision: 3);
    }

    [Fact]
    public void ParseHex_MixedHex_CorrectComponents()
    {
        // #AABBCC → R=0xAA/255, G=0xBB/255, B=0xCC/255
        var (r, g, b) = OverlayBlend.ParseHex("#AABBCC");
        Assert.Equal(0xAA / 255f, r, precision: 4);
        Assert.Equal(0xBB / 255f, g, precision: 4);
        Assert.Equal(0xCC / 255f, b, precision: 4);
    }

    // ── ApplyFlatOverlay ──────────────────────────────────────────────────────

    [Fact]
    public void ApplyFlatOverlay_FullyOpaqueWhiteOverlay_ReplacesBase()
    {
        var baseTex = RGBA(255, 0, 0, 255);         // red
        var overlay  = RGBA(0,   0, 255, 255);       // blue, full alpha
        var row      = Row(1f, 1f, 1f);              // white tint (no tint)

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, row, 1, 1);

        Assert.Equal(0,   baseTex[0]); // R → 0
        Assert.Equal(0,   baseTex[1]); // G → 0
        Assert.Equal(255, baseTex[2]); // B → 255
    }

    [Fact]
    public void ApplyFlatOverlay_ZeroAlphaOverlay_LeavesBaseUnchanged()
    {
        var baseTex = RGBA(100, 150, 200, 255);
        var overlay  = RGBA(255, 255, 255, 0);       // fully transparent
        var original = (byte[])baseTex.Clone();

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f), 1, 1);

        Assert.Equal(original, baseTex);
    }

    [Fact]
    public void ApplyFlatOverlay_HalfAlpha_BlendsCorrectly()
    {
        // base=200, overlay=0, alpha=128 → 0*(128/255) + 200*(1-128/255) ≈ 100
        var baseTex = RGBA(200, 0, 0, 255);
        var overlay  = RGBA(0, 200, 0, 128);         // green at 50% alpha

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f), 1, 1);

        Assert.InRange(baseTex[0], 94, 106);  // ≈100 (red fades)
        Assert.InRange(baseTex[1], 94, 106);  // ≈100 (green appears)
    }

    [Fact]
    public void ApplyFlatOverlay_RedTint_ZeroesGreenAndBlue()
    {
        var baseTex = RGBA(0, 0, 0, 255);
        var overlay  = RGBA(255, 255, 255, 255);     // white, full alpha
        var row      = Row(1f, 0f, 0f);              // red tint only

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, row, 1, 1);

        Assert.Equal(255, baseTex[0]); // R = full (white * red tint)
        Assert.Equal(0,   baseTex[1]); // G = 0
        Assert.Equal(0,   baseTex[2]); // B = 0
    }

    [Fact]
    public void ApplyFlatOverlay_MultiplePixels_ProcessesAll()
    {
        // 2×1 image: two pixels
        var baseTex = new byte[] { 255, 0, 0, 255,  0, 255, 0, 255 }; // red | green
        var overlay  = new byte[] { 0,   0, 0, 255,  0, 0,   0, 0   }; // black opaque | transparent
        var row      = Row(1f, 1f, 1f);

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, row, 2, 1);

        // First pixel: fully replaced by black overlay
        Assert.Equal(0, baseTex[0]);
        Assert.Equal(0, baseTex[1]);
        Assert.Equal(0, baseTex[2]);
        // Second pixel: unchanged (transparent overlay)
        Assert.Equal(0,   baseTex[4]);
        Assert.Equal(255, baseTex[5]);
        Assert.Equal(0,   baseTex[6]);
    }

    // ── Blend modes: a print colours the fabric ───────────────────────────────
    // The clip ("painted") is what this mod's own layers already put on the material. Every mode but
    // Paint is multiplied through it, which is what makes a print colour a fishnet's threads and leave
    // its holes as skin.

    /// <summary>A print with nothing beneath it is invisible — the rule the whole feature rests on.</summary>
    [Fact]
    public void ApplyFlatOverlay_PrintWithNothingPaintedBeneath_LeavesBaseUnchanged()
    {
        var baseTex  = RGBA(100, 150, 200, 255);
        var overlay  = RGBA(255, 0, 0, 255);          // fully opaque red print
        var original = (byte[])baseTex.Clone();

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Multiply),
                                           1, 1, painted: null);

        Assert.Equal(original, baseTex);
    }

    /// <summary>A print onto everything beneath needs no clip: on bare skin, Multiply drops white out and keeps
    /// black, like a Photoshop Multiply layer.</summary>
    [Fact]
    public void ApplyFlatOverlay_BeneathMultiply_PrintsOnBareSkin()
    {
        byte[] baseTex = [200, 150, 100, 255,  200, 150, 100, 255];
        byte[] overlay = [255, 255, 255, 255,  0, 0, 0, 255];   // white, then black

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Multiply, beneath: true),
                                           2, 1, painted: null);

        Assert.Equal(new byte[] { 200, 150, 100, 255, 0, 0, 0, 255 }, baseTex);
    }

    /// <summary>Beneath is weighted by the art's own alpha, so a half-transparent black darkens by half.</summary>
    [Fact]
    public void ApplyFlatOverlay_BeneathMultiply_WeightedByArtAlpha()
    {
        var baseTex = RGBA(200, 200, 200, 255);
        var overlay = RGBA(0, 0, 0, 128);

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Multiply, beneath: true),
                                           1, 1, painted: [0]);   // the clip is ignored

        Assert.InRange(baseTex[0], 98, 101);   // 200 × (1 − 128/255) ≈ 99.6
    }

    /// <summary>An indexed sub-row onto everything beneath prints without a clip; its OwnPaint sibling still does not.</summary>
    [Fact]
    public void ApplyIndexedOverlay_BeneathSubRow_IgnoresClip_OwnPaintSubRowKeepsIt()
    {
        var rows = new Dictionary<int, ColorTableRowOverride>
        {
            [0] = new() { A = Row(1f, 1f, 1f, blend: RowBlend.Multiply, beneath: true),
                          B = Row(1f, 1f, 1f, blend: RowBlend.Multiply) },
        };
        byte[] baseTex = [200, 200, 200, 255,  200, 200, 200, 255];
        byte[] overlay = [0, 0, 0, 255,  0, 0, 0, 255];
        byte[] idx     = [0, 255, 0, 255,  0, 0, 0, 255];   // pixel 0 → sub-row A, pixel 1 → sub-row B

        OverlayBlend.ApplyIndexedOverlay(baseTex, overlay, idx, rows, false, 2, 1, painted: [0, 0]);

        Assert.Equal(0,   baseTex[0]);   // A: printed onto bare skin
        Assert.Equal(200, baseTex[4]);   // B: nothing painted, so nothing printed
    }

    [Fact]
    public void BuildRowDict_PrintOnto_MissingMeansOwnPaint()
    {
        var dict = OverlayBlend.BuildRowDict(
        [
            new() { Row = 1, SubRowA = new() { Blend = RowBlend.Multiply },
                             SubRowB = new() { Blend = RowBlend.Multiply, PrintOnto = PrintTarget.Beneath } },
        ]);

        Assert.False(dict[0].A.OntoBeneath);
        Assert.True(dict[0].B.OntoBeneath);
    }

    [Fact]
    public void ApplyFlatOverlay_WhiteMultiply_IsIdentity()
    {
        var baseTex  = RGBA(200, 120, 40, 255);
        var overlay  = RGBA(255, 255, 255, 255);      // white multiplies to nothing
        var original = (byte[])baseTex.Clone();

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Multiply),
                                           1, 1, painted: [255]);

        Assert.Equal(original, baseTex);
    }

    [Fact]
    public void ApplyFlatOverlay_Multiply_DarkensBase()
    {
        // 200/255 × 128/255 ≈ 0.394 → ≈100
        var baseTex = RGBA(200, 200, 200, 255);
        var overlay = RGBA(128, 128, 128, 255);

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Multiply),
                                           1, 1, painted: [255]);

        Assert.InRange(baseTex[0], 95, 105);
    }

    [Fact]
    public void ApplyFlatOverlay_Screen_LightensBase()
    {
        // 1 − (1 − 100/255)(1 − 128/255) ≈ 0.697 → ≈178
        var baseTex = RGBA(100, 100, 100, 255);
        var overlay = RGBA(128, 128, 128, 255);

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Screen),
                                           1, 1, painted: [255]);

        Assert.InRange(baseTex[0], 173, 183);
    }

    /// <summary>The neutral element of Screen, and the reason a dark print needs Multiply instead.</summary>
    [Fact]
    public void ApplyFlatOverlay_BlackScreen_IsIdentity()
    {
        var baseTex  = RGBA(200, 120, 40, 255);
        var overlay  = RGBA(0, 0, 0, 255);
        var original = (byte[])baseTex.Clone();

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Screen),
                                           1, 1, painted: [255]);

        Assert.Equal(original, baseTex);
    }

    [Fact]
    public void ApplyFlatOverlay_Add_SaturatesAtWhite()
    {
        var baseTex = RGBA(200, 200, 200, 255);
        var overlay = RGBA(200, 200, 200, 255);       // 0.784 + 0.784 clamps to 1

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Add),
                                           1, 1, painted: [255]);

        Assert.Equal(255, baseTex[0]);
    }

    [Fact]
    public void ApplyFlatOverlay_Replace_TakesTheOverlayColour()
    {
        var baseTex = RGBA(200, 200, 200, 255);
        var overlay = RGBA(50, 60, 70, 255);

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Replace),
                                           1, 1, painted: [255]);

        Assert.InRange(baseTex[0], 48, 52);
        Assert.InRange(baseTex[1], 58, 62);
        Assert.InRange(baseTex[2], 68, 72);
    }

    /// <summary>
    /// Half-painted lands between the base and the full result — the clip is the PRODUCT of the print's
    /// alpha and the fabric's coverage, not the smaller of them. That is what fades a print out along a
    /// fishnet's antialiased thread edges instead of stopping it at a hard line.
    /// </summary>
    [Fact]
    public void ApplyFlatOverlay_HalfPainted_LandsBetweenBaseAndResult()
    {
        var baseTex = RGBA(200, 200, 200, 255);
        var overlay = RGBA(0, 0, 0, 255);             // multiplying by black → 0 at full strength

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Multiply),
                                           1, 1, painted: [128]);

        Assert.InRange(baseTex[0], 95, 105);          // ≈100, halfway from 200 to 0
    }

    [Fact]
    public void ApplyFlatOverlay_PrintRowColour_MultipliesIntoSource()
    {
        var baseTex = RGBA(255, 255, 255, 255);
        var overlay = RGBA(255, 255, 255, 255);

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 0f, 0f, blend: RowBlend.Multiply),
                                           1, 1, painted: [255]);

        Assert.Equal(255, baseTex[0]);
        Assert.Equal(0,   baseTex[1]);
        Assert.Equal(0,   baseTex[2]);
    }

    [Fact]
    public void ApplyFlatOverlay_ZeroPrintAlpha_LeavesBaseUnchanged()
    {
        var baseTex  = RGBA(100, 150, 200, 255);
        var overlay  = RGBA(0, 0, 0, 0);
        var original = (byte[])baseTex.Clone();

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Multiply),
                                           1, 1, painted: [255]);

        Assert.Equal(original, baseTex);
    }

    [Fact]
    public void ApplyFlatOverlay_Print_DoesNotModifyDstAlpha()
    {
        var baseTex = RGBA(200, 200, 200, 77);
        var overlay = RGBA(0, 0, 0, 255);

        OverlayBlend.ApplyFlatOverlay(baseTex, overlay, Row(1f, 1f, 1f, blend: RowBlend.Multiply),
                                           1, 1, painted: [255]);

        Assert.Equal(77, baseTex[3]);
    }

    /// <summary>
    /// A Paint row ignores the clip entirely. This is what guarantees that adding blend modes changed
    /// nothing for every mod authored before they existed.
    /// </summary>
    [Fact]
    public void ApplyIndexedOverlay_AllRowsPaint_IgnoresTheClip()
    {
        var rows = new Dictionary<int, ColorTableRowOverride>
        {
            [15] = new() { A = Row(1f, 0.5f, 0.25f), B = Row(0.2f, 0.4f, 0.6f) },
        };
        var idx = RGBA(255, 128, 0, 255);            // pair 15, halfway between A and B

        var withoutClip = RGBA(200, 100, 50, 255);
        var withClip    = RGBA(200, 100, 50, 255);
        var overlay     = RGBA(180, 180, 180, 200);

        OverlayBlend.ApplyIndexedOverlay(withoutClip, overlay, idx, rows, false, 1, 1, null);
        OverlayBlend.ApplyIndexedOverlay(withClip,    overlay, idx, rows, false, 1, 1, [0]);

        Assert.Equal(withoutClip, withClip);
    }

    /// <summary>
    /// The reported case. A uniform (255,255) index resolves to pair 15 sub-row A — identically the row
    /// the flat path uses — so the two must agree byte for byte.
    /// </summary>
    [Fact]
    public void ApplyIndexedOverlay_UniformIndex_MatchesFlat()
    {
        var row16A = Row(1f, 0.5f, 0.25f, blend: RowBlend.Multiply);
        var rows   = new Dictionary<int, ColorTableRowOverride>
        {
            [15] = new() { A = row16A, B = row16A },
        };
        var idx = RGBA(255, 255, 0, 255);

        var viaIndexed = RGBA(200, 160, 120, 255);
        var viaFlat    = RGBA(200, 160, 120, 255);
        var overlay    = RGBA(128, 200, 64, 255);

        OverlayBlend.ApplyIndexedOverlay(viaIndexed, overlay, idx, rows, false, 1, 1, [255]);
        OverlayBlend.ApplyFlatOverlay(viaFlat, overlay, row16A, 1, 1, [255]);

        Assert.Equal(viaFlat, viaIndexed);
    }

    /// <summary>
    /// A blend mode cannot be interpolated, so each sub-row is resolved on its own and the RESULTS are
    /// lerped. Half-way between a printing sub-row and a painting one must therefore land strictly between
    /// the two — a hard seam at green 128 is exactly what picking the nearer sub-row would produce.
    /// </summary>
    [Fact]
    public void ApplyIndexedOverlay_SubRowsWithDifferentModes_LerpTheResults()
    {
        var rows = new Dictionary<int, ColorTableRowOverride>
        {
            [15] = new()
            {
                // Black art. A multiplies it through a weak clip, so it only darkens a little; B paints it
                // outright, so it goes to black. Two very different answers for the same texel.
                A = Row(1f, 1f, 1f, blend: RowBlend.Multiply),
                B = Row(1f, 1f, 1f),
            },
        };
        var overlay = RGBA(0, 0, 0, 255);

        var pureA = RGBA(200, 200, 200, 255);
        var pureB = RGBA(200, 200, 200, 255);
        var mixed = RGBA(200, 200, 200, 255);

        OverlayBlend.ApplyIndexedOverlay(pureA, overlay, RGBA(255, 255, 0, 255), rows, false, 1, 1, [64]);
        OverlayBlend.ApplyIndexedOverlay(pureB, overlay, RGBA(255, 0,   0, 255), rows, false, 1, 1, [64]);
        OverlayBlend.ApplyIndexedOverlay(mixed, overlay, RGBA(255, 128, 0, 255), rows, false, 1, 1, [64]);

        // A prints weakly (clip 64/255) and B paints outright, so the two differ; halfway must sit between.
        Assert.True(pureA[0] > pureB[0], "a weak print should darken less than an opaque paint");
        Assert.InRange(mixed[0], pureB[0], pureA[0]);
    }

    // ── Paint coverage ────────────────────────────────────────────────────────

    [Fact]
    public void PaintCoverage_NoPrintRows_ReturnsTheInputUntouched()
    {
        var cov  = RGBA(10, 20, 30, 200);
        var rows = new Dictionary<int, ColorTableRowOverride> { [15] = new() { A = Row(1f, 1f, 1f) } };

        var got = OverlayBlend.PaintCoverage(cov, null, rows, 1, 1);

        Assert.Same(cov, got);   // no allocation on the ordinary path
    }

    [Fact]
    public void PaintCoverage_FlatPrint_IsAllZero()
    {
        var cov  = RGBA(10, 20, 30, 255);
        var rows = new Dictionary<int, ColorTableRowOverride>
        {
            [15] = new() { A = Row(1f, 1f, 1f, blend: RowBlend.Multiply) },
        };

        var got = OverlayBlend.PaintCoverage(cov, null, rows, 1, 1);

        Assert.Equal(0, got[3]);
    }

    /// <summary>
    /// The claim scoping that lets one mod ship a whole-body diffuse group and a whole-body normal group: an
    /// overlay can only take a channel away from the overlays beneath it if it puts art in that channel. Before
    /// this, whichever of the two groups sat on top erased the other, since both cover the entire body.
    /// </summary>
    [Theory]
    // diffuse, normal, mask declared      →  claims diffuse, normal, mask
    [InlineData(true,  false, false,           true,  false, false)]
    [InlineData(false, true,  false,           false, true,  false)]
    [InlineData(false, false, true,            false, false, true)]
    [InlineData(true,  true,  true,            true,  true,  true)]
    [InlineData(false, false, false,           false, false, false)]
    public void Supplies_ScopesAClaimToTheChannelsTheOverlayActuallyDeclares(
        bool diffuse, bool normal, bool mask, bool claimsD, bool claimsN, bool claimsM)
    {
        var d = new OverlayDescriptor
        {
            Diffuse = diffuse ? "d.png" : null,
            Normal  = normal  ? "n.png" : null,
            Mask    = mask    ? "m.png" : null,
        };

        Assert.Equal(claimsD, OverlayBlend.Supplies(d, OverlayChannel.Diffuse));
        Assert.Equal(claimsN, OverlayBlend.Supplies(d, OverlayChannel.Normal));
        Assert.Equal(claimsM, OverlayBlend.Supplies(d, OverlayChannel.Mask));
    }

    /// <summary>
    /// The silhouette channel follows the order CoverageOf picks a source in, so a decision that feeds every
    /// channel at once (the UV-seam drop) is gated by the same art the coverage was built from.
    /// </summary>
    [Fact]
    public void PrimaryChannel_FollowsCoverageOfsOrderAndIsNullWithNoArt()
    {
        Assert.Equal(OverlayChannel.Diffuse, OverlayBlend.PrimaryChannel(
            new OverlayDescriptor { Diffuse = "d.png", Normal = "n.png", Mask = "m.png" }));
        Assert.Equal(OverlayChannel.Normal, OverlayBlend.PrimaryChannel(
            new OverlayDescriptor { Normal = "n.png", Mask = "m.png" }));
        Assert.Equal(OverlayChannel.Mask, OverlayBlend.PrimaryChannel(
            new OverlayDescriptor { Mask = "m.png" }));
        Assert.Null(OverlayBlend.PrimaryChannel(new OverlayDescriptor()));
    }

    /// <summary>A normal sheet at the flat value, with the texels in <paramref name="bumps"/> set to R=G=128+dev.</summary>
    private static byte[] FlatNormal(int w, int h, params (int X, int Y, int Dev)[] bumps)
    {
        var n = new byte[w * h * 4];
        for (int i = 0; i < n.Length; i += 4) { n[i] = 128; n[i + 1] = 128; n[i + 2] = 255; n[i + 3] = 255; }
        foreach (var (x, y, dev) in bumps)
        {
            int o = (y * w + x) * 4;
            n[o] = n[o + 1] = (byte)(128 + dev / 2);
        }
        return n;
    }

    /// <summary>
    /// A normal exported the usual way is flat and opaque over the whole sheet. As a Compound layer it adds no
    /// relief there, so it must claim none: before this, its blue channel (255) made it hide every normal beneath.
    /// </summary>
    [Fact]
    public void ReliefPresence_IsZeroOnAFlatSheet()
    {
        var p = OverlayBlend.ReliefPresence(FlatNormal(512, 512), 512, 512);
        Assert.All(p, v => Assert.Equal(0, v));
    }

    [Fact]
    public void ReliefPresence_IgnoresSlopesInsideTheDeadzone()
    {
        var p = OverlayBlend.ReliefPresence(
            FlatNormal(512, 512, (100, 100, OverlayBlend.MaskReliefDeadzone - 2)), 512, 512);
        Assert.All(p, v => Assert.Equal(0, v));
    }

    /// <summary>
    /// A bump claims its own texel fully and its pooling cell with it, so a pattern's small flats (scale tops,
    /// the gaps in lace) stay its own; far away, where the sheet is flat, nothing is claimed.
    /// </summary>
    [Fact]
    public void ReliefPresence_ClaimsTheBumpAndItsCellButNotTheFlatFarAway()
    {
        const int W = 1024;   // 4-texel cells at 256 per side
        var p = OverlayBlend.ReliefPresence(FlatNormal(W, W, (9, 9, 40)), W, W);

        Assert.Equal(255, p[9 * W + 9]);
        Assert.True(p[10 * W + 10] >= 128, $"same-cell neighbour got {p[10 * W + 10]}");
        Assert.Equal(0, p[500 * W + 500]);
    }

    [Fact]
    public void ScaleAlphaByPlane_ScalesAlphaOnlyAndLeavesTheInputAlone()
    {
        var rgba  = new byte[] { 10, 20, 30, 200,   40, 50, 60, 200 };
        var plane = new byte[] { 255, 0 };

        var got = OverlayBlend.ScaleAlphaByPlane(rgba, plane);

        Assert.Equal(new byte[] { 10, 20, 30, 200,   40, 50, 60, 0 }, got);
        Assert.Equal(200, rgba[7]);
    }

    /// <summary>
    /// An index cell nobody configured resolves to a default row, and a default row paints — so one
    /// unconfigured cell is enough to keep the overlay a surface. The safe direction.
    /// </summary>
    [Fact]
    public void AllRowsPrint_UnconfiguredIndexCell_IsNotAPrint()
    {
        var rows = new Dictionary<int, ColorTableRowOverride>
        {
            [3] = new() { A = Row(1f, 1f, 1f, blend: RowBlend.Multiply),
                          B = Row(1f, 1f, 1f, blend: RowBlend.Multiply) },
        };

        Assert.False(OverlayBlend.AllRowsPrint(rows, hasIndex: true));
    }

    [Fact]
    public void AllRowsPrint_FlatOverlayWithAPrintingRow16_IsAPrint()
    {
        var rows = new Dictionary<int, ColorTableRowOverride>
        {
            [15] = new() { A = Row(1f, 1f, 1f, blend: RowBlend.Screen) },
        };

        Assert.True(OverlayBlend.AllRowsPrint(rows, hasIndex: false));
    }

    /// <summary>
    /// An indexed overlay whose `_id` failed to load cannot be routed, so guessing from row 16 would be a
    /// claim about texels the index was supposed to place. Falling back to all-paint makes a broken index
    /// degrade to "the print does not print" rather than to a print that bleaches skin tone.
    /// </summary>
    [Fact]
    public void PaintCoverage_IndexDeclaredButMissing_FallsBackToAllPaint()
    {
        var cov  = RGBA(10, 20, 30, 255);
        var rows = new Dictionary<int, ColorTableRowOverride>
        {
            [15] = new() { A = Row(1f, 1f, 1f, blend: RowBlend.Multiply) },
        };

        var got = OverlayBlend.PaintCoverage(cov, null, rows, 1, 1, hasIndex: true);

        Assert.Same(cov, got);
    }

    /// <summary>The same call without a declared index is a genuinely flat overlay, and row 16 does decide.</summary>
    [Fact]
    public void PaintCoverage_NoIndexDeclared_StillUsesRow16()
    {
        var cov  = RGBA(10, 20, 30, 255);
        var rows = new Dictionary<int, ColorTableRowOverride>
        {
            [15] = new() { A = Row(1f, 1f, 1f, blend: RowBlend.Multiply) },
        };

        var got = OverlayBlend.PaintCoverage(cov, null, rows, 1, 1, hasIndex: false);

        Assert.Equal(0, got[3]);
    }

    /// <summary>The loop reads idx[i + 1], so a buffer that is not a whole number of texels must not
    /// let the last iteration run off the end.</summary>
    [Fact]
    public void PaintCoverage_RaggedIndexBuffer_DoesNotOverrun()
    {
        var cov  = new byte[8];                       // two texels
        var idx  = new byte[5];                       // one texel and a stray byte
        var rows = new Dictionary<int, ColorTableRowOverride>
        {
            [0] = new() { A = Row(1f, 1f, 1f, blend: RowBlend.Multiply) },
        };

        var ex = Record.Exception(() => OverlayBlend.PaintCoverage(cov, idx, rows, 2, 1));

        Assert.Null(ex);
    }

    [Fact]
    public void AnyCoverage_AllZeroAlpha_IsFalse()
        => Assert.False(OverlayBlend.AnyCoverage(new byte[] { 9, 9, 9, 0, 9, 9, 9, 0 }));

    [Fact]
    public void AnyCoverage_OneCoveredTexel_IsTrue()
        => Assert.True(OverlayBlend.AnyCoverage(new byte[] { 0, 0, 0, 0, 0, 0, 0, 1 }));

    [Fact]
    public void AnyCoverage_Null_IsFalse()
        => Assert.False(OverlayBlend.AnyCoverage(null));

    /// <summary>
    /// Giving one row a blend mode must not move any OTHER row's output. The print path rounds where the
    /// original truncates, so without a per-pair fast path a per-row edit would shift the whole table.
    /// </summary>
    [Fact]
    public void ApplyIndexedOverlay_PaintPairInAPrintingTable_MatchesThePlainPath()
    {
        ColorTableRowOverride PaintPair() => new()
        {
            A = Row(1f, 0.53f, 0.27f),
            B = Row(0.31f, 0.62f, 0.11f),
        };

        // Identical tables but for pair 3, which prints in one and paints in the other. Pair 15 — the one
        // the index actually selects — is the same in both.
        var printing = new Dictionary<int, ColorTableRowOverride>
        {
            [15] = PaintPair(),
            [3]  = new() { A = Row(1f, 1f, 1f, blend: RowBlend.Multiply),
                           B = Row(1f, 1f, 1f, blend: RowBlend.Multiply) },
        };
        var plain = new Dictionary<int, ColorTableRowOverride>
        {
            [15] = PaintPair(),
            [3]  = new() { A = Row(1f, 1f, 1f), B = Row(1f, 1f, 1f) },
        };

        var idx = RGBA(255, 137, 0, 255);            // pair 15, partway between A and B

        var viaPrinting = RGBA(203, 101, 47, 255);
        var viaPlain    = RGBA(203, 101, 47, 255);
        var overlay     = RGBA(181, 77, 233, 199);

        OverlayBlend.ApplyIndexedOverlay(viaPrinting, overlay, idx, printing, false, 1, 1, [255]);
        OverlayBlend.ApplyIndexedOverlay(viaPlain,    overlay, idx, plain,    false, 1, 1, [255]);

        Assert.Equal(viaPlain, viaPrinting);
    }

    [Fact]
    public void UnionAlphaInto_MatchesTheNaiveLoop()
    {
        var rng  = new Random(20260905);
        var acc  = new byte[257];
        var rgba = new byte[257 * 4];
        rng.NextBytes(acc);
        rng.NextBytes(rgba);

        var expected = (byte[])acc.Clone();
        for (int i = 0; i < expected.Length; i++)
            expected[i] = (byte)(expected[i] + (255 - expected[i]) * rgba[i * 4 + 3] / 255);

        OverlayBlend.UnionAlphaInto(acc, rgba);

        Assert.Equal(expected, acc);
    }

    // ── AlphaComposite ────────────────────────────────────────────────────────

    [Fact]
    public void AlphaComposite_FullyOpaqueSrc_ReplacesDst()
    {
        var dst = RGBA(255, 0, 0, 255);  // red
        var src = RGBA(0,   0, 255, 255); // blue, full alpha

        OverlayBlend.AlphaComposite(dst, src, 1, 1);

        Assert.Equal(0,   dst[0]);
        Assert.Equal(0,   dst[1]);
        Assert.Equal(255, dst[2]);
    }

    [Fact]
    public void AlphaComposite_ZeroAlphaSrc_LeavesDstUnchanged()
    {
        var dst      = RGBA(100, 150, 200, 255);
        var original = (byte[])dst.Clone();

        OverlayBlend.AlphaComposite(dst, RGBA(255, 0, 0, 0), 1, 1);

        Assert.Equal(original, dst);
    }

    [Fact]
    public void AlphaComposite_HalfAlpha_BlendsEvenly()
    {
        var dst = RGBA(200, 200, 200, 255);
        var src = RGBA(0,   0,   0,   128); // black at 50%

        OverlayBlend.AlphaComposite(dst, src, 1, 1);

        // ≈ 0*(128/255) + 200*(1-128/255) ≈ 100
        Assert.InRange(dst[0], 94, 106);
        Assert.InRange(dst[1], 94, 106);
        Assert.InRange(dst[2], 94, 106);
    }

    [Fact]
    public void AlphaComposite_WithMask_MaskAlphaZeroBlocksComposite()
    {
        var dst  = RGBA(0, 0, 0, 255);
        var src  = RGBA(255, 255, 255, 255); // fully opaque white
        var mask = RGBA(0, 0, 0, 0);         // mask blocks everything

        OverlayBlend.AlphaComposite(dst, src, 1, 1, mask);

        // dst should be unchanged (mask blocked the composite)
        Assert.Equal(0, dst[0]);
        Assert.Equal(0, dst[1]);
        Assert.Equal(0, dst[2]);
    }

    [Fact]
    public void AlphaComposite_WithMask_MaskTakesMinAlpha()
    {
        var dst  = RGBA(0,   0,   0,   255);
        var src  = RGBA(255, 255, 255, 255); // full alpha
        var mask = RGBA(0,   0,   0,   128); // half alpha — limits effective alpha

        OverlayBlend.AlphaComposite(dst, src, 1, 1, mask);

        // effective alpha = min(1, 0.5) = 0.5 → ≈128 for white on black
        Assert.InRange(dst[0], 120, 136);
    }

    [Fact]
    public void AlphaComposite_DstAlphaNotModified()
    {
        var dst = RGBA(0, 0, 0, 255);
        OverlayBlend.AlphaComposite(dst, RGBA(255, 255, 255, 128), 1, 1);
        Assert.Equal(255, dst[3]); // dst alpha is never touched
    }

    // ── CompoundNormal ────────────────────────────────────────────────────────

    [Fact]
    public void CompoundNormal_AddsXYDetail()
    {
        // Base: tilted right (X > 128), flat Y — decoded X ≈ +0.25
        byte[] dst = [160, 128, 200, 0];
        // Overlay: same tilt, fully opaque
        byte[] src = [160, 128, 180, 255];

        OverlayBlend.CompoundNormal(dst, src, 1, 1);

        // XY compounds: result X must exceed either input alone
        Assert.True(dst[0] > 160);
        // Blue and alpha untouched
        Assert.Equal(200, dst[2]);
        Assert.Equal(0,   dst[3]);
    }

    [Fact]
    public void CompoundNormal_FlatOverlay_LeavesBaseXYUnchanged()
    {
        // Flat overlay (128,128) = zero deviation — adding zero changes nothing
        byte[] dst = [180, 90, 200, 0];
        OverlayBlend.CompoundNormal(dst, [128, 128, 255, 255], 1, 1);
        Assert.Equal(180, dst[0]);
        Assert.Equal(90,  dst[1]);
    }

    [Fact]
    public void CompoundNormal_ZeroAlpha_LeavesBaseUnchanged()
    {
        byte[] dst      = [160, 128, 200, 0];
        byte[] original = (byte[])dst.Clone();
        OverlayBlend.CompoundNormal(dst, [255, 0, 180, 0], 1, 1);
        Assert.Equal(original, dst);
    }

    /// <summary>
    /// The whole-skin defect, pinned at the arithmetic. A converted skin mod's normal is composited over a
    /// base that is already that same map — either the mod's own textures or the body mod it was derived
    /// from — so compounding applies every slope twice. Measured in game on one such mod: mean deviation
    /// from flat went 5.95 → 11.83 (R) and 4.73 → 9.39 (G), which is what this reproduces at one texel.
    /// <see cref="NormalMode.Replace"/> is the way out, and it composites through AlphaComposite.
    /// </summary>
    [Fact]
    public void CompoundNormal_OverItself_DoublesTheDeviationFromFlat()
    {
        // A texel tilted +32 in X and −20 in Y away from flat (128,128).
        byte[] skin = [160, 108, 250, 255];

        byte[] compounded = (byte[])skin.Clone();
        OverlayBlend.CompoundNormal(compounded, skin, 1, 1);
        Assert.Equal(192, compounded[0]);   // 128 + 32 + 32
        Assert.Equal(88,  compounded[1]);   // 128 − 20 − 20

        // Replace mode hands back the map the author painted, exactly.
        byte[] replaced = [200, 60, 180, 255];
        OverlayBlend.AlphaComposite(replaced, skin, 1, 1);
        Assert.Equal(skin[0], replaced[0]);
        Assert.Equal(skin[1], replaced[1]);
        // And the BLUE channel comes across too — skin.shpk reads it as skin-colour influence, and
        // CompoundNormal never writes it, so a whole-skin normal's blue was silently inherited from
        // whatever body mod happened to sit underneath.
        Assert.Equal(skin[2], replaced[2]);
    }

    [Fact]
    public void CompoundNormal_WithMask_MaskZeroBlocksComposite()
    {
        byte[] dst  = [160, 128, 200, 0];
        byte[] src  = [200, 200, 180, 255];
        byte[] mask = [0,   0,   0,   0];
        byte[] orig = (byte[])dst.Clone();
        OverlayBlend.CompoundNormal(dst, src, 1, 1, mask);
        Assert.Equal(orig, dst);
    }

    // ── BuildRowDict ──────────────────────────────────────────────────────────

    [Fact]
    public void BuildRowDict_Null_ReturnsEmptyDict()
    {
        Assert.Empty(OverlayBlend.BuildRowDict(null));
    }

    [Fact]
    public void BuildRowDict_EmptyList_ReturnsEmptyDict()
    {
        Assert.Empty(OverlayBlend.BuildRowDict([]));
    }

    [Fact]
    public void BuildRowDict_Row1_MapsToIndex0()
    {
        var presets = Presets(row: 1, diffuseA: "#FF0000");
        var dict    = OverlayBlend.BuildRowDict(presets);

        Assert.True(dict.ContainsKey(0));  // 1-based → 0-based
        Assert.Equal(1f, dict[0].A.DiffuseR, precision: 3);
        Assert.Equal(0f, dict[0].A.DiffuseG, precision: 3);
        Assert.Equal(0f, dict[0].A.DiffuseB, precision: 3);
    }

    [Fact]
    public void BuildRowDict_Row16_MapsToIndex15()
    {
        var presets = Presets(row: 16, diffuseA: "#0000FF");
        var dict    = OverlayBlend.BuildRowDict(presets);

        Assert.True(dict.ContainsKey(15));
        Assert.Equal(1f, dict[15].A.DiffuseB, precision: 3);
    }

    [Fact]
    public void BuildRowDict_MissingDiffuse_DefaultsToWhite()
    {
        var presets = new List<ColorTableRowPreset>
        {
            new() { Row = 1, SubRowA = new() { Diffuse = null, Emissive = 0.5f } }
        };
        var dict = OverlayBlend.BuildRowDict(presets);

        Assert.Equal(1f, dict[0].A.DiffuseR, precision: 3);
        Assert.Equal(1f, dict[0].A.DiffuseG, precision: 3);
        Assert.Equal(1f, dict[0].A.DiffuseB, precision: 3);
        Assert.Equal(0.5f, dict[0].A.Emissive, precision: 5);
    }

    [Fact]
    public void BuildRowDict_SubRowBSeparateFromA()
    {
        var presets = new List<ColorTableRowPreset>
        {
            new()
            {
                Row    = 1,
                SubRowA = new() { Diffuse = "#FF0000", Emissive = 0.5f, Opacity = 10 },
                SubRowB = new() { Diffuse = "#0000FF", Emissive = 0.2f, Opacity = -5 }
            }
        };
        var dict = OverlayBlend.BuildRowDict(presets);
        var row  = dict[0];

        Assert.Equal(1f,   row.A.DiffuseR, precision: 3);
        Assert.Equal(0.5f, row.A.Emissive,  precision: 5);
        Assert.Equal(10,   row.A.Opacity);
        Assert.Equal(1f,   row.B.DiffuseB, precision: 3);
        Assert.Equal(0.2f, row.B.Emissive,  precision: 5);
        Assert.Equal(-5,   row.B.Opacity);
    }

    [Fact]
    public void BuildRowDict_MultipleRows()
    {
        var presets = new List<ColorTableRowPreset>
        {
            new() { Row = 1,  SubRowA = new() { Diffuse = "#FF0000" } },
            new() { Row = 16, SubRowA = new() { Diffuse = "#0000FF" } }
        };
        var dict = OverlayBlend.BuildRowDict(presets);

        Assert.Equal(2, dict.Count);
        Assert.True(dict.ContainsKey(0));
        Assert.True(dict.ContainsKey(15));
    }

    // ── ScaleOverlayAlpha ─────────────────────────────────────────────────────

    [Fact]
    public void ScaleOverlayAlpha_ZeroOpacity_ReturnsSameAlphas()
    {
        var src    = new byte[] { 255, 255, 255, 128, 255, 255, 255, 200 };
        var result = OverlayBlend.ScaleOverlayAlpha(src, 0);
        Assert.Equal(128, result[3]);
        Assert.Equal(200, result[7]);
    }

    [Fact]
    public void ScaleOverlayAlpha_PositiveOpacity_IncreasesAlpha()
    {
        // alpha=128, opacity=+50: newA = 128 + (255-128)*50/100 = 128+63 = 191
        var result = OverlayBlend.ScaleOverlayAlpha(RGBA(255, 255, 255, 128), 50);
        Assert.Equal(191, result[3]);
    }

    [Fact]
    public void ScaleOverlayAlpha_NegativeOpacity_DecreasesAlpha()
    {
        // alpha=200, opacity=-50: newA = 200 * 50/100 = 100
        var result = OverlayBlend.ScaleOverlayAlpha(RGBA(255, 255, 255, 200), -50);
        Assert.Equal(100, result[3]);
    }

    [Fact]
    public void ScaleOverlayAlpha_PositiveOpacity_ZeroAlphaPixelStaysZero()
    {
        // fully-transparent pixel stays transparent even with positive opacity
        var result = OverlayBlend.ScaleOverlayAlpha(RGBA(255, 255, 255, 0), 100);
        Assert.Equal(0, result[3]);
    }

    [Fact]
    public void ScaleOverlayAlpha_NegativeOpacity_ZeroAlphaStaysZero()
    {
        var result = OverlayBlend.ScaleOverlayAlpha(RGBA(255, 255, 255, 0), -50);
        Assert.Equal(0, result[3]);
    }

    [Fact]
    public void ScaleOverlayAlpha_FullPositive_ClampsAt255()
    {
        // alpha=200, opacity=+100: newA = 200 + (255-200)*100/100 = 200+55 = 255
        var result = OverlayBlend.ScaleOverlayAlpha(RGBA(255, 255, 255, 200), 100);
        Assert.Equal(255, result[3]);
    }

    [Fact]
    public void ScaleOverlayAlpha_DoesNotMutateSrc()
    {
        var src = RGBA(255, 255, 255, 128);
        OverlayBlend.ScaleOverlayAlpha(src, 50);
        Assert.Equal(128, src[3]);
    }

    // ── ApplyCoverageMask (cov' = cov*W + T, gated by base alpha > 0) ──────────
    // A mask SETS the overlay's opacity explicitly within its alpha region (additive): it can force
    // opacity over a SHEER area, not only reduce it. W = original-coverage survival (Π(1-aᵢ)); T =
    // accumulated gray·a target. cov' = cov*W + T (clamped to 255) — but ONLY where the base overlay
    // already has coverage (alpha > 0). Where base alpha = 0 the pixel stays 0, so a mask can never
    // paint onto bare skin. Mask alpha black → W=255, T=0 → cov' = cov (no effect); alpha white →
    // W=0, cov' = gray target (gated by base > 0).

    [Fact]
    public void ApplyCoverageMask_NullMap_ReturnsSameReference()
    {
        var cov = RGBA(255, 255, 255, 200);
        Assert.Same(cov, OverlayBlend.ApplyCoverageMask(cov, null, null));
    }

    [Fact]
    public void ApplyCoverageMask_BaseTransparent_StaysTransparent_EvenUnderWhite()
    {
        // THE GATE: base coverage 0 (bare skin above the stocking, or a fishnet hole) stays 0 even
        // when the mask is fully applied white (W=0, T=255). A mask can boost a sheer area to opaque
        // but can NEVER create coverage where the overlay is absent.
        var cov    = RGBA(255, 255, 255, 0);
        var result = OverlayBlend.ApplyCoverageMask(cov, new byte[] { 0 }, new byte[] { 255 });
        Assert.Equal(0, result[3]);
    }

    [Fact]
    public void ApplyCoverageMask_BaseSheer_WhiteForcesOpaque()
    {
        // Additive over a SHEER base: alpha=40 (visible but sheer), mask white (W=0, T=255) → forced
        // to 255. This is what paints the opaque bands at the bottom of a sheer stocking.
        var cov    = RGBA(255, 255, 255, 40);
        var result = OverlayBlend.ApplyCoverageMask(cov, new byte[] { 0 }, new byte[] { 255 });
        Assert.Equal(255, result[3]);
    }

    [Fact]
    public void ApplyCoverageMask_AlphaBlack_LeavesCoverageUnchanged()
    {
        // alpha=0 → W=255, T=0 → keep=255 → cov' = cov (mask does nothing)
        var cov    = RGBA(255, 255, 255, 200);
        var result = OverlayBlend.ApplyCoverageMask(cov, new byte[] { 255 }, new byte[] { 0 });
        Assert.Equal(200, result[3]);
    }

    [Fact]
    public void ApplyCoverageMask_AlphaWhiteGrayBlack_RemovesCoverage()
    {
        // alpha=255, gray=0 → W=0, T=0 → keep=0 → cov' = 0 (rip / hole)
        var cov    = RGBA(255, 255, 255, 200);
        var result = OverlayBlend.ApplyCoverageMask(cov, new byte[] { 0 }, new byte[] { 0 });
        Assert.Equal(0, result[3]);
    }

    [Fact]
    public void ApplyCoverageMask_AlphaWhiteGrayWhite_ForcesOpaque()
    {
        // alpha=255, gray=255 → W=0, T=255 → cov' = 255 (forced opaque, above the sheer base of 40)
        var cov    = RGBA(255, 255, 255, 40);
        var result = OverlayBlend.ApplyCoverageMask(cov, new byte[] { 0 }, new byte[] { 255 });
        Assert.Equal(255, result[3]);
    }

    [Fact]
    public void ApplyCoverageMask_AlphaWhiteGrayMid_SetsToTarget()
    {
        // alpha=255, gray=128 → W=0, T=128 → cov' = 128 (set to the gray target, regardless of base)
        var cov    = RGBA(255, 255, 255, 200);
        var result = OverlayBlend.ApplyCoverageMask(cov, new byte[] { 0 }, new byte[] { 128 });
        Assert.Equal(128, result[3]);
    }

    [Fact]
    public void ApplyCoverageMask_AlphaHalfGrayBlack_HalfwayRemoval()
    {
        // a=128 → W=127, T=0 → keep=127 → cov' = 200*127/255 ≈ 99
        var cov    = RGBA(255, 255, 255, 200);
        var result = OverlayBlend.ApplyCoverageMask(cov, new byte[] { 127 }, new byte[] { 0 });
        Assert.Equal(200 * 127 / 255, result[3]);
    }

    [Fact]
    public void ApplyCoverageMask_OnlyTouchesAlpha_NotColor()
    {
        var cov    = RGBA(10, 20, 30, 200);
        var result = OverlayBlend.ApplyCoverageMask(cov, new byte[] { 0 }, new byte[] { 0 });
        Assert.Equal(10, result[0]);
        Assert.Equal(20, result[1]);
        Assert.Equal(30, result[2]);
    }

    [Fact]
    public void ApplyCoverageMask_DoesNotMutateSource()
    {
        var cov = RGBA(255, 255, 255, 200);
        OverlayBlend.ApplyCoverageMask(cov, new byte[] { 0 }, new byte[] { 0 });
        Assert.Equal(200, cov[3]); // original untouched (clone returned)
    }

    [Fact]
    public void ApplyCoverageMask_MultiplePixels_AppliesPerPixel()
    {
        // pixel 0: alpha black (keep=255) → unchanged; pixel 1: alpha white gray black (keep=0) → 0
        var cov    = new byte[] { 255, 0, 0, 255,  0, 255, 0, 255 };
        var result = OverlayBlend.ApplyCoverageMask(cov, new byte[] { 255, 0 }, new byte[] { 0, 0 });
        Assert.Equal(255, result[3]);
        Assert.Equal(0,   result[7]);
    }

    // ── ApplyIndexedOpacity ───────────────────────────────────────────────────

    [Fact]
    public void ApplyIndexedOpacity_PositiveOpacity_IncreasesAlpha()
    {
        var src  = RGBA(255, 255, 255, 128);
        var idx  = RGBA(0,   255, 0,   255); // R=0→pair0, G=255→100% A row
        var rows = RowDict(pairIdx: 0, opA: 50, opB: 0);

        var result = OverlayBlend.ApplyIndexedOpacity(src, idx, rows);

        float a    = 128f / 255f;
        float newA = a + (1f - a) * 50f / 100f;
        Assert.Equal((byte)(newA * 255f + 0.5f), result[3]);
    }

    [Fact]
    public void ApplyIndexedOpacity_NegativeOpacity_DecreasesAlpha()
    {
        var src  = RGBA(255, 255, 255, 200);
        var idx  = RGBA(0,   255, 0,   255);
        var rows = RowDict(pairIdx: 0, opA: -50, opB: 0);

        var result = OverlayBlend.ApplyIndexedOpacity(src, idx, rows);

        float a    = 200f / 255f;
        float newA = a * (100f - 50f) / 100f;
        Assert.Equal((byte)(newA * 255f + 0.5f), result[3]);
    }

    [Fact]
    public void ApplyIndexedOpacity_ZeroAlphaPixel_Skipped()
    {
        var src  = RGBA(255, 255, 255, 0);    // transparent
        var idx  = RGBA(0,   255, 0,   255);
        var rows = RowDict(pairIdx: 0, opA: 50, opB: 0);

        var result = OverlayBlend.ApplyIndexedOpacity(src, idx, rows);
        Assert.Equal(0, result[3]);
    }

    [Fact]
    public void ApplyIndexedOpacity_UnmappedPair_Unchanged()
    {
        // idx.R = 85 → pairIdx = 85/17 = 5, but no row 5 in dict
        var src  = RGBA(255, 255, 255, 200);
        var idx  = RGBA(85,  255, 0,   255);
        var rows = RowDict(pairIdx: 0, opA: 100, opB: 0); // only pair 0 exists

        var result = OverlayBlend.ApplyIndexedOpacity(src, idx, rows);
        Assert.Equal(200, result[3]); // unchanged
    }

    [Fact]
    public void ApplyIndexedOpacity_BlendsBetweenAandB()
    {
        // G=0 → blendA=0 → use B row opacity
        var src  = RGBA(255, 255, 255, 200);
        var idx  = RGBA(0,   0,   0,   255); // R=0→pair0, G=0→100% B
        var rows = new Dictionary<int, ColorTableRowOverride>
        {
            [0] = new() { A = new() { Opacity = 100 }, B = new() { Opacity = -50 } }
        };

        var result = OverlayBlend.ApplyIndexedOpacity(src, idx, rows);

        // blendA = 0 → op = B.Opacity = -50 → newA = (200/255)*(50/100)
        float a    = 200f / 255f;
        float newA = a * 50f / 100f;
        Assert.Equal((byte)(newA * 255f + 0.5f), result[3]);
    }

    [Fact]
    public void ApplyIndexedOpacity_DoesNotMutateSrc()
    {
        var src  = RGBA(255, 255, 255, 200);
        var orig = (byte[])src.Clone();
        OverlayBlend.ApplyIndexedOpacity(src, RGBA(0, 255, 0, 255), RowDict(0, 50, 0));
        Assert.Equal(orig, src);
    }

    // ── ApplyIndexedOverlay ───────────────────────────────────────────────────

    [Fact]
    public void ApplyIndexedOverlay_Diffuse_TintsWithRowAColor()
    {
        // R=0 → pair0; G=255 → blendA=1 → full A row; row A is pure red
        var baseTex = RGBA(0,   0, 0, 255);
        var ov      = RGBA(255, 255, 255, 255);  // white overlay, full alpha
        var idx     = RGBA(0,   255, 0,  255);   // pair0, 100% A
        var rows    = new Dictionary<int, ColorTableRowOverride>
        {
            [0] = new()
            {
                A = new() { DiffuseR = 1f, DiffuseG = 0f, DiffuseB = 0f }, // red
                B = new() { DiffuseR = 0f, DiffuseG = 1f, DiffuseB = 0f }  // green
            }
        };

        OverlayBlend.ApplyIndexedOverlay(baseTex, ov, idx, rows, isNormal: false, 1, 1);

        Assert.Equal(255, baseTex[0]); // R = full (red row A)
        Assert.Equal(0,   baseTex[1]); // G = 0
        Assert.Equal(0,   baseTex[2]); // B = 0
    }

    [Fact]
    public void ApplyIndexedOverlay_Diffuse_BlendsAandB()
    {
        // G=128 → blendA ≈ 0.502 → lerp between B(green) and A(red)
        var baseTex = RGBA(0,   0, 0, 255);
        var ov      = RGBA(255, 255, 255, 255);
        var idx     = RGBA(0,   128, 0, 255);   // pair0, ~50% blend
        var rows    = new Dictionary<int, ColorTableRowOverride>
        {
            [0] = new()
            {
                A = new() { DiffuseR = 1f, DiffuseG = 0f, DiffuseB = 0f }, // red
                B = new() { DiffuseR = 0f, DiffuseG = 0f, DiffuseB = 1f }  // blue
            }
        };

        OverlayBlend.ApplyIndexedOverlay(baseTex, ov, idx, rows, isNormal: false, 1, 1);

        // blendA ≈ 0.5 → R ≈ 0.5, B ≈ 0.5 → ~127 each
        Assert.InRange(baseTex[0], 120, 135);
        Assert.InRange(baseTex[2], 120, 135);
    }

    [Fact]
    public void ApplyIndexedOverlay_MissingRow_UsesDefaultWhite()
    {
        // idx.R = 17 → pairIdx = 1, but only pair 0 exists → defaults to white
        var baseTex = RGBA(0,   0, 0, 255);
        var ov      = RGBA(255, 255, 255, 255);
        var idx     = RGBA(17,  255, 0,  255);  // pair1, not in dict
        var rows    = new Dictionary<int, ColorTableRowOverride>
        {
            [0] = new() { A = new() { DiffuseR = 1f, DiffuseG = 0f, DiffuseB = 0f } }
        };

        OverlayBlend.ApplyIndexedOverlay(baseTex, ov, idx, rows, isNormal: false, 1, 1);

        // Default ColorTableRowOverride has white (1,1,1) sub-rows
        Assert.Equal(255, baseTex[0]);
        Assert.Equal(255, baseTex[1]);
        Assert.Equal(255, baseTex[2]);
    }

    [Fact]
    public void ApplyIndexedOverlay_ZeroAlphaPixel_Skipped()
    {
        var baseTex  = RGBA(100, 100, 100, 255);
        var original = (byte[])baseTex.Clone();
        var ov       = RGBA(255, 255, 255, 0);   // transparent
        var idx      = RGBA(0,   255, 0,   255);
        var rows     = new Dictionary<int, ColorTableRowOverride>
        {
            [0] = new() { A = new() { DiffuseR = 0f, DiffuseG = 0f, DiffuseB = 0f } }
        };

        OverlayBlend.ApplyIndexedOverlay(baseTex, ov, idx, rows, isNormal: false, 1, 1);

        Assert.Equal(original, baseTex);
    }

    // ── SanitizeName ─────────────────────────────────────────────────────────

    [Fact]
    public void SanitizeName_ExtractsFilenameWithoutExtension()
    {
        var result = CompositorService.SanitizeName("chara/human/c0101/mt_c0101b0001_b.mtrl");
        Assert.Equal("mt_c0101b0001_b", result);
    }

    [Fact]
    public void SanitizeName_InvalidPathChars_ReplacedWithUnderscore()
    {
        // Simulate a game path that contains characters disallowed in Windows file names.
        // We use a game path that contains a colon-like character (not common but let's use < >).
        var result = CompositorService.SanitizeName("chara/test<body>mat.mtrl");
        Assert.DoesNotContain("<", result);
        Assert.DoesNotContain(">", result);
    }

    // ── BodyCodeFromCustomize ─────────────────────────────────────────────────

    [Theory]
    [InlineData(1, 1, 0, "c0101")]  // Hyur Midlander male
    [InlineData(1, 1, 1, "c0201")]  // Hyur Midlander female
    [InlineData(1, 2, 0, "c0301")]  // Hyur Highlander male
    [InlineData(1, 2, 1, "c0401")]  // Hyur Highlander female
    [InlineData(2, 1, 0, "c0101")]  // Elezen male → shares mid body
    [InlineData(2, 1, 1, "c0201")]  // Elezen female
    [InlineData(3, 1, 0, "c1101")]  // Lalafell male → own body
    [InlineData(3, 1, 1, "c1101")]  // Lalafell female → the male's body (no c1201 body)
    [InlineData(4, 1, 0, "c0101")]  // Miqo'te male
    [InlineData(4, 1, 1, "c0201")]  // Miqo'te female
    [InlineData(5, 1, 0, "c0101")]  // Roegadyn male
    [InlineData(5, 1, 1, "c0201")]  // Roegadyn female
    [InlineData(6, 1, 0, "c1301")]  // Au Ra male
    [InlineData(6, 1, 1, "c1401")]  // Au Ra female
    [InlineData(7, 1, 0, "c1501")]  // Hrothgar male
    [InlineData(7, 1, 1, "c1601")]  // Hrothgar female
    [InlineData(8, 1, 0, "c1701")]  // Viera male
    [InlineData(8, 1, 1, "c1801")]  // Viera female
    public void BodyCodeFromCustomize_KnownRaces_ReturnCorrectCode(
        byte race, byte tribe, byte sex, string expected)
    {
        var result = CompositorService.BodyCodeFromCustomize(race, tribe, sex);
        Assert.Equal(expected, result);
    }

    [Fact]
    public void BodyCodeFromCustomize_UnknownRace_ReturnsNull()
    {
        Assert.Null(CompositorService.BodyCodeFromCustomize(99, 1, 0));
        Assert.Null(CompositorService.BodyCodeFromCustomize(0,  1, 0));
        Assert.Null(CompositorService.BodyCodeFromCustomize(9,  1, 0));
    }

    // ── FaceCodeFromCustomize ─────────────────────────────────────────────────
    //
    // The head is NOT the body. Four races wear the Midlander body under a face of their own, and a face
    // material measured against the body's code is thrown away as another race's — which is how a face pack
    // for the very character wearing it came out inert.

    [Theory]
    [InlineData(1, 1, 0, "c0101")]  // Hyur Midlander male
    [InlineData(1, 1, 1, "c0201")]  // Hyur Midlander female
    [InlineData(1, 2, 0, "c0301")]  // Hyur Highlander male
    [InlineData(1, 2, 1, "c0401")]  // Hyur Highlander female
    [InlineData(2, 1, 0, "c0501")]  // Elezen male
    [InlineData(2, 1, 1, "c0601")]  // Elezen female
    [InlineData(3, 1, 0, "c1101")]  // Lalafell male
    [InlineData(3, 1, 1, "c1201")]  // Lalafell female
    [InlineData(4, 1, 0, "c0701")]  // Miqo'te male
    [InlineData(4, 1, 1, "c0801")]  // Miqo'te female — the reported case: c0801 face over a c0201 body
    [InlineData(5, 1, 0, "c0901")]  // Roegadyn male
    [InlineData(5, 1, 1, "c1001")]  // Roegadyn female
    [InlineData(6, 1, 1, "c1401")]  // Au Ra female — races with their own body agree with BodyCode
    [InlineData(7, 1, 1, "c1601")]  // Hrothgar female
    [InlineData(8, 1, 1, "c1801")]  // Viera female
    public void FaceCodeFromCustomize_KnownRaces_ReturnTheirOwnCode(
        byte race, byte tribe, byte sex, string expected)
        => Assert.Equal(expected, CompositorService.FaceCodeFromCustomize(race, tribe, sex));

    [Fact]
    public void FaceCodeFromCustomize_SharedBodyRaces_DoNotShareAHead()
    {
        // The pairs the bug lived in: same body code, four different faces.
        Assert.Equal("c0201", CompositorService.BodyCodeFromCustomize(4, 1, 1));
        Assert.Equal("c0801", CompositorService.FaceCodeFromCustomize(4, 1, 1));
        Assert.Equal("c0201", CompositorService.BodyCodeFromCustomize(2, 1, 1));
        Assert.Equal("c0601", CompositorService.FaceCodeFromCustomize(2, 1, 1));
    }

    [Fact]
    public void FaceCodeFromCustomize_UnknownRace_ReturnsNull()
    {
        Assert.Null(CompositorService.FaceCodeFromCustomize(99, 1, 0));
        Assert.Null(CompositorService.FaceCodeFromCustomize(0,  1, 0));
        Assert.Null(CompositorService.FaceCodeFromCustomize(9,  1, 0));
    }

    // ── HeadCodeSet ───────────────────────────────────────────────────────────

    [Fact]
    public void HeadCodeSet_IsTheHeadsCodeAloneAndNotTheBodysUnderIt()
    {
        // A Miqo'te woman's draw object, as the snapshot reports it: a c0201 body under a c0801 head. The
        // body's code must NOT leak in, or a Midlander face pack would match her through the body she wears.
        var materials = new[]
        {
            "chara/human/c0201/obj/body/b0001/material/v0001/mt_c0201b0001_a.mtrl",
            "chara/human/c0201/obj/body/b0001/material/v0001/mt_c0201b0001_bibo.mtrl",
            "chara/human/c0801/obj/face/f0102/material/mt_c0801f0102_fac_a.mtrl",
            "chara/equipment/e6255/material/v0001/mt_c0201e6255_top_a.mtrl",   // no human code: skipped
        };

        Assert.Equal(["c0801"], CompositorService.HeadCodeSet(materials, null).OrderBy(c => c));
    }

    [Fact]
    public void HeadCodeSet_ReadsTheHeadOffTheModelWalkWhenTheMaterialIsMissing()
    {
        // The case the fix turns on: the materials snapshot has not caught up with the face, but the model
        // walk names it. Without the models, the face material would be measured against the body's code.
        var materials = new[] { "chara/human/c0201/obj/body/b0001/material/v0001/mt_c0201b0001_a.mtrl" };
        var models    = new[] { "chara/human/c0801/obj/face/f0102/model/c0801f0102_fac.mdl",
                                "chara/human/c0801/obj/hair/h0009/model/c0801h0009_hir.mdl" };

        Assert.Equal(["c0801"], CompositorService.HeadCodeSet(materials, models).OrderBy(c => c));
    }

    [Fact]
    public void HeadCodeSet_IsEmptyWhenNothingIsKnown()
        => Assert.Empty(CompositorService.HeadCodeSet(null, null));

    // ── BlurCoverage ──────────────────────────────────────────────────────────

    [Fact]
    public void BlurCoverage_FlatPlane_StaysFlat()
    {
        // A uniform plane must be unchanged by a box blur (edge clamping preserves the constant).
        int w = 64, h = 64;
        var src = new byte[w * h];
        Array.Fill(src, (byte)200);

        var blurred = OverlayBlend.BlurCoverage(src, w, h, radius: 4);

        Assert.All(blurred, v => Assert.Equal(200, v));
    }

    [Fact]
    public void BlurCoverage_SingleWhiteSquare_BleedsIntoSurroundingRing()
    {
        // A small white square on black: after the blur, pixels just outside the square (previously 0)
        // must become non-zero (the coverage bled outward), while a far-away corner stays black.
        int w = 64, h = 64;
        var src = new byte[w * h];
        for (int y = 28; y < 36; y++)
            for (int x = 28; x < 36; x++)
                src[y * w + x] = 255;

        var blurred = OverlayBlend.BlurCoverage(src, w, h, radius: 4);

        Assert.True(blurred[27 * w + 30] > 0, "pixel just outside the square should receive bled coverage");
        Assert.True(blurred[30 * w + 27] > 0, "pixel just left of the square should receive bled coverage");
        Assert.Equal(0, blurred[0]);                  // far corner untouched
        Assert.True(blurred[31 * w + 31] > 0);        // interior still lit
    }

    // ── ApplyAmbientOcclusion ───────────────────────────────────────────────────

    [Fact]
    public void ApplyAmbientOcclusion_DarkensOutsideStrapOnly_AlphaUntouched()
    {
        // 3 pixels: [0] under the strap interior, [1] just outside (blurred spread present),
        // [2] far away (no spread). Only [1] should darken; alpha never changes.
        int w = 3, h = 1;
        var baseD = new byte[]
        {
            200, 200, 200, 255,   // p0: under strap
            200, 200, 200, 255,   // p1: outside, in the halo
            200, 200, 200, 255,   // p2: far away
        };
        var strap   = new byte[] { 255, 0,   0   };  // p0 is the strap; p1/p2 are skin
        var blurred = new byte[] { 255, 200, 0   };  // spread reaches p1 but not p2

        OverlayBlend.ApplyAmbientOcclusion(baseD, strap, blurred, w, h, strength: 0.5f);

        Assert.Equal(200, baseD[0]);   // under strap (s=1 → halo 0): unchanged
        Assert.True(baseD[4] < 200);   // outside, in halo: darkened
        Assert.Equal(200, baseD[8]);   // far away (blur 0): unchanged
        Assert.Equal(255, baseD[3]);   // alpha untouched
        Assert.Equal(255, baseD[7]);
        Assert.Equal(255, baseD[11]);
    }

    [Fact]
    public void ApplyAmbientOcclusion_ZeroStrength_NoChange()
    {
        var baseD   = RGBA(200, 150, 100, 255);
        var strap   = new byte[] { 0 };
        var blurred = new byte[] { 255 };

        OverlayBlend.ApplyAmbientOcclusion(baseD, strap, blurred, 1, 1, strength: 0f);

        Assert.Equal(new byte[] { 200, 150, 100, 255 }, baseD);
    }

    /// <summary>
    /// A contact shadow needs contact. Where a bridged garment has lifted clear of the bust there is
    /// nothing touching the skin, so the AO halo must be suppressed exactly as the indent's is.
    /// <para/>
    /// This pairs with <c>ApplyNormalIndent_LiftedOff_SuppressesTheIndent</c> deliberately: the two passes
    /// describe the SAME contact, and gating only one of them is the bug this was written for — the indent
    /// went quiet while the shadow stayed, leaving pale smudges on the skin under a garment that was no
    /// longer against it.
    /// </summary>
    [Fact]
    public void ApplyAmbientOcclusion_LiftedOff_SuppressesTheHalo()
    {
        int w = 3, h = 1;
        var baseD = new byte[]
        {
            200, 200, 200, 255,
            200, 200, 200, 255,
            200, 200, 200, 255,
        };
        var strap   = new byte[] { 255, 0,   0 };
        var blurred = new byte[] { 255, 200, 0 };
        // p1 is in the halo AND fully lifted; p2 is in neither.
        var lifted  = new byte[] { 0,   255, 0 };

        OverlayBlend.ApplyAmbientOcclusion(baseD, strap, blurred, w, h, strength: 0.5f,
                                                coveredAbove: null, liftedOff: lifted);

        Assert.Equal(200, baseD[4]);   // lifted clear: no contact, so no shadow

        // ...and half-lifted shades half as much, so the suppression is a fade and not a switch — which is
        // what lets the compositor feather it and get a gradient rather than a seam.
        var half = new byte[] { 200, 200, 200, 255, 200, 200, 200, 255, 200, 200, 200, 255 };
        OverlayBlend.ApplyAmbientOcclusion(half, strap, blurred, w, h, strength: 0.5f,
                                                coveredAbove: null, liftedOff: new byte[] { 0, 128, 0 });
        var none = new byte[] { 200, 200, 200, 255, 200, 200, 200, 255, 200, 200, 200, 255 };
        OverlayBlend.ApplyAmbientOcclusion(none, strap, blurred, w, h, strength: 0.5f);
        Assert.True(half[4] > none[4] && half[4] < 200,
            $"half-lifted should shade between none ({none[4]}) and full (200), got {half[4]}");
    }

    /// <summary>
    /// The separable maximum filter, against a brute-force max over the same window.
    /// <para/>
    /// Checked exhaustively rather than by a couple of cases because it is a block-decomposition algorithm
    /// (van Herk): its whole risk is off-by-one indexing at block boundaries, which shows up for some
    /// radii and positions and not others, and produces a mask that is merely a bit wrong rather than
    /// obviously broken.
    /// </summary>
    [Theory]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(5)]
    [InlineData(8)]
    public void MaxFilter_MatchesABruteForceWindow(int radius)
    {
        const int w = 23, h = 17;
        var src = new byte[w * h];
        var rng = new Random(1234 + radius);
        for (int i = 0; i < src.Length; i++) src[i] = (byte)rng.Next(256);

        var got = OverlayBlend.MaxFilter(src, w, h, radius);

        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                byte want = 0;
                for (int dy = -radius; dy <= radius; dy++)
                    for (int dx = -radius; dx <= radius; dx++)
                    {
                        int sx = Math.Clamp(x + dx, 0, w - 1), sy = Math.Clamp(y + dy, 0, h - 1);
                        if (src[sy * w + sx] > want) want = src[sy * w + sx];
                    }
                // The clamped window may reach a little past the true one at the plane's edges, which can
                // only raise the result — so the filter must never come out UNDER the brute-force answer.
                Assert.True(got[y * w + x] >= want,
                    $"r={radius} at ({x},{y}): {got[y * w + x]} < {want}");
            }
    }

    [Fact]
    public void MaxFilter_GrowsARegionByTheRadius()
    {
        // The property the caller actually depends on: a lifted spot suppresses everything within the
        // shadow's own reach of it, so no halo cast by lifted cloth survives.
        const int w = 41, h = 41, r = 6;
        var src = new byte[w * h];
        src[20 * w + 20] = 255;

        var got = OverlayBlend.MaxFilter(src, w, h, r);

        Assert.Equal(255, got[20 * w + 20]);
        Assert.Equal(255, got[20 * w + (20 + r)]);       // exactly at the radius, still covered
        Assert.Equal(255, got[(20 - r) * w + 20]);
        Assert.Equal(0, got[20 * w + (20 + r + 1)]);     // one past it, untouched
        Assert.Equal(0, got[(20 + r + 1) * w + 20]);
    }

    /// <summary>
    /// End to end: a garment whose cloth has lifted must leave NO shadow anywhere, not a ring of it.
    /// <para/>
    /// The failure this pins is specific and was visible in game — the halo immediately beside the cloth
    /// suppressed and its outer part left standing, so the skin showed a band of shadow with clean skin
    /// between it and the garment casting it. It comes from growing the lift mask by less than the halo
    /// actually reaches, which is <see cref="OverlayBlend.BlurCoveragePasses"/> box passes of the
    /// radius, not one.
    /// </summary>
    [Fact]
    public void LiftedCloth_LeavesNoRingOfShadow()
    {
        const int w = 96, h = 1, radius = 6;

        // Cloth on the left half, skin on the right. The whole garment has lifted clear.
        var strap = new byte[w * h];
        for (int x = 0; x < 40; x++) strap[x] = 255;
        var lift = new byte[w * h];
        for (int x = 0; x < 40; x++) lift[x] = 255;

        var blurred = OverlayBlend.BlurCoverage(strap, w, h, radius);
        // Exactly what BustStandoff does: grow past the halo's reach by the feather's own bite, then
        // feather. Growing by less leaves a ring — by 2r it is 12 texels of faint shadow standing off the
        // cloth, which is what this was written against.
        var grown = OverlayBlend.BlurCoverage(
            OverlayBlend.MaxFilter(lift, w, h, radius * (OverlayBlend.BlurCoveragePasses + 1)),
            w, h, radius, iterations: 1);

        var baseD = new byte[w * h * 4];
        for (int p = 0; p < w * h; p++) { baseD[p * 4] = baseD[p * 4 + 1] = baseD[p * 4 + 2] = 200; baseD[p * 4 + 3] = 255; }
        OverlayBlend.ApplyAmbientOcclusion(baseD, strap, blurred, w, h, 1f, null, grown);

        // Nothing anywhere may be shaded: every texel the halo reaches is within the lifted cloth's reach.
        int shaded = 0, worstX = -1, worst = 255;
        for (int p = 0; p < w * h; p++)
            if (baseD[p * 4] < 200) { shaded++; if (baseD[p * 4] < worst) { worst = baseD[p * 4]; worstX = p; } }
        Assert.True(shaded == 0,
            $"{shaded} texels still shaded under fully lifted cloth (darkest {worst} at x={worstX})");

        // ...and the fixture is capable of showing shadow at all, so a pass that shades nothing for an
        // unrelated reason cannot make this test vacuous.
        var control = new byte[w * h * 4];
        for (int p = 0; p < w * h; p++) { control[p * 4] = control[p * 4 + 1] = control[p * 4 + 2] = 200; control[p * 4 + 3] = 255; }
        OverlayBlend.ApplyAmbientOcclusion(control, strap, blurred, w, h, 1f);
        Assert.True(control.Where((_, i) => i % 4 == 0).Any(v => v < 200),
            "the control shades nothing — this fixture proves nothing");
    }

    // ── ApplyNormalIndent ───────────────────────────────────────────────────────

    [Fact]
    public void ApplyNormalIndent_LeansNormalTowardStrap_OnSkinSideOnly()
    {
        // 4×1 row: strap on the left two texels, skin on the right two. The blurred coverage ramps down
        // left→right. On the skin side the surface should lean toward the strap (−X → R below neutral 128);
        // texels under the strap (edge==0) are untouched. Blue (skin-color) and G stay neutral (h=1 → gy=0).
        int w = 4, h = 1;
        var baseN = new byte[]
        {
            128, 128, 255, 128,   // x0 under strap
            128, 128, 255, 128,   // x1 under strap
            128, 128, 255, 128,   // x2 skin
            128, 128, 255, 128,   // x3 skin
        };
        var strap   = new byte[] { 255, 255, 0, 0 };
        var blurred = new byte[] { 255, 192, 64, 0 };

        OverlayBlend.ApplyNormalIndent(baseN, blurred, strap, w, h, strength: 0.5f);

        Assert.Equal(128, baseN[0]);        // x0: under strap, untouched
        Assert.Equal(128, baseN[4]);        // x1: under strap, untouched
        Assert.True(baseN[8]  < 128);       // x2: skin leans −X toward the strap
        Assert.True(baseN[12] < 128);       // x3: skin leans −X toward the strap
        Assert.Equal(255, baseN[10]);       // blue untouched
        Assert.Equal(255, baseN[14]);
        Assert.Equal(128, baseN[9]);        // green untouched (single row → no vertical gradient)
        Assert.Equal(128, baseN[13]);
    }

    /// <summary>
    /// The indent's half of the pair — see <c>ApplyAmbientOcclusion_LiftedOff_SuppressesTheHalo</c>. A
    /// skindent is the mark cloth leaves where it bears on the body; lifted clear of the bust it bears on
    /// nothing, and pressing a groove there draws the seam of a garment that is not touching.
    /// </summary>
    [Fact]
    public void ApplyNormalIndent_LiftedOff_SuppressesTheIndent()
    {
        int w = 4, h = 1;
        byte[] Fresh() => new byte[]
        {
            128, 128, 255, 128,
            128, 128, 255, 128,
            128, 128, 255, 128,
            128, 128, 255, 128,
        };
        var strap   = new byte[] { 255, 255, 0, 0 };
        var blurred = new byte[] { 255, 192, 64, 0 };

        var lifted = Fresh();
        OverlayBlend.ApplyNormalIndent(lifted, blurred, strap, w, h, strength: 0.5f,
            coveredAbove: null, radius: 6, inside: null,
            liftedOff: new byte[] { 0, 0, 255, 255 });
        Assert.Equal(128, lifted[8]);    // x2: lifted clear, so no groove
        Assert.Equal(128, lifted[12]);   // x3: likewise

        // Half-lifted leans half as far — a fade, not a switch, so the map can be feathered.
        var partial = Fresh();
        OverlayBlend.ApplyNormalIndent(partial, blurred, strap, w, h, strength: 0.5f,
            coveredAbove: null, radius: 6, inside: null,
            liftedOff: new byte[] { 0, 0, 128, 128 });
        var full = Fresh();
        OverlayBlend.ApplyNormalIndent(full, blurred, strap, w, h, strength: 0.5f);
        Assert.True(partial[8] > full[8] && partial[8] < 128,
            $"half-lifted should lean between full ({full[8]}) and none (128), got {partial[8]}");
    }

    [Fact]
    public void ApplyNormalIndent_FlatCoverage_NoChange()
    {
        // No edges (flat blurred plane, no strap) → zero gradient → normal unchanged.
        int w = 4, h = 4;
        var baseN = new byte[w * h * 4];
        for (int p = 0; p < w * h; p++) { baseN[p * 4] = 128; baseN[p * 4 + 1] = 128; baseN[p * 4 + 2] = 255; }
        var expected = (byte[])baseN.Clone();
        var strap   = new byte[w * h];               // all skin
        var blurred = new byte[w * h];
        Array.Fill(blurred, (byte)128);              // flat

        OverlayBlend.ApplyNormalIndent(baseN, blurred, strap, w, h, strength: 1f);

        Assert.Equal(expected, baseN);
    }

    [Fact]
    public void ApplyNormalIndent_ZeroDepth_NoChange()
    {
        var baseN   = RGBA(128, 128, 255, 128);
        var strap   = new byte[] { 0 };
        var blurred = new byte[] { 200 };

        OverlayBlend.ApplyNormalIndent(baseN, blurred, strap, 1, 1, strength: 0f);

        Assert.Equal(new byte[] { 128, 128, 255, 128 }, baseN);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static byte[] RGBA(byte r, byte g, byte b, byte a) => [r, g, b, a];

    private static ColorTableSubRow Row(
        float r, float g, float b, float emissive = 0f, int opacity = 0,
        RowBlend blend = RowBlend.Paint, bool beneath = false) =>
        new() { DiffuseR = r, DiffuseG = g, DiffuseB = b, Emissive = emissive, Opacity = opacity,
                Blend = blend, OntoBeneath = beneath };

    private static List<ColorTableRowPreset> Presets(int row, string? diffuseA = null, float emissiveA = 0f)
    {
        return
        [
            new ColorTableRowPreset
            {
                Row    = row,
                SubRowA = new ColorTableSubRowPreset { Diffuse = diffuseA, Emissive = emissiveA }
            }
        ];
    }

    private static Dictionary<int, ColorTableRowOverride> RowDict(int pairIdx, int opA, int opB)
    {
        return new Dictionary<int, ColorTableRowOverride>
        {
            [pairIdx] = new() { A = new() { Opacity = opA }, B = new() { Opacity = opB } }
        };
    }

    // ── ContentTag ───────────────────────────────────────────────────────────
    // The output filename suffix. Stability is the whole point: a sync plugin keys transfers on content,
    // so identical bytes must produce an identical name (no re-upload), and any difference that reaches
    // the written file must produce a different one (or the game keeps rendering its cached texture).

    [Fact]
    public void ContentTag_IdenticalInput_IsStable()
    {
        var a = new byte[1000]; var b = new byte[1000];
        for (int i = 0; i < a.Length; i++) { a[i] = (byte)(i * 7); b[i] = (byte)(i * 7); }

        Assert.Equal(CompositorService.ContentTag(a, 512, 512, 1),
                     CompositorService.ContentTag(b, 512, 512, 1));
    }

    [Fact]
    public void ContentTag_IsEightHexChars()
    {
        var tag = CompositorService.ContentTag(new byte[64], 4, 4);
        Assert.Equal(8, tag.Length);
        Assert.All(tag, c => Assert.Contains(c, "0123456789abcdef"));
    }

    [Fact]
    public void ContentTag_OneChangedByte_ChangesTag()
    {
        var a = new byte[1000];
        var b = (byte[])a.Clone();
        b[997] = 1;   // in the ragged tail past the last whole 8-byte word

        Assert.NotEqual(CompositorService.ContentTag(a), CompositorService.ContentTag(b));
    }

    [Fact]
    public void ContentTag_TailBytesAreNotIgnored()
    {
        // 1003 bytes = 125 whole words + 3 loose. A word-at-a-time hash that forgets the remainder would
        // give these two the same name and the peer would never see the edit.
        var a = new byte[1003];
        var b = (byte[])a.Clone();
        b[1002] = 0xFF;

        Assert.NotEqual(CompositorService.ContentTag(a), CompositorService.ContentTag(b));
    }

    [Fact]
    public void ContentTag_SaltDistinguishesDimensionsAndEncoding()
    {
        var data = new byte[512];

        // Same pixels, different declared size — a resize writes different bytes.
        Assert.NotEqual(CompositorService.ContentTag(data, 128, 128, 0),
                        CompositorService.ContentTag(data, 256, 64, 0));

        // Same pixels, compression toggled — BC7 vs B8G8R8A8 must not share a filename.
        Assert.NotEqual(CompositorService.ContentTag(data, 128, 128, 0),
                        CompositorService.ContentTag(data, 128, 128, 1));
    }

    // ── CanRenderAsShell — which overlays a shell can be cut for ───────────────
    // Every surface the shell builder knows: the character's own body, face, hair, tail and ears. Nothing
    // else, ever — gear, accessories and weapons have no shell path.
    //
    // Face was FALSE here until the multi-surface work landed, and the reason is worth keeping: while the
    // builder could only cut from the body, promoting a face overlay cut a BODY shell and pasted the face
    // art across the whole character. The veto was the correct answer to "there is nowhere to put this",
    // not a statement that faces can't glow.

    private static OverlayDescriptor Target(params string[] mtrl)
        => new() { MaterialGamePaths = [.. mtrl] };

    [Theory]
    [InlineData("chara/human/c1401/obj/body/b0001/material/v0001/mt_c1401b0001_bibo.mtrl")]
    [InlineData("chara/human/c1401/obj/face/f0001/material/mt_c1401f0001_fac_a.mtrl")]
    [InlineData("chara/human/c1401/obj/hair/h0133/material/v0001/mt_c1401h0133_hir_a.mtrl")]
    [InlineData("chara/human/c1401/obj/tail/t0001/material/v0001/mt_c1401t0001_etc_a.mtrl")]
    [InlineData("chara/human/c1801/obj/zear/z0001/material/mt_c1801z0001_zer_a.mtrl")]
    public void CanRenderAsShell_OwnSkinSurfaces_Yes(string mtrl)
        => Assert.True(CompositorService.CanRenderAsShell(Target(mtrl)));

    [Fact]
    public void CanRenderAsShell_BodyUvThroughAnEquipmentSlot_Yes()   // body mods route skin through gear paths
        => Assert.True(CompositorService.CanRenderAsShell(
            Target("chara/equipment/e0001/material/v0001/mt_c0201e0001_top_bibo.mtrl")));

    [Theory]
    [InlineData("chara/equipment/e6039/material/v0001/mt_c0201e6039_sho_a.mtrl")]
    [InlineData("chara/accessory/a0053/material/v0001/mt_c0101a0053_rir_a.mtrl")]
    [InlineData("chara/weapon/w0801/obj/body/b0006/material/v0001/mt_w0801b0006_a.mtrl")]
    [InlineData("chara/monster/m0361/obj/body/b0001/material/v0001/mt_m0361b0001_a.mtrl")]
    public void CanRenderAsShell_NotOurSkin_No(string mtrl)
        => Assert.False(CompositorService.CanRenderAsShell(Target(mtrl)));

    [Fact]
    public void CanRenderAsShell_MixedFaceAndBody_Yes()   // both halves have somewhere to go now
        => Assert.True(CompositorService.CanRenderAsShell(
            Target("chara/human/c1401/obj/face/f0001/material/mt_c1401f0001_fac_a.mtrl",
                   "chara/human/c1401/obj/body/b0001/material/v0001/mt_c1401b0001_bibo.mtrl")));

    [Fact]
    public void CanRenderAsShell_NoMaterialNamed_Yes()   // can't place it — keep the prior behaviour
        => Assert.True(CompositorService.CanRenderAsShell(Target()));

    // ── SnapIndexRowsToDefined ───────────────────────────────────────────────

    /// <summary>An index texture with `red` per texel, green pinned to 255, opaque.</summary>
    private static byte[] IndexOf(params byte[] reds)
    {
        var t = new byte[reds.Length * 4];
        for (int i = 0; i < reds.Length; i++)
        { t[i * 4] = reds[i]; t[i * 4 + 1] = 255; t[i * 4 + 3] = 255; }
        return t;
    }

    [Fact]
    public void SnapIndexRows_UndefinedRow_TakesNeighboursRow()
    {
        // red 255 → pair 16 (defined), red 0 → pair 1 (not defined) → dilated over from the left.
        var index = IndexOf(255, 0, 0);
        OverlayBlend.SnapIndexRowsToDefined(index, 3, 1, new[] { 16 });
        Assert.Equal(255, index[4]);
        Assert.Equal(255, index[8]);
    }

    [Fact]
    public void SnapIndexRows_DefinedRow_LeftAlone()
    {
        // Both pairs are configured, so the boundary between them is a real one — not a repair target.
        var index = IndexOf(255, 0, 0);
        OverlayBlend.SnapIndexRowsToDefined(index, 3, 1, new[] { 1, 16 });
        Assert.Equal(0, index[4]);
        Assert.Equal(0, index[8]);
    }

    [Fact]
    public void SnapIndexRows_UnauthoredTexel_RepairedEvenWhenItsRowIsDefined()
    {
        // The regression this exists for: a mask shell has no _id, so the merge SYNTHESIZES one and paints
        // over only the texels a mask claims. The unclaimed remainder is a real selector, and once the
        // colorset happens to configure that row the numeric test alone calls it authored and the fringe
        // survives — as white, when the seeded pair's other sub-row was never set.
        var index = IndexOf(255, 0, 0);
        var authored = new[] { true, false, false };
        OverlayBlend.SnapIndexRowsToDefined(index, 3, 1, new[] { 1, 16 }, authored: authored);
        Assert.Equal(255, index[4]);
        Assert.Equal(255, index[8]);
    }

    [Fact]
    public void SnapIndexRows_NullAuthored_KeepsPriorBehaviour()
    {
        var withNull = IndexOf(255, 0, 0);
        var withAllTrue = IndexOf(255, 0, 0);
        OverlayBlend.SnapIndexRowsToDefined(withNull, 3, 1, new[] { 1, 16 });
        OverlayBlend.SnapIndexRowsToDefined(withAllTrue, 3, 1, new[] { 1, 16 },
            authored: new[] { true, true, true });
        Assert.Equal(withAllTrue, withNull);
    }

    [Fact]
    public void SnapIndexRows_ShortAuthored_Ignored()   // a mismatched array must not throw or half-apply
    {
        var index = IndexOf(255, 0, 0);
        OverlayBlend.SnapIndexRowsToDefined(index, 3, 1, new[] { 1, 16 }, authored: new[] { false });
        Assert.Equal(0, index[4]);
    }

    [Fact]
    public void SnapIndexRows_DilateBudget_StopsSpreading()
    {
        var index = IndexOf(255, 0, 0, 0, 0);
        OverlayBlend.SnapIndexRowsToDefined(index, 5, 1, new[] { 16 }, dilate: 2);
        Assert.Equal(255, index[4]);
        Assert.Equal(255, index[8]);
        Assert.Equal(0, index[12]);    // past the budget — left unmapped, and never drawn
    }

    /// <summary>
    /// The straightforward version of the dilation: rescan the whole map every pass, filling any invalid
    /// texel that has a valid neighbour in the pass-start snapshot. The shipping code walks a frontier
    /// instead — the same fill, minus the texels that provably cannot be filled — because the full scan
    /// stopped exiting early once `authored` marked a mask shell's whole background invalid. This is the
    /// reference the optimisation has to stay byte-identical to.
    /// </summary>
    private static void NaiveSnap(byte[] index, int w, int h, int[] definedRows, int dilate, bool[]? authored)
    {
        var isDefined = new bool[17];
        foreach (var r in definedRows)
            if (r >= 1 && r <= 16) isDefined[r] = true;

        int n = w * h;
        var valid = new bool[n];
        for (int p = 0; p < n; p++)
            valid[p] = (authored?[p] ?? true) && isDefined[index[p * 4] / 17 + 1];

        var snap = new bool[n];
        for (int it = 0; it < dilate; it++)
        {
            Array.Copy(valid, snap, n);
            int filled = 0;
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                {
                    int p = y * w + x;
                    if (snap[p]) continue;
                    int src = -1;
                    if (x > 0 && snap[p - 1]) src = p - 1;
                    else if (x < w - 1 && snap[p + 1]) src = p + 1;
                    else if (y > 0 && snap[p - w]) src = p - w;
                    else if (y < h - 1 && snap[p + w]) src = p + w;
                    if (src < 0) continue;
                    index[p * 4] = index[src * 4];
                    index[p * 4 + 1] = index[src * 4 + 1];
                    valid[p] = true;
                    filled++;
                }
            if (filled == 0) break;
        }
    }

    [Fact]
    public void SnapIndexRows_FrontierWalk_MatchesTheNaiveFullScan()
    {
        // Randomised rather than hand-picked: what the frontier has to get right is an invariant about
        // which texels are reachable, and the cases that break such a thing are odd shapes — islands,
        // single-texel rows, a region touching an edge — not the tidy ones anybody thinks to write down.
        var rng = new Random(20260831);
        for (int trial = 0; trial < 400; trial++)
        {
            int w = 1 + rng.Next(40), h = 1 + rng.Next(40);
            int n = w * h;

            var index = new byte[n * 4];
            for (int p = 0; p < n; p++)
            {
                index[p * 4]     = (byte)rng.Next(256);   // row selector
                index[p * 4 + 1] = (byte)rng.Next(256);   // sub-row weight
                index[p * 4 + 2] = (byte)rng.Next(256);   // must survive untouched
                index[p * 4 + 3] = 255;
            }

            var defined = Enumerable.Range(1, 16).Where(_ => rng.Next(3) == 0).ToArray();
            if (defined.Length == 0) defined = new[] { 1 + rng.Next(16) };

            bool[]? authored = null;
            if (rng.Next(2) == 0)
            {
                authored = new bool[n];
                // Biased toward contiguous blobs, which is what mask coverage actually looks like, with
                // enough noise to produce islands and ragged edges.
                for (int p = 0; p < n; p++) authored[p] = rng.Next(100) < 70;
            }

            int dilate = rng.Next(4);

            var mine = (byte[])index.Clone();
            var reference = (byte[])index.Clone();
            OverlayBlend.SnapIndexRowsToDefined(mine, w, h, defined, dilate, authored);
            NaiveSnap(reference, w, h, defined, dilate, authored);

            Assert.True(reference.AsSpan().SequenceEqual(mine),
                $"trial {trial}: w={w} h={h} dilate={dilate} authored={(authored == null ? "null" : "set")} "
                + $"rows=[{string.Join(",", defined)}]");
        }
    }

    [Fact]
    public void SnapIndexRows_CarriesGreenWithTheRow()
    {
        // Green is the A/B weight; a repaired texel has to take the pair AND the weight, or it lands on the
        // sub-row the author never set.
        var index = IndexOf(255, 0);
        index[1] = 40;                 // the valid texel leans toward sub-row B
        OverlayBlend.SnapIndexRowsToDefined(index, 2, 1, new[] { 16 });
        Assert.Equal(255, index[4]);
        Assert.Equal(40, index[5]);
    }
}
