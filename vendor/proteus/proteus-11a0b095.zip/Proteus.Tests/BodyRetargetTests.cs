using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Proteus.Services;
using Xunit;

namespace Proteus.Tests;

/// <summary>
/// The body retarget's geometry, against hand-built <see cref="ModelParts"/> at real body scale.
/// <para/>
/// Built by hand rather than through <see cref="SyntheticModel"/> on purpose: that builder's triangles are a metre
/// across, and every constant this feature has — a 40 mm near band, a 30 mm push probe, a 0.1 mm snap — is sized for a
/// character. A metre-wide triangle makes all of them degenerate and the tests would pass for the wrong reason.
/// </summary>
public partial class BodyRetargetTests
{
    private const string SkinMaterial = "/mt_c0201b0001_bibo.mtrl";
    private const string ClothMaterial = "/mt_c0201e6255_top_a.mtrl";

    // ── swapping the garment's skin for the body's ──────────────────────────────────────────────────────

    /// <summary>Triangles a model draws, per material, read back through the reader the Studio uses.</summary>
    private static Dictionary<string, int> Drawn(byte[] mdl)
    {
        var drawn = new Dictionary<string, int>(StringComparer.Ordinal);
        foreach (var part in ModelPartReader.Read(mdl)!.Parts.Where(p => p.Island < 0))
            drawn[part.Material.TrimStart('/')] = drawn.GetValueOrDefault(part.Material.TrimStart('/'))
                                                + part.Triangles.Length / 3;
        return drawn;
    }

    /// <summary>A resized slot whose new body is <paramref name="body"/>. The swap reads only the target and its file.</summary>
    private static BodyRetarget.SlotPair Resized(string slot, byte[] body)
    {
        var target = ModelPartReader.Read(body)!;
        Assert.True(IdentityCorrespondence.TryBuild(target, target, slot, out var built, out string refusal), refusal);
        return new BodyRetarget.SlotPair(slot, built!, target, body);
    }

    private const string HipSkin = "/mt_c0201b0001_b.mtrl";

    [Fact]
    public void The_skin_swap_replaces_the_resized_slot_s_skin_mesh_with_the_body_s_whole()
    {
        // The garment's chest skin mesh, all of it on the chest: it goes whole, and the body's own skin takes its
        // place. A mesh is never cut into — it is swapped entire or kept entire.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 2),
                                                  new SyntheticModel.Sub(0, TrianglesPerIsland: 1)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.001f)));
        // The chest's new body skin, denser than the garment's copy.
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out var report);

        Assert.NotNull(rebuilt);
        Assert.Equal(3, report.Removed);
        Assert.Equal(5, report.Added);
        Assert.Equal(0, report.Kept);

        // The cloth untouched; the only skin drawn is the body's five triangles.
        var drawn = Drawn(rebuilt!);
        Assert.Equal(4, drawn[ClothMaterial.TrimStart('/')]);
        Assert.Equal(5, drawn.Where(d => SecondSkinWriter.IsBodySkinMaterial("/" + d.Key)).Sum(d => d.Value));
    }

    [Fact]
    public void A_skin_mesh_only_partly_on_the_body_is_kept_whole()
    {
        // A heeled shoe draws its own foot, turned onto the toe, in the same mesh as the lower leg: the leg sits on the
        // body and the foot does not. Swapping by majority handed the whole mesh to the body — whose skin has no foot
        // — and the foot vanished. Part on, part off: the author's mesh stays, all of it.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 2),
                                                  new SyntheticModel.Sub(0, OffsetZ: 5f)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.001f)));
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));

        Assert.Null(BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out var report));
        Assert.Equal(0, report.Removed);
        Assert.Equal(1, report.Kept);
        Assert.Equal(1, report.Posed);
    }

    [Fact]
    public void A_skin_mesh_laid_millimetres_off_the_body_is_still_the_body_s()
    {
        // The Pioneer's Bottoms' waist strip: laid onto Rue+, two of its 38 corners missed the hip by 6 mm. Counted
        // against the 2 mm that tells slots apart it read as a posed piece, and the vanilla skin stayed over the new body.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 2),
                                                  new SyntheticModel.Sub(0, OffsetZ: 0.006f)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.02f)));
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out var report);

        Assert.NotNull(rebuilt);
        Assert.Equal(3, report.Removed);
        Assert.Equal(0, report.Kept);
        Assert.Equal(0, report.Posed);
    }

    [Fact]
    public void Skin_of_a_slot_nobody_is_resizing_stays_as_the_author_left_it()
    {
        // A long top: chest skin, and hip skin that belongs to the legs. Only the chest is being resized.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 2)),
            new SyntheticModel.Mesh(HipSkin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetY: 50f)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.001f)));
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out var report);

        Assert.NotNull(rebuilt);
        Assert.Equal(2, report.Removed);
        Assert.Equal(1, report.Kept);
        var drawn = Drawn(rebuilt!);
        Assert.Equal(3, drawn[HipSkin.TrimStart('/')]);                       // the hips, exactly as they were
        Assert.Equal(5, drawn[SkinMaterial.TrimStart('/')]);                  // the chest, the body's
    }

    [Fact]
    public void Each_resized_slot_takes_its_own_body_s_skin()
    {
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 2)),
            new SyntheticModel.Mesh(HipSkin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetY: 50f)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.001f)));
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));
        var legs = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 7, OffsetY: 50f)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest), Resized("_dwn", legs)], out var report);

        Assert.NotNull(rebuilt);
        Assert.Equal(2 + 3, report.Removed);
        Assert.Equal(5 + 7, report.Added);
        var drawn = Drawn(rebuilt!);
        Assert.False(drawn.ContainsKey(HipSkin.TrimStart('/')));
        Assert.Equal(12, drawn.Where(d => SecondSkinWriter.IsBodySkinMaterial("/" + d.Key)).Sum(d => d.Value));
    }

    [Fact]
    public void The_swapped_skin_keeps_the_tags_other_gear_hides_it_by_and_drops_variant_tags()
    {
        // atr_ude is how long gloves hide the arm skin under them; atr_tv_a is a Neolithe body's own variant toggle,
        // which the garment's IMC mask was never written for.
        var garment = SyntheticModel.Build(["atr_ude"],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0b1, TrianglesPerIsland: 2)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.001f)));
        var chest = SyntheticModel.Build(["atr_ude", "atr_tv_a"],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0b11, TrianglesPerIsland: 5)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out _);

        var model = ModelPartReader.Read(rebuilt!)!;
        var skin = model.Parts.Single(p => p.Island < 0 && SecondSkinWriter.IsBodySkinMaterial(p.Material));
        var tags = Enumerable.Range(0, model.AttributeNames.Count)
                             .Where(bit => (skin.AttributeMask & (1u << bit)) != 0)
                             .Select(bit => model.AttributeNames[bit]).ToList();
        Assert.Equal(["atr_ude"], tags);
        Assert.DoesNotContain("atr_tv_a", model.AttributeNames);
    }

    [Fact]
    public void A_body_bulging_off_a_large_skin_triangle_is_still_under_it()
    {
        // The game's own gear draws an arm in triangles 40 mm across. Laid onto a body, a triangle's corners sit on it
        // and its middle is a chord the body rises off — 4.8 mm on the Neotunic's upper arm — and the swap cut holes
        // there the author never made.
        static BodySurface Triangle(float edge)
            => new(Build([0f, 0f, 0f, edge, 0f, 0f, 0f, edge, 0f], [0, 0, 1, 0, 0, 1, 0, 0, 1], [0, 1, 2], SkinMaterial),
                   0.01f);
        var large = Triangle(0.04f);
        var small = Triangle(0.01f);
        var middle = new Vector3(0.01f, 0.01f, 0f);

        Assert.True(BodyRetarget.Covers(large, middle + new Vector3(0f, 0f, 0.0065f)));   // inside, and within 20% of 40 mm
        Assert.False(BodyRetarget.Covers(large, middle + new Vector3(0f, 0f, 0.0118f)));  // past 20% of its 56.6 mm side
        // A 10 mm triangle sags nowhere near 6.5 mm: what the author's own fine skin allows stays at the plain reach.
        Assert.False(BodyRetarget.Covers(small, new Vector3(0.003f, 0.003f, 0.0065f)));
        Assert.True(BodyRetarget.Covers(small, new Vector3(0.003f, 0.003f, 0.0035f)));
        // Off the triangle's edge is where the author stopped drawing skin: the plain reach, however large the triangle.
        Assert.False(BodyRetarget.Covers(large, new Vector3(0.02f, -0.0065f, 0f)));
    }

    [Fact]
    public void A_body_bulging_over_an_edge_two_skin_triangles_share_is_still_under_it()
    {
        // A ridge: two 40 mm triangles folded down either side of a shared edge, as coarse skin bends round an arm. A
        // point above the ridge lands ON the edge — a zero weight — and the body rises off that edge as far as off a
        // triangle's middle. The same edge on a lone triangle is where the author stopped drawing skin.
        float[] pos = [0f, 0f, 0f, 0.04f, 0f, 0f, 0.02f, 0.03f, -0.015f, 0.02f, -0.03f, -0.015f];
        float[] nrm = [0, 0, 1, 0, 0, 1, 0, 1, 0, 0, -1, 0];
        var ridge = Build(pos, nrm, [0, 1, 2, 1, 0, 3], SkinMaterial);
        var lone = Build(pos, nrm, [0, 1, 2], SkinMaterial);
        var above = new Vector3(0.02f, 0f, 0.0065f);

        Assert.True(BodyRetarget.Covers(new BodySurface(ridge, 0.01f), above, BodyRetarget.SkinEdges.Of(ridge)));
        Assert.False(BodyRetarget.Covers(new BodySurface(lone, 0.01f), above, BodyRetarget.SkinEdges.Of(lone)));
        // Without the edges, every edge is the author's boundary: the plain reach.
        Assert.False(BodyRetarget.Covers(new BodySurface(ridge, 0.01f), above));
    }

    [Fact]
    public void Skin_a_few_millimetres_off_the_body_is_on_it_only_over_its_middle()
    {
        // A 40 mm square of body. Laid skin that missed it by 6 mm sits OVER it — off along its normal — and counts, even
        // above the square's edge or corner; skin 6 mm PAST its edge — a hip strip just below where the chest body
        // stops — is off along the surface, and is another slot's.
        float[] pos = [0f, 0f, 0f, 0.04f, 0f, 0f, 0.04f, 0.04f, 0f, 0f, 0.04f, 0f];
        float[] nrm = [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1];
        var body = new BodySurface(Build(pos, nrm, [0, 1, 2, 0, 2, 3], SkinMaterial), 0.01f);

        Assert.True(BodyRetarget.OnBody(body, new Vector3(0.03f, 0.01f, 0.006f)));    // over a triangle
        Assert.True(BodyRetarget.OnBody(body, new Vector3(0.02f, 0.02f, -0.006f)));   // under the shared diagonal
        Assert.True(BodyRetarget.OnBody(body, new Vector3(0f, 0f, 0.006f)));          // over the corner
        Assert.True(BodyRetarget.OnBody(body, new Vector3(0.02f, -0.001f, 0f)));      // past the edge, but within 2 mm
        Assert.False(BodyRetarget.OnBody(body, new Vector3(0.02f, -0.006f, 0f)));     // past the edge
        Assert.False(BodyRetarget.OnBody(body, new Vector3(-0.004f, -0.004f, 0f)));   // past the corner
        Assert.False(BodyRetarget.OnBody(body, new Vector3(0.03f, 0.01f, 0.012f)));   // beyond LayFull
    }

    [Fact]
    public void The_body_that_comes_in_is_cut_the_way_the_author_cut_the_one_going_out()
    {
        // A garment author hides the body under the cloth by deleting its faces — 84% of it, on the jacket this was
        // measured on. The body mod ships the body whole, so putting it in whole puts the deleted shoulder back
        // through the jacket. What the author drew is what the new body draws.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.001f)));
        // The body: the same five triangles the garment's skin draws, and three well away that it does not.
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5),
                                                  new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetY: 50f)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out var report);

        Assert.NotNull(rebuilt);
        Assert.Equal("added 5 cut 3", $"added {report.Added} cut {report.Cut}");
        Assert.Equal(5, Drawn(rebuilt!).Where(d => SecondSkinWriter.IsBodySkinMaterial("/" + d.Key))
                                       .Sum(d => d.Value));
    }

    [Fact]
    public void With_the_cut_turned_off_the_body_comes_in_whole()
    {
        // The same garment and body as above; the user asked for the skin the author deleted to stay.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.001f)));
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5),
                                                  new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetY: 50f)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out var report, cutHidden: false);

        Assert.NotNull(rebuilt);
        Assert.Equal("added 8 cut 0", $"added {report.Added} cut {report.Cut}");
        Assert.Equal(8, Drawn(rebuilt!).Where(d => SecondSkinWriter.IsBodySkinMaterial("/" + d.Key))
                                       .Sum(d => d.Value));
    }

    [Fact]
    public void A_body_mesh_the_cut_empties_is_not_drawn_at_all()
    {
        // The cut is carried per mesh, and a mesh the writer has no entry for draws WHOLE — that is how a body
        // nothing was cut from goes in. So a body whose skin spans two meshes, one of them entirely under the
        // cloth, is the case that inverts: the mesh most deserving of the cut is the one that comes back in full.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.001f)));
        // Two skin MESHES: the five the garment draws, and three of a second mesh well away, which it does not.
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetY: 50f)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out var report);

        Assert.NotNull(rebuilt);
        Assert.Equal("added 5 cut 3", $"added {report.Added} cut {report.Cut}");
        Assert.Equal(5, Drawn(rebuilt!).Where(d => SecondSkinWriter.IsBodySkinMaterial("/" + d.Key))
                                       .Sum(d => d.Value));
    }

    [Fact]
    public void The_body_s_skin_keeps_the_body_s_material_when_the_layouts_differ()
    {
        // The game's own gear names the vanilla skin material, whose texture is laid out gen2. Swap the body's mesh
        // in under that material and its bibo texture coordinates read the wrong half of the sheet — pale blocks
        // across the back, hard-edged where the islands change.
        const string vanillaSkin = "/mt_c0201b0001_a.mtrl";
        const string biboSkin = "/mt_c0201b0001_bibo.mtrl";

        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(vanillaSkin, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.001f)));
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(biboSkin, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out _);

        Assert.NotNull(rebuilt);
        var drawn = Drawn(rebuilt!);
        Assert.Contains(biboSkin.TrimStart('/'), drawn.Keys);
        Assert.DoesNotContain(vanillaSkin.TrimStart('/'), drawn.Keys);
    }

    [Fact]
    public void The_author_s_own_skin_material_stands_when_the_layouts_agree()
    {
        // An author who gave their skin its own material — a tattoo, a scar — meant it, and a garment made for this
        // body already names one in the body's layout. Nothing about swapping the mesh changes that.
        const string theirs = "/mt_c0201b0001_bibo.mtrl";

        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(theirs, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.001f)));
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh("/mt_c0201b0001_other_bibo.mtrl", new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out _);

        Assert.NotNull(rebuilt);
        Assert.Contains(theirs.TrimStart('/'), Drawn(rebuilt!).Keys);
    }

    [Fact]
    public void Nothing_is_rebuilt_when_no_skin_mesh_belongs_to_a_resized_slot()
    {
        var clothOnly = SyntheticModel.Build([],
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 2)));
        var hipsOnly = SyntheticModel.Build([],
            new SyntheticModel.Mesh(HipSkin, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, OffsetY: 50f)));
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 2)));

        Assert.Null(BodyRetarget.SwapSkin(clothOnly, [Resized("_top", chest)], out _));
        Assert.Null(BodyRetarget.SwapSkin(hipsOnly, [Resized("_top", chest)], out _));
    }

    // ── the new body's nails and piercings ──────────────────────────────────────────────────────────────

    private const string TreNails = "/mt_c0201b0001_trenails.mtrl";

    [Fact]
    public void The_body_s_nails_come_in_with_its_skin_tagged_as_the_body_tags_them()
    {
        // Tre draws its nails in their own material, switched on by a nail mod's atrx_nt_mani. A glove refitted onto
        // Tre's hands took the skin alone, and the hands went bare.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));
        var hands = SyntheticModel.Build(["atrx_nt_mani"],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(TreNails, new SyntheticModel.Sub(0b1, OffsetZ: 0.001f)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_glv", hands)], out var report);

        Assert.NotNull(rebuilt);
        Assert.Equal(1, report.Adorned);
        var model = ModelPartReader.Read(rebuilt!)!;
        var nails = model.Parts.Single(p => p.Island < 0 && p.Material == TreNails);
        Assert.Equal(["atrx_nt_mani"], Enumerable.Range(0, model.AttributeNames.Count)
                                                 .Where(bit => (nails.AttributeMask & (1u << bit)) != 0)
                                                 .Select(bit => model.AttributeNames[bit]));
    }

    [Fact]
    public void Nails_over_skin_the_author_deleted_stay_out()
    {
        // A full glove: its author deleted the fingertips, and the body's nails go with them. The one over skin the
        // garment draws comes in.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));
        var hands = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5),
                                                  new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetY: 50f)),
            new SyntheticModel.Mesh(TreNails, new SyntheticModel.Sub(0, OffsetZ: 0.001f),
                                              new SyntheticModel.Sub(0, OffsetY: 50f, OffsetZ: 0.001f)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_glv", hands)], out var report);

        Assert.Equal("cut 3 adorned 1", $"cut {report.Cut} adorned {report.Adorned}");
        Assert.Equal(1, Drawn(rebuilt!)[TreNails.TrimStart('/')]);
    }

    [Fact]
    [Trait("Plan", "AC-refit-piercings-option-2")]
    public void A_piercing_under_cloth_stays_out_unless_the_garment_showed_one_there()
    {
        // [AC-refit-piercings-option-2] With the piercings asked for, the rules are today's.
        // A top that keeps the skin under an opaque cup: put in, the body's ring would stand through the cloth. But
        // where the garment carried its own piercing, its author showed one — through sheer cloth or not.
        const string piercings = "/mt_c0201b0001_piercings.mtrl";
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(piercings, new SyntheticModel.Sub(0, OffsetZ: 0.001f)));
        var covered = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.003f)));
        var shown = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(ClothMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, OffsetZ: 0.003f)),
            new SyntheticModel.Mesh(piercings, new SyntheticModel.Sub(0, OffsetZ: 0.001f)));

        var under = BodyRetarget.SwapSkin(covered, [Resized("_top", chest)], out var underReport, carryPiercings: true);
        var over = BodyRetarget.SwapSkin(shown, [Resized("_top", chest)], out var overReport, carryPiercings: true);

        Assert.Equal(0, underReport.Adorned);
        Assert.False(Drawn(under!).ContainsKey(piercings.TrimStart('/')));
        // The garment's own, and the body's in its place: one, not two.
        Assert.Equal(1, overReport.Adorned);
        Assert.Equal(1, Drawn(over!)[piercings.TrimStart('/')]);
    }

    [Fact]
    [Trait("Plan", "AC-refit-piercings-option-2")]
    [Trait("Plan", "EDGE-refit-piercings-option-2")]
    public void A_chain_hanging_off_the_skin_comes_in_with_what_it_hangs_from()
    {
        // [AC-refit-piercings-option-2]
        // YAB strings a chain between the nipple rings, its links 20-30 mm in front of the sternum: too far off the skin
        // to land on it, they were left out link by link. A link goes with the one it touches; one touching nothing
        // that came in stays out.
        const string piercings = "/mt_c0201b0001_piercings.mtrl";
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));
        var chain = new[] { 0.001f, 0.005f, 0.009f, 0.013f, 0.017f, 0.021f, 0.025f, 0.029f }
            .Select(z => new SyntheticModel.Sub(0, OffsetZ: z))
            .Append(new SyntheticModel.Sub(0, OffsetX: 3f, OffsetZ: 0.025f))   // hung from nothing
            .ToArray();
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(piercings, chain));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out var report, carryPiercings: true);

        Assert.Equal(8, report.Adorned);
        Assert.Equal(8, Drawn(rebuilt!)[piercings.TrimStart('/')]);

        // [EDGE-refit-piercings-option-2] Not asked for, no link comes in.
        var off = BodyRetarget.SwapSkin(garment, [Resized("_top", chest)], out var offReport);
        Assert.Equal(0, offReport.Adorned);
        Assert.False(Drawn(off!).ContainsKey(piercings.TrimStart('/')));
    }

    [Fact]
    public void A_garment_with_no_material_room_keeps_its_own_nails()
    {
        // Nine materials, the garment's own Tre nails among them: the body's skin takes the tenth, and the body's nails
        // have nowhere to go. Swapped piecemeal, the garment's nails went and nothing came in their place.
        var meshes = new List<SyntheticModel.Mesh>
        {
            new(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new(TreNails, new SyntheticModel.Sub(0, OffsetZ: 0.001f)),
        };
        for (int i = 0; i < 7; i++)
            meshes.Add(new($"/mt_c0201e6255_glv_{(char)('a' + i)}.mtrl",
                           new SyntheticModel.Sub(0, OffsetY: 50f + i, OffsetZ: 0.001f)));
        var garment = SyntheticModel.Build([], [.. meshes]);
        var hands = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(TreNails, new SyntheticModel.Sub(0, OffsetZ: 0.001f)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_glv", hands)], out var report);

        Assert.NotNull(rebuilt);
        Assert.Equal(0, report.Adorned);
        Assert.Equal(1, Drawn(rebuilt!)[TreNails.TrimStart('/')]);           // the garment's own, kept
    }

    [Theory]
    [InlineData("/mt_c0201b0001_piercings.mtrl", true)]
    [InlineData("/mt_c0201b0001_neolithe_piercings.mtrl", true)]
    [InlineData("/mt_c0201b0001_nipplepierce.mtrl", true)]
    [InlineData("/mt_c0201b0001_trenails.mtrl", true)]
    [InlineData("/mt_c0201b0001_treaccent.mtrl", true)]
    [InlineData("/mt_c0201b0001_neolithe_nails.mtrl", true)]
    [InlineData("/mt_c0201b0001_yafinger.mtrl", true)]
    [InlineData("/mt_c0201b0001_bibo.mtrl", false)]              // skin
    [InlineData("/mt_c0201b0001_bibopube.mtrl", false)]          // sits under whatever the legs wear
    [InlineData("/mt_c0201b0001_neolithe_penis.mtrl", false)]
    [InlineData("/mt_c0201b0001_tre_trans.mtrl", false)]
    [InlineData("/mt_c0201b0001_ckundies.mtrl", false)]
    [InlineData("/mt_c0201e6255_top_a.mtrl", false)]             // a garment's own
    public void Only_a_body_s_nails_and_piercings_are_carried(string material, bool carried)
        => Assert.Equal(carried, BodyRetarget.IsBodyAdornmentMaterial(material));

    // ── piercings only when asked for ───────────────────────────────────────────────────────────────────

    private const string Piercings = "/mt_c0201b0001_piercings.mtrl";

    [Theory]
    [Trait("Plan", "AC-refit-piercings-option-3")]
    [Trait("Plan", "EDGE-refit-piercings-option-3")]
    [InlineData("/mt_c0201b0001_piercings.mtrl", true)]
    [InlineData("/mt_c0201b0001_neolithe_piercings.mtrl", true)]
    [InlineData("/mt_c0201b0001_neolithe_piercings_top.mtrl", true)]
    [InlineData("/mt_c0201b0001_nipplepierce.mtrl", true)]
    [InlineData("/mt_c0201b0001_navelpierce.mtrl", true)]
    [InlineData("/mt_c0201b0001_genitalpierce.mtrl", true)]
    [InlineData("/mt_c0201b0001_nailpiercing.mtrl", true)]       // [EDGE-refit-piercings-option-3] both: a piercing
    [InlineData("/mt_c0201b0001_trenails.mtrl", false)]
    [InlineData("/mt_c0201b0001_treaccent.mtrl", false)]
    [InlineData("/mt_c0201b0001_neolithe_nails.mtrl", false)]
    [InlineData("/mt_c0201b0001_yafinger.mtrl", false)]
    [InlineData("/mt_c0201b0001_yatoe.mtrl", false)]
    [InlineData("/mt_c0201b0001_bibo.mtrl", false)]              // skin
    [InlineData("/mt_c0201b0001_bibopube.mtrl", false)]
    [InlineData("/mt_c0201e6255_top_a.mtrl", false)]             // a garment's own
    public void Only_a_body_s_piercings_are_gated(string material, bool piercing)
        // [AC-refit-piercings-option-3] [EDGE-refit-piercings-option-3]
        => Assert.Equal(piercing, BodyRetarget.IsBodyPiercingMaterial(material));

    [Fact]
    [Trait("Plan", "AC-refit-piercings-option-1")]
    public void The_body_s_piercings_stay_out_unless_asked_for()
    {
        // [AC-refit-piercings-option-1] A top whose skin shows the ring: the body's comes in only when asked, through
        // the swap and through Plan, as the Studio, the size set and the automatic refit call it.
        var chest = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, OffsetZ: 0.001f)));
        var bare = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));

        var off = BodyRetarget.SwapSkin(bare, [Resized("_top", chest)], out var offReport);
        var on = BodyRetarget.SwapSkin(bare, [Resized("_top", chest)], out var onReport, carryPiercings: true);
        Assert.Equal(0, offReport.Adorned);
        Assert.False(Drawn(off!).ContainsKey(Piercings.TrimStart('/')));
        Assert.Equal(1, onReport.Adorned);
        Assert.Equal(1, Drawn(on!)[Piercings.TrimStart('/')]);

        var planOff = BodyRetarget.Plan(ModelPartReader.Read(bare)!, bare, [Resized("_top", chest)], "_top",
                                        pushOut: false, replaceSkin: true);
        var planOn = BodyRetarget.Plan(ModelPartReader.Read(bare)!, bare, [Resized("_top", chest)], "_top",
                                       pushOut: false, replaceSkin: true, carryPiercings: true);
        Assert.False(Drawn(planOff.Model).ContainsKey(Piercings.TrimStart('/')));
        Assert.Equal(1, Drawn(planOn.Model)[Piercings.TrimStart('/')]);
    }

    [Fact]
    [Trait("Plan", "AC-refit-piercings-option-3")]
    public void Nails_come_in_and_piercings_stay_out_with_the_option_off()
    {
        // [AC-refit-piercings-option-3] Tre's nails and a ring, both on skin the garment draws: the nails come in
        // whatever the piercings setting says.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));
        var body = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(TreNails, new SyntheticModel.Sub(0, OffsetZ: 0.001f)),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, OffsetX: 0.2f, OffsetZ: 0.001f)));

        var off = BodyRetarget.SwapSkin(garment, [Resized("_glv", body)], out var offReport);
        var on = BodyRetarget.SwapSkin(garment, [Resized("_glv", body)], out var onReport, carryPiercings: true);

        Assert.Equal(1, offReport.Adorned);
        Assert.Equal(1, Drawn(off!)[TreNails.TrimStart('/')]);
        Assert.False(Drawn(off!).ContainsKey(Piercings.TrimStart('/')));
        Assert.Equal(2, onReport.Adorned);
        Assert.Equal(1, Drawn(on!)[TreNails.TrimStart('/')]);
        Assert.Equal(1, Drawn(on!)[Piercings.TrimStart('/')]);
    }

    [Fact]
    [Trait("Plan", "EDGE-refit-piercings-option-1")]
    public void Without_piercings_the_nails_fit_where_both_did_not()
    {
        // [EDGE-refit-piercings-option-1] Eight materials, the garment's own two-triangle Tre nails among them: one
        // free after the body's skin. The body's nails and ring would take two; its nails alone fit.
        var meshes = new List<SyntheticModel.Mesh>
        {
            new(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new(TreNails, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, OffsetZ: 0.001f)),
        };
        for (int i = 0; i < 6; i++)
            meshes.Add(new($"/mt_c0201e6255_glv_{(char)('a' + i)}.mtrl",
                           new SyntheticModel.Sub(0, OffsetY: 50f + i, OffsetZ: 0.001f)));
        var garment = SyntheticModel.Build([], [.. meshes]);
        var body = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(TreNails, new SyntheticModel.Sub(0, OffsetZ: 0.001f)),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, OffsetX: 0.2f, OffsetZ: 0.001f)));

        var off = BodyRetarget.SwapSkin(garment, [Resized("_glv", body)], out var offReport);
        var on = BodyRetarget.SwapSkin(garment, [Resized("_glv", body)], out var onReport, carryPiercings: true);

        Assert.Equal(1, offReport.Adorned);
        Assert.Equal(1, Drawn(off!)[TreNails.TrimStart('/')]);               // the body's, in place of the garment's
        Assert.Equal(0, onReport.Adorned);
        Assert.Equal(2, Drawn(on!)[TreNails.TrimStart('/')]);                // no room: the garment's own, kept
    }

    [Fact]
    [Trait("Plan", "EDGE-refit-piercings-option-5")]
    public void Within_one_body_nails_swap_and_the_author_s_piercings_stay()
    {
        // [EDGE-refit-piercings-option-5] The garment's own two-triangle nails and ring, over a body with one-triangle
        // ones. Off: the nails are the body's, the ring the author's — one ring, not two.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(TreNails, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, OffsetZ: 0.001f)),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, OffsetX: 0.2f,
                                                                      OffsetZ: 0.001f)));
        var body = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(TreNails, new SyntheticModel.Sub(0, OffsetZ: 0.001f)),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, OffsetX: 0.2f, OffsetZ: 0.001f)));

        var rebuilt = BodyRetarget.SwapSkin(garment, [Resized("_top", body)], out var report);

        Assert.Equal(1, report.Adorned);
        Assert.Equal(1, Drawn(rebuilt!)[TreNails.TrimStart('/')]);
        Assert.Equal(2, Drawn(rebuilt!)[Piercings.TrimStart('/')]);
    }

    [Fact]
    [Trait("Plan", "EDGE-refit-piercings-option-13")]
    public void A_hidden_variant_s_piercing_stays_out_with_the_option_on()
    {
        // [EDGE-refit-piercings-option-13] A ring on a variant the body mod does not draw: asked for or not, it stays out.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)));
        var body = SyntheticModel.Build(["atr_tv_b"],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0b1, OffsetZ: 0.001f)));
        var pair = Resized("_top", body) with { TargetHidden = new HashSet<string> { "atr_tv_b" } };

        var shown = BodyRetarget.SwapSkin(garment, [Resized("_top", body)], out var shownReport, carryPiercings: true);
        var hidden = BodyRetarget.SwapSkin(garment, [pair], out var hiddenReport, carryPiercings: true);

        Assert.Equal(1, shownReport.Adorned);                                // reaches the case
        Assert.Equal(0, hiddenReport.Adorned);
        Assert.False(Drawn(hidden!).ContainsKey(Piercings.TrimStart('/')));
    }

    [Fact]
    [Trait("Plan", "EDGE-refit-piercings-option-14")]
    public void Finish_style_swap_keeps_the_author_s_piercings_with_the_option_off()
    {
        // [EDGE-refit-piercings-option-14] As the headless refit's --finish: its own body, nothing pushed. Off keeps the
        // author's two-triangle ring; on swaps it for the body's one.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, OffsetZ: 0.001f)));
        var body = SyntheticModel.Build([],
            new SyntheticModel.Mesh(SkinMaterial, new SyntheticModel.Sub(0, TrianglesPerIsland: 5)),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, OffsetZ: 0.001f)));
        var parts = ModelPartReader.Read(garment)!;

        var off = BodyRetarget.Plan(parts, garment, [Resized("_top", body)], "_top", pushOut: false, replaceSkin: true);
        var on = BodyRetarget.Plan(parts, garment, [Resized("_top", body)], "_top", pushOut: false, replaceSkin: true,
                                   carryPiercings: true);

        Assert.Equal(0, off.Report.Swap!.Value.Adorned);
        Assert.Equal(2, Drawn(off.Model)[Piercings.TrimStart('/')]);
        Assert.Equal(1, on.Report.Swap!.Value.Adorned);
        Assert.Equal(1, Drawn(on.Model)[Piercings.TrimStart('/')]);
    }

    // ── which mods are bodies ───────────────────────────────────────────────────────────────────────────

    [Theory]
    [InlineData("chara/equipment/e0000/model/c0201e0000_top.mdl", true)]
    [InlineData("chara/equipment/e0000/model/c0101e0000_dwn.mdl", true)]
    [InlineData("Chara/Equipment/e0000/Model/c1401e0000_sho.mdl", true)]
    [InlineData("chara/equipment/e0279/model/c0201e0279_top.mdl", false)]   // the same files again: sizes listed twice
    [InlineData("chara/equipment/e0194/model/c0201e0194_top.mdl", false)]   // an outfit with a size group of its own
    [InlineData("chara/equipment/e0000/model/c0201e0000_met.mdl", false)]
    [InlineData("chara/equipment/e0000/texture/c0201e0000_top_n.tex", false)]
    public void Only_the_smallclothes_model_makes_a_mod_a_body(string gamePath, bool body)
        => Assert.Equal(body, BodySizeCatalog.IsBodyModel(gamePath));

    // ── the two senses of "is this skin?", asserted next to each other ──────────────────────────────────
    //
    // The transfer and the push-out consult SecondSkinWriter.IsBodySkinMaterial with OPPOSITE senses, and the brush
    // has a third, opposite again to the transfer's. The three tests below sit together so that changing any one of
    // them is visibly a change to a set, not an isolated tweak.

    [Fact]
    public void The_refit_never_touches_the_author_s_normals()
    {
        // Recomputing normals from the moved surface — relaxed, averaged over welded seams, blended toward the body's
        // under laid skin — blotched a shirt sleeve dark and light. Every normal comes back zero, which Inflate reads
        // as "leave this vertex's normal as the file has it".
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);
        var garment = Copy(source, ClothMaterial);
        Assert.True(IdentityCorrespondence.TryBuild(source, target, "chest", out var built, out string why), why);

        foreach (bool lay in new[] { false, true })
        {
            var solved = BodyRetarget.Solve(garment, [new BodyRetarget.SlotPair("_top", built!, target)], replaceSkin: lay);
            Assert.True(solved.WorstMove > 0f, "the garment should have moved");
            for (int v = 0; v < garment.Positions.Length / 3; v++)
            {
                var n = solved.Edit.NormalAt(v);
                Assert.True(n.X == 0f && n.Y == 0f && n.Z == 0f, $"vertex {v} was given a normal ({n.X}, {n.Y}, {n.Z})");
            }
        }
    }

    [Fact]
    public void Tracing_the_solve_changes_nothing()
    {
        // [AC-outfit-fit-2] A diagnostic reads each stage's moves; the refit it watches must come out the same.
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);
        var garment = Copy(Cube(0.21f, SkinMaterial), ClothMaterial);
        Assert.True(IdentityCorrespondence.TryBuild(source, target, "chest", out var built, out string why), why);
        List<BodyRetarget.SlotPair> pairs = [new("_top", built!, target)];

        var plain = BodyRetarget.Solve(garment, pairs, "_top", replaceSkin: true);
        var stages = new List<string>();
        SecondSkinWriter.Vec3[]? last = null;
        var traced = BodyRetarget.Solve(garment, pairs, "_top", replaceSkin: true,
                                        trace: (stage, delta) => { stages.Add(stage); last = delta; });

        Assert.Equal(["transfer", "knit", "layer-knit", "lay", "follow", "push", "unfold", "relax", "face-settle",
                      "rim-lift", "standoff", "layer-order"], stages);
        Assert.True(plain.WorstMove > 0f, "the garment should have moved");
        Assert.Equal(plain.Pushed, traced.Pushed);
        Assert.Equal(plain.Folded, traced.Folded);
        // The last stage is what is written.
        var sets = BodyRetarget.Sets.From(garment, null, BodyRetarget.PartedSkinMeshes(garment, pairs, "_top", true, null));
        Assert.NotNull(last);
        for (int v = 0; v < garment.Positions.Length / 3; v++)
        {
            Assert.Equal(Delta(plain, v), Delta(traced, v));
            var written = last![sets.NodeOf[v]];
            Assert.Equal(Delta(plain, v), new Vector3(written.X, written.Y, written.Z));
        }
    }

    [Fact]
    public void Retarget_moves_the_garment_s_own_skin_mesh()
    {
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);

        // A garment whose body mesh is a verbatim copy of the source body's, which is how gear is usually built.
        var garment = Copy(source, SkinMaterial);

        var solved = Solve(garment, source, target);

        Assert.True(solved.Snapped > 0, "the garment's body mesh is a copy of the body, so it should snap");
        for (int v = 0; v < garment.Positions.Length / 3; v++)
        {
            var landed = At(garment, v) + Delta(solved, v);
            var wanted = At(target, v);
            Assert.True(Vector3.Distance(landed, wanted) < 1e-5f,
                        $"vertex {v} landed at {landed}, wanted the target body's {wanted}");
        }
    }

    [Fact]
    public void The_brush_leaves_the_same_vertices_alone()
    {
        // The contrast case. A brush must never move skin; the retarget must always move it. Both guarantees are
        // real and they are opposites, so they are asserted in one place.
        var source = Cube(0.20f, SkinMaterial);
        var garment = Copy(source, SkinMaterial);

        var solve = new MeshVolumeSolve(garment);
        solve.Paint(new Vector3(0f, 0f, 0.20f), radius: 0.5f, strength: 0.05f,
                    toViewer: new Vector3(0f, 0f, 1f));

        for (int v = 0; v < garment.Positions.Length / 3; v++)
        {
            var d = solve.DeltaAt(v);
            Assert.True(d.X == 0f && d.Y == 0f && d.Z == 0f, $"the brush moved skin vertex {v}");
        }
    }

    [Fact]
    public void Push_out_leaves_the_garment_s_skin_mesh_alone()
    {
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);
        var garment = Copy(source, SkinMaterial);

        var solved = Solve(garment, source, target);

        // Every vertex is snapped and therefore excluded from the push-out. Bit-identical, not "close": the point is
        // that the push-out did not touch them at all, and an epsilon would hide a small nudge.
        for (int v = 0; v < garment.Positions.Length / 3; v++)
        {
            var expected = At(target, v) - At(source, v);
            var actual = Delta(solved, v);
            Assert.Equal(expected.X, actual.X);
            Assert.Equal(expected.Y, actual.Y);
            Assert.Equal(expected.Z, actual.Z);
        }
        Assert.Equal(0, solved.Pushed);
    }

    // ── the push-out: only clips the refit CREATED ─────────────────────────────────────────────────────
    //
    // The scenario these share: two body slots. A holds still; B grows. The patch sits in the gap between them, 30 mm
    // off A and 70 mm off B, so as authored it is outside everything and its nearest body is A — which does not move,
    // so the transfer leaves the patch where it is. B's growth then swallows it, 10 mm deep. That is a clip the refit
    // created, which is the only kind the push-out may undo.

    [Fact]
    public void Cloth_the_refit_drives_into_a_body_is_pushed_out()
    {
        var (garment, pairs) = CreatedClip(ClothMaterial);

        var solved = BodyRetarget.Solve(garment, pairs);

        Assert.True(solved.Pushed > 0, "the refit swallowed this cloth, so the push-out should have freed it");

        // The deepest corner is 12.5 mm in. The slope-limited spread lifts the shallower corners towards that, so the
        // whole patch moves together rather than crumpling — which is the spread's job — but nothing may be flung
        // further than the worst clip needed.
        const float deepest = 0.0125f;
        foreach (int v in Enumerable.Range(0, garment.Positions.Length / 3))
        {
            var start = At(garment, v);
            var landed = start + Delta(solved, v);
            Assert.True(landed.X < GrownFace, $"vertex {v} is still inside the grown body at x={landed.X}");
            Assert.True(start.X - landed.X <= deepest + BodyRetarget.Clearance + 1e-5f,
                        $"vertex {v} was pushed {(start.X - landed.X) * 1000f:F2} mm, more than the worst clip needed");
        }
    }

    // ── the push-out: skin through the MIDDLE of a face ──────────────────────────────────────────────────
    //
    // A cube body whose +Z face has a bump at its centre, and one large cloth triangle over that face, 1 mm off it. The
    // triangle's corners are far from the bump, so only the face itself can meet it.

    /// <summary>A cube of half 0.20 whose +Z face centre (vertex 49: face 5, grid centre) stands out by <paramref name="bump"/>.</summary>
    private static ModelParts Bumped(float bump)
    {
        var cube = Cube(0.20f, SkinMaterial);
        var pos = (float[])cube.Positions.Clone();
        pos[49 * 3 + 2] += bump;
        return Build(pos, cube.Normals, cube.Parts[0].Triangles, SkinMaterial);
    }

    /// <summary>One cloth triangle 1 mm over the +Z face (0.4 mm over a 2.6 mm bump); doubled, back to back, on request.</summary>
    private static ModelParts Sheet(Vector3 a, Vector3 b, Vector3 c, bool doubled = false)
    {
        float[] pos = [a.X, a.Y, a.Z, b.X, b.Y, b.Z, c.X, c.Y, c.Z];
        float[] nrm = [0, 0, 1, 0, 0, 1, 0, 0, 1];
        return Build(pos, nrm, doubled ? [0, 1, 2, 0, 2, 1] : [0, 1, 2], ClothMaterial);
    }

    private const float SheetZ = 0.201f;

    [Fact]
    public void Two_pieces_side_by_side_keep_the_gap_between_them_where_the_body_stretches()
    {
        // Two strips 1 mm over the +Z face, 2 mm apart at x = 0, on a body three times as wide: every point of the face
        // moves by twice its x, so the transfer alone carries the strips' inner edges to x = +-3 mm, a 6 mm gap where
        // the author left 2 — skin through it in game ("Sirius", the corset's top edge over the blouse on YAB+ Large).
        var garment = Strips(0.001f, 0.002f, 15, 10);
        var body = Cube(0.20f, SkinMaterial);
        var wide = Build(body.Positions.Select((p, i) => i % 3 == 0 ? p * 3f : p).ToArray(), body.Normals,
                         body.Parts[0].Triangles, SkinMaterial);

        float Gap(BodyRetarget.Solved s)
        {
            // The two inner edges: the column at x = -0.001 (vertex 0 of each row of A) and x = +0.001 (of B).
            int row = 16, half = row * 11;
            float worst = 0f;
            for (int j = 0; j <= 10; j++)
            {
                int a = j * row, b = half + j * row;
                worst = MathF.Max(worst, (At(garment, b) + Delta(s, b)).X - (At(garment, a) + Delta(s, a)).X);
            }
            return worst;
        }

        float knit = Gap(Solve(garment, body, wide));
        float plain = BodyRetarget.WithTuning(new BodyRetarget.Tuning(NoLayerKnit: true), () => Gap(Solve(garment, body, wide)));

        Assert.True(plain > 0.005f, $"without the layer knit the gap should open with the body, but it is {plain * 1000:F2} mm");
        Assert.True(knit < 0.003f, $"the gap should stay near the 2 mm the author left, but it is {knit * 1000:F2} mm");
    }

    /// <summary>
    /// Two flat strips over the +Z face, mirror images either side of x = 0, their inner edges at +-<paramref name="inner"/>:
    /// each <paramref name="columns"/> x <paramref name="rows"/> quads of <paramref name="step"/>, strip A first, row by
    /// row from its inner edge outward.
    /// </summary>
    private static ModelParts Strips(float inner, float step, int columns, int rows)
    {
        var pos = new List<float>();
        var nrm = new List<float>();
        var tris = new List<int>();
        foreach (float side in new[] { -1f, 1f })
        {
            int baseVertex = pos.Count / 3;
            for (int j = 0; j <= rows; j++)
            for (int i = 0; i <= columns; i++)
            {
                pos.AddRange([side * (inner + i * step), (j - rows / 2f) * step, SheetZ]);
                nrm.AddRange([0f, 0f, 1f]);
            }
            for (int j = 0; j < rows; j++)
            for (int i = 0; i < columns; i++)
            {
                int p00 = baseVertex + j * (columns + 1) + i, p10 = p00 + 1, p01 = p00 + columns + 1, p11 = p01 + 1;
                // Wound to face +Z on both sides.
                if (side > 0) tris.AddRange([p00, p10, p11, p00, p11, p01]);
                else tris.AddRange([p00, p11, p10, p00, p01, p11]);
            }
        }
        return Build(pos.ToArray(), nrm.ToArray(), tris.ToArray(), ClothMaterial);
    }

    [Fact]
    public void Skin_the_refit_puts_through_the_middle_of_a_face_is_pushed_out()
    {
        // Every corner stays clear of the new body; its bump comes 2 mm through the face between them.
        var garment = Sheet(new(-0.15f, -0.15f, SheetZ), new(0.15f, -0.15f, SheetZ), new(0f, 0.15f, SheetZ));
        var solved = Solve(garment, Cube(0.20f, SkinMaterial), Bumped(0.003f));

        Assert.True(solved.Pushed > 0, "the bump is through the face, so its corners should have been pushed");
        var corners = Enumerable.Range(0, 3).Select(v => At(garment, v) + Delta(solved, v)).ToArray();
        var q = BrushTransfer.ClosestOnTriangle(new Vector3(0f, 0f, 0.203f), corners[0], corners[1], corners[2],
                                                out _, out _, out _);
        Assert.True(q.Z >= 0.203f, $"the face still passes under the bump's top, at z={q.Z:F5}");
    }

    /// <summary>
    /// The face test and push of <see cref="BodyRetarget.ClearFaces"/>, set up the way the push-out sets them up: the
    /// garment where it was authored, over <paramref name="source"/> then <paramref name="target"/>.
    /// </summary>
    private static (BodyRetarget.FaceCheck Check, SecondSkinWriter.Vec3[] Delta, BodyRetarget.Sets Sets) FaceSetup(
        ModelParts garment, ModelParts source, ModelParts target)
    {
        Assert.True(IdentityCorrespondence.TryBuild(source, target, "chest", out var built, out string refusal), refusal);
        BodyRetarget.SlotPair[] pairs = [new("_top", built!, target)];
        var sets = BodyRetarget.Sets.From(garment);
        var before = BodyRetarget.TargetBody.Build(pairs, null, null, before: true);
        var after = BodyRetarget.TargetBody.Build(pairs, null, null, before: false);
        var authored = new float[sets.NodeCount];
        Array.Fill(authored, float.MaxValue);
        var check = new BodyRetarget.FaceCheck(sets, sets.ClothNodes, before, after, authored, clearBody: false);
        return (check, new SecondSkinWriter.Vec3[sets.NodeCount], sets);
    }

    [Fact]
    public void Clearing_faces_lifts_a_face_the_skin_is_still_through()
    {
        // What the push-out's fold guard leaves behind: every corner clear, the bump 0.8 mm through the middle.
        var garment = Sheet(new(-0.15f, -0.15f, SheetZ), new(0.15f, -0.15f, SheetZ), new(0f, 0.15f, SheetZ));
        var (check, delta, sets) = FaceSetup(garment, Cube(0.20f, SkinMaterial), Bumped(SagBump));
        Assert.True(check.Need(check.Faces[0], delta).Push > 0f, "the bump should start out through the face");

        float worst = 0f;
        int pushed = BodyRetarget.ClearFaces(check, delta, new float[sets.NodeCount], ref worst);

        Assert.Equal(3, pushed);
        Assert.Equal(0f, check.Need(check.Faces[0], delta, 1e-4f).Push);
        var corners = Enumerable.Range(0, 3).Select(v =>
        {
            var d = delta[sets.NodeOf[v]];
            return At(garment, v) + new Vector3(d.X, d.Y, d.Z);
        }).ToArray();
        const float top = 0.20f + SagBump;
        var q = BrushTransfer.ClosestOnTriangle(new Vector3(0f, 0f, top), corners[0], corners[1], corners[2],
                                                out _, out _, out _);
        Assert.True(q.Z >= top, $"the face still passes under the bump's top, at z={q.Z:F5}");
    }

    /// <summary>A bump on the cube's +Z face that comes 0.8 mm through a <see cref="Sheet"/>: sag, which
    /// <see cref="BodyRetarget.ClearFaces"/> clears (it asks 1.8 mm, under <see cref="BodyRetarget.ClearFaceDeepest"/>).</summary>
    private const float SagBump = 0.0018f;

    [Fact]
    public void Clearing_faces_leaves_a_face_the_skin_is_deep_through()
    {
        // 3 mm through is not sag. On a corset it was the breast bulging over the top edge, read as through the rim's
        // faces, and chasing it pushed the rim out 20 mm: the jagged top edge of the cups.
        var garment = Sheet(new(-0.15f, -0.15f, SheetZ), new(0.15f, -0.15f, SheetZ), new(0f, 0.15f, SheetZ));
        var (check, delta, sets) = FaceSetup(garment, Cube(0.20f, SkinMaterial), Bumped(0.004f));
        Assert.True(check.Need(check.Faces[0], delta).Push > BodyRetarget.ClearFaceDeepest);

        float worst = 0f;
        Assert.Equal(0, BodyRetarget.ClearFaces(check, delta, new float[sets.NodeCount], ref worst));
        Assert.All(delta, d => Assert.Equal(default, d));
    }

    [Fact]
    public void Clearing_faces_never_turns_a_neighbour_over()
    {
        // The same face, with a pleat standing 1 mm up off its near edge and leaning 0.5 mm out past it. Lifting the
        // edge's two corners the 1.8 mm the face needs takes them above the pleat's top and tips it onto its back,
        // which draws black: the face has to stay through rather than fold its neighbour.
        float[] pos =
        [
            -0.15f, -0.15f, SheetZ, 0.15f, -0.15f, SheetZ, 0f, 0.15f, SheetZ,
            0f, -0.1505f, SheetZ + 0.001f,
        ];
        float[] nrm = [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, -1, 0];
        var garment = Build(pos, nrm, [0, 1, 2, 1, 0, 3], ClothMaterial);
        var (check, delta, sets) = FaceSetup(garment, Cube(0.20f, SkinMaterial), Bumped(SagBump));

        float worst = 0f;
        BodyRetarget.ClearFaces(check, delta, new float[sets.NodeCount], ref worst);

        Assert.Equal(0, Folded(garment, delta, sets));
        Assert.Equal(default, delta[sets.NodeOf[0]]);
        Assert.Equal(default, delta[sets.NodeOf[1]]);
    }

    [Fact]
    public void Clearing_faces_never_pushes_a_lining_through_its_shell()
    {
        // A lining with the bump 0.8 mm through it, and a shell 1.5 mm over the lining, clear of the bump itself.
        // Clearing the lining's face takes its corners 1.8 mm out, straight through the shell — which in game is the
        // lining poking through the outside of the garment. The skin through a lining the shell covers was never seen;
        // it stays.
        const float shellZ = SheetZ + 0.0015f;
        float[] pos =
        [
            -0.15f, -0.15f, SheetZ, 0.15f, -0.15f, SheetZ, 0f, 0.15f, SheetZ,
            -0.18f, -0.18f, shellZ, 0.18f, -0.18f, shellZ, 0f, 0.18f, shellZ,
        ];
        float[] nrm = [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1];
        var garment = Build(pos, nrm, [0, 1, 2, 3, 4, 5], ClothMaterial);
        var (check, delta, sets) = FaceSetup(garment, Cube(0.20f, SkinMaterial), Bumped(SagBump));

        float worst = 0f;
        BodyRetarget.ClearFaces(check, delta, new float[sets.NodeCount], ref worst);

        for (int v = 3; v < 6; v++) Assert.Equal(default, delta[sets.NodeOf[v]]);   // the shell is clear: never moved
        for (int v = 0; v < 3; v++)
        {
            float z = At(garment, v).Z + delta[sets.NodeOf[v]].Z;
            Assert.True(z < shellZ, $"lining corner {v} went through the shell, to z={z:F5}");
        }

        // And it is the guard that holds it: without it the lining does go through.
        var (check2, delta2, sets2) = FaceSetup(garment, Cube(0.20f, SkinMaterial), Bumped(SagBump));
        BodyRetarget.WithTuning(new BodyRetarget.Tuning(NoLayerGuard: true),
            () => BodyRetarget.ClearFaces(check2, delta2, new float[sets2.NodeCount], ref worst));
        Assert.Contains(Enumerable.Range(0, 3), v => At(garment, v).Z + delta2[sets2.NodeOf[v]].Z > shellZ);
    }

    [Fact]
    public void Clearing_faces_leaves_what_it_is_told_to_keep()
    {
        var garment = Sheet(new(-0.15f, -0.15f, SheetZ), new(0.15f, -0.15f, SheetZ), new(0f, 0.15f, SheetZ));
        var (check, delta, sets) = FaceSetup(garment, Cube(0.20f, SkinMaterial), Bumped(SagBump));
        var stay = new bool[sets.NodeCount];
        stay[sets.NodeOf[2]] = true;

        float worst = 0f;
        BodyRetarget.ClearFaces(check, delta, new float[sets.NodeCount], ref worst, stay);

        Assert.Equal(default, delta[sets.NodeOf[2]]);
        Assert.True(delta[sets.NodeOf[0]].Z > 0f, "the corners it may move should still have been lifted");
    }

    [Fact]
    public void A_face_resting_close_over_skin_the_refit_left_alone_is_not_pushed()
    {
        // The bump on both bodies: the face's middle sits 0.4 mm over it as authored and after. Close, not through, and
        // not the refit's doing — nothing moves.
        var garment = Sheet(new(-0.15f, -0.15f, SheetZ + 0.002f), new(0.15f, -0.15f, SheetZ + 0.002f),
                            new(0f, 0.15f, SheetZ + 0.002f));
        var solved = Solve(garment, Bumped(0.0026f), Bumped(0.0026f));

        Assert.Equal(0, solved.Pushed);
    }

    [Fact]
    public void Skin_past_a_doubled_hem_is_not_through_it()
    {
        // The face stops 5 mm short of the new bump: a hem, with the body going on wider past it, like a thigh above a
        // stocking. Drawn double-sided, the hem's edge is used by two triangles — the same face twice, not two faces.
        var garment = Sheet(new(-0.15f, -0.005f, SheetZ), new(0.15f, -0.005f, SheetZ), new(0f, -0.15f, SheetZ),
                            doubled: true);
        var solved = Solve(garment, Cube(0.20f, SkinMaterial), Bumped(0.003f));

        Assert.Equal(0, solved.Pushed);
    }

    [Fact]
    public void The_push_moves_along_the_body_normal()
    {
        // B's face that swallowed the patch faces -X, so the patch must move towards -X. Aiming along
        // (p - landing) instead would drive an interior point further in, and this fails outright then.
        var (garment, pairs) = CreatedClip(ClothMaterial);

        var solved = BodyRetarget.Solve(garment, pairs);

        var d = Delta(solved, 0);
        Assert.True(d.X < 0f, $"the push went the wrong way: {d}");
    }

    [Fact]
    public void Push_out_leaves_an_unsnapped_skin_vertex_alone()
    {
        // The SKIN exclusion, which is a different rule from the snap one. The garment's own body mesh is itself one of
        // the drawn surfaces, so a skin node always reads as ON the skin and is never pushed for its own sake — but the
        // slope-limited spread lifts every node towards its neighbours' push, so body mesh beside a genuine cloth clip
        // would be peeled off the body it must coincide with. Only membership of the cloth set stops that. This skin
        // is sculpted rather than copied, 10 mm off any body vertex, so the snap cannot be what protects it.
        var (_, pairs) = CreatedClip(ClothMaterial);

        // Cloth: a clip patch in the gap (0-2), joined by an edge to vertex 3. Skin: a small patch (3-5) tucked 10 mm
        // inside body A, far enough from the clip that the clip's own before/after reading is unaffected by it.
        var pos = new List<float>
        {
            0.228f, -0.002f, 0f,
            0.232f, -0.002f, 0f,
            0.230f,  0.002f, 0f,
            0.190f,  0.001f, 0f,
            0.190f,  0.003f, 0f,
            0.192f,  0.002f, 0f,
        };
        var filler = new List<int>();
        for (int i = 0; i < 40; i++)
        {
            int b = pos.Count / 3;
            float x = 5f + i * 0.01f;
            pos.AddRange([x, 5f, 5f, x + 0.001f, 5f, 5f, x, 5.001f, 5f]);
            filler.AddRange([b, b + 1, b + 2]);
        }
        var nrm = new float[pos.Count];
        for (int i = 0; i < nrm.Length; i += 3) nrm[i + 2] = 1f;

        int[] cloth = [0, 1, 2, 0, 2, 3, .. filler];
        int[] skin = [3, 4, 5];
        var garment = BuildTwoPart(pos.ToArray(), nrm, cloth, ClothMaterial, skin, SkinMaterial);

        var solved = BodyRetarget.Solve(garment, pairs);

        Assert.True(Delta(solved, 0).Length() > 0f, "the clip beside it should have been pushed, or this proves nothing");
        for (int v = 3; v <= 5; v++)
            Assert.Equal(0f, Delta(solved, v).Length(), 6);
    }

    [Fact]
    public void Cloth_the_author_put_inside_the_skin_is_left_there()
    {
        // The third exclusion, and the one that decides whether the push-out helps at all. Authors leave the whole
        // body mesh under the fabric where it is hidden, so cloth behind a skin surface is usually AUTHORED. Measured on
        // a real outfit, pushing it made the refit 30% worse against the author's own hand-fitted size. Here source
        // and target are the same body, so nothing about the refit put this cloth inside — the author did.
        var body = Cube(0.20f, SkinMaterial);
        var garment = Patch(ClothMaterial, new Vector3(0f, 0f, 0.19f));

        var solved = Solve(garment, body, body);

        Assert.Equal(0, solved.Pushed);
        for (int v = 0; v < garment.Positions.Length / 3; v++)
            Assert.Equal(0f, Delta(solved, v).Length(), 6);
    }

    [Fact]
    public void A_held_point_beside_a_moving_one_stays_exactly_where_it_was()
    {
        // Holding is absolute: neither pass moves a held node. The knit that closes tears averages a node toward its
        // neighbours, and run over every node it moved held ones too — the hold then slipped at exactly the seam it is
        // there to hold, where a held part meets a moving one.
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);
        var garment = Patch(ClothMaterial, new Vector3(0f, 0f, 0.21f));

        Assert.True(IdentityCorrespondence.TryBuild(source, target, "chest", out var built, out string refusal), refusal);
        var pairs = new[] { new BodyRetarget.SlotPair("_top", built!, target) };

        // One corner of the patch held, the other two free: the free ones move and the held one may not follow.
        var solved = BodyRetarget.Solve(garment, pairs, held: new HashSet<int> { 0 });

        Assert.Equal(0f, Delta(solved, 0).Length(), 6);
        Assert.True(Delta(solved, 1).Length() > 1e-4f, "the unheld corners should still have moved");
    }

    [Fact]
    public void Clearing_the_body_pulls_out_cloth_the_author_buried()
    {
        // "Push the garment clear of the body", for the garment the rule above is wrong for: one whose mod draws its
        // own skin over yours, where cloth the author buried is no longer hidden by anything and shows as the body
        // through the fabric. Same setup as the test above, where nothing the refit did put this cloth inside.
        var body = Cube(0.20f, SkinMaterial);
        // Four millimetres under the surface: shallow enough to be a clip rather than the garment's own structure.
        var garment = Patch(ClothMaterial, new Vector3(0f, 0f, 0.196f));

        var solved = Solve(garment, body, body, clearBody: true);

        Assert.True(solved.Pushed > 0, "asked to clear the body, the pass should have pulled this cloth out of it");
        for (int v = 0; v < garment.Positions.Length / 3; v++)
        {
            float z = At(garment, v).Z + Delta(solved, v).Z;
            Assert.True(z >= 0.20f, $"vertex {v} is still inside the body at z={z}");
        }
    }

    [Fact]
    public void A_legs_waist_inside_the_chest_body_is_pulled_out_of_it()
    {
        // Over the belly the skin drawn is the worn TOP's own body mesh, which its author sculpts — so a legs garment's
        // waist inside the body mod's plain chest says nothing about what its author meant. "Victoria's Secret Sauce":
        // the waist sat 4 mm inside Bibo+'s chest, fitted to a top that pulls the belly in; refitted, the top took the
        // new body's full belly and the waist stayed inside it. A top's hem inside the LEGS body keeps the rule.
        var body = Cube(0.20f, SkinMaterial);
        var garment = Patch(ClothMaterial, new Vector3(0f, 0f, 0.196f));
        Assert.True(IdentityCorrespondence.TryBuild(body, body, "chest", out var built, out string refusal), refusal);

        var legs = BodyRetarget.Solve(garment, [new BodyRetarget.SlotPair("_top", built!, body)], garmentSlot: "_dwn");
        Assert.True(legs.Pushed > 0, "a legs garment's waist inside the chest body should have been pulled out");
        for (int v = 0; v < garment.Positions.Length / 3; v++)
        {
            float z = At(garment, v).Z + Delta(legs, v).Z;
            Assert.True(z >= 0.20f, $"vertex {v} is still inside the chest at z={z}");
        }

        var top = BodyRetarget.Solve(garment, [new BodyRetarget.SlotPair("_dwn", built!, body)], garmentSlot: "_top");
        Assert.Equal(0, top.Pushed);
    }

    // ── folds: a triangle that ends up facing the wrong way is a black speck in game ───────────────

    [Fact]
    public void A_triangle_the_transfer_turns_over_is_relaxed_back()
    {
        // The refit moves neighbouring points by different amounts, and where the two bodies disagree sharply enough
        // one point crosses the edge opposite it: the triangle is then drawn from behind, which on cloth is black.
        // The delta here is hand-made, so the test is about the pass and not about any body pair reaching it.
        var quad = Quad(0.01f);
        var sets = BodyRetarget.Sets.From(quad);

        // Corner 1 dragged clear across the diagonal between 0 and 2, which turns the first triangle over.
        var delta = new SecondSkinWriter.Vec3[sets.NodeCount];
        delta[sets.NodeOf[1]] = new SecondSkinWriter.Vec3(-0.02f, 0.02f, 0f);
        Assert.True(Folded(quad, delta, sets) > 0, "the hand-made delta should have turned a triangle over");

        int left = BodyRetarget.Unfold(sets, delta, new bool[sets.NodeCount]);

        Assert.Equal(0, left);
        Assert.Equal(0, Folded(quad, delta, sets));
    }

    [Fact]
    public void A_fold_between_two_exact_landings_is_taken_out_as_well()
    {
        // Points the transfer landed exactly are the answer, so the pass leaves them alone — until a fold survives
        // the rounds that respect them. Two exact landings that crossed each other are no answer at all, and holding
        // both while only the cloth beside them moves cannot undo it.
        var quad = Quad(0.01f);
        var sets = BodyRetarget.Sets.From(quad);
        var delta = new SecondSkinWriter.Vec3[sets.NodeCount];
        delta[sets.NodeOf[1]] = new SecondSkinWriter.Vec3(-0.02f, 0.02f, 0f);

        var snapped = new bool[sets.NodeCount];
        for (int n = 0; n < sets.NodeCount; n++) snapped[n] = true;

        Assert.Equal(0, BodyRetarget.Unfold(sets, delta, snapped));
        Assert.Equal(0, Folded(quad, delta, sets));
    }

    /// <summary>
    /// A fold the give-up cannot reach — its corner is the skin's, which may not be pulled back off the body — must
    /// not cost the cloth around it its movement: given up toward nothing, those corners land where the author put
    /// them on the OLD body while the points they are welded to keep the full displacement, which is the tear the pass
    /// exists to close, now in a place nothing was wrong.
    /// </summary>
    [Fact]
    public void A_fold_held_by_the_skin_does_not_cost_the_cloth_its_movement()
    {
        var quad = Quad(0.01f);
        var sets = BodyRetarget.Sets.From(quad);

        // Corner 1 across the diagonal turns the first triangle over, and corner 1 is the skin's.
        var delta = new SecondSkinWriter.Vec3[sets.NodeCount];
        delta[sets.NodeOf[1]] = new SecondSkinWriter.Vec3(-0.02f, 0.02f, 0f);
        // The cloth around it moved too — a body-size displacement, nothing to do with the fold.
        foreach (int v in new[] { 0, 2, 3 })
            delta[sets.NodeOf[v]] = new SecondSkinWriter.Vec3(0f, 0f, 0.004f);

        var isSkin = new bool[sets.NodeCount];
        isSkin[sets.NodeOf[1]] = true;
        var flagged = new bool[sets.NodeCount];
        int before = FoldedVia(quad, delta, sets, flagged);
        Assert.True(before > 0, "the hand-made delta should have turned a triangle over");

        int left = BodyRetarget.GiveUpFolds(sets, delta, isSkin, flagged, before);

        // It cannot be cleared — and it must not be made worse trying.
        Assert.True(left <= before, $"the give-up left {left} folds where the relax had {before}");

        // Every cloth corner keeps most of the movement it shares with the others. Toward nothing it keeps 0.5^64.
        foreach (int v in new[] { 0, 2, 3 })
            Assert.True(delta[sets.NodeOf[v]].Z >= 0.002f,
                $"cloth corner {v} kept {delta[sets.NodeOf[v]].Z:0.#######} of 0.004");
    }

    /// <summary>
    /// A fold on cloth that moved a long way with the body gives up the corners' DISAGREEMENT, not the move they share.
    /// Reported on "Picklish" refitted Neolithe L to YAB L: the whole band under the bust was scaled back toward where
    /// the author put it on the old body, and came out up to 26 mm inside the new, lower breasts.
    /// </summary>
    [Fact]
    public void Giving_up_a_fold_keeps_the_body_size_move()
    {
        var quad = Quad(0.01f);
        var sets = BodyRetarget.Sets.From(quad);

        // Every corner carried 30 mm out with the body; corner 1 also dragged across the diagonal, which folds.
        var delta = new SecondSkinWriter.Vec3[sets.NodeCount];
        for (int v = 0; v < 4; v++) delta[sets.NodeOf[v]] = new SecondSkinWriter.Vec3(0f, 0f, 0.03f);
        delta[sets.NodeOf[1]] = new SecondSkinWriter.Vec3(-0.02f, 0.02f, 0.03f);

        var flagged = new bool[sets.NodeCount];
        int before = FoldedVia(quad, delta, sets, flagged);
        Assert.True(before > 0, "the hand-made delta should have turned a triangle over");

        Assert.Equal(0, BodyRetarget.GiveUpFolds(sets, delta, new bool[sets.NodeCount], flagged, before));
        for (int v = 0; v < 4; v++)
            Assert.True(delta[sets.NodeOf[v]].Z > 0.029f, $"corner {v} kept {delta[sets.NodeOf[v]].Z * 1000:F1} mm of 30");
    }

    /// <summary>
    /// A held corner of a fold stays where the user left it. The give-up takes a corner toward the movement around it,
    /// and a held point's own movement is none, so without the hold it is dragged after its moving neighbours.
    /// </summary>
    [Fact]
    public void Giving_up_a_fold_never_moves_a_held_point()
    {
        var quad = Quad(0.01f);
        var sets = BodyRetarget.Sets.From(quad, new HashSet<int> { 0 });
        Assert.Equal(1, sets.HeldCount);

        // Corner 1 across the diagonal folds triangle 0-1-2, whose corner 0 is held.
        var delta = new SecondSkinWriter.Vec3[sets.NodeCount];
        delta[sets.NodeOf[1]] = new SecondSkinWriter.Vec3(-0.02f, 0.02f, 0.01f);
        delta[sets.NodeOf[2]] = new SecondSkinWriter.Vec3(0f, 0f, 0.01f);
        delta[sets.NodeOf[3]] = new SecondSkinWriter.Vec3(0f, 0f, 0.01f);
        var flagged = new bool[sets.NodeCount];
        int before = FoldedVia(quad, delta, sets, flagged);
        Assert.True(flagged[sets.NodeOf[0]], "the held corner should be a corner of the fold");

        var fixedNode = BodyRetarget.GiveUpFixed(sets, new bool[sets.NodeCount]);
        Assert.True(fixedNode[sets.NodeOf[0]], "a held node is not the give-up's to move");
        BodyRetarget.GiveUpFolds(sets, delta, fixedNode, flagged, before);

        Assert.Equal(default, delta[sets.NodeOf[0]]);
    }

    /// <summary>
    /// A corner the next step would bury in the skin keeps the step it has, and its fold stays: a black speck is a
    /// smaller fault than cloth the skin comes through, and nothing after this pass would push it back out.
    /// </summary>
    [Fact]
    public void A_fold_is_not_given_up_into_the_skin()
    {
        var quad = Quad(0.01f);
        var sets = BodyRetarget.Sets.From(quad);
        var delta = new SecondSkinWriter.Vec3[sets.NodeCount];
        delta[sets.NodeOf[1]] = new SecondSkinWriter.Vec3(-0.02f, 0.02f, 0f);
        var was = (SecondSkinWriter.Vec3[])delta.Clone();

        var flagged = new bool[sets.NodeCount];
        int before = FoldedVia(quad, delta, sets, flagged);

        // Every step the give-up could take would bury its corner.
        int left = BodyRetarget.GiveUpFolds(sets, delta, new bool[sets.NodeCount], flagged, before, (_, _) => false);

        Assert.Equal(before, left);
        Assert.Equal(was, delta);
    }

    /// <summary>
    /// A fold whose corners are all the refit's own still clears outright: at zero the triangle is the authored one.
    /// The floor must not have bought safety at the price of the thing the pass is for.
    /// </summary>
    [Fact]
    public void A_fold_the_give_up_can_reach_is_still_cleared()
    {
        var quad = Quad(0.01f);
        var sets = BodyRetarget.Sets.From(quad);
        var delta = new SecondSkinWriter.Vec3[sets.NodeCount];
        delta[sets.NodeOf[1]] = new SecondSkinWriter.Vec3(-0.02f, 0.02f, 0f);

        var flagged = new bool[sets.NodeCount];
        int before = FoldedVia(quad, delta, sets, flagged);

        Assert.Equal(0, BodyRetarget.GiveUpFolds(sets, delta, new bool[sets.NodeCount], flagged, before));
        Assert.Equal(0, Folded(quad, delta, sets));
    }

    /// <summary>Count the folds AND fill <paramref name="flagged"/> the way the relax hands them over.</summary>
    private static int FoldedVia(ModelParts m, SecondSkinWriter.Vec3[] delta, BodyRetarget.Sets sets, bool[] flagged)
    {
        int folded = 0;
        foreach (var part in m.Parts)
            for (int t = 0; t + 2 < part.Triangles.Length; t += 3)
            {
                int a = part.Triangles[t], b = part.Triangles[t + 1], c = part.Triangles[t + 2];
                Vector3 Moved(int v)
                {
                    var d = delta[sets.NodeOf[v]];
                    return At(m, v) + new Vector3(d.X, d.Y, d.Z);
                }
                var n0 = Vector3.Cross(At(m, b) - At(m, a), At(m, c) - At(m, a));
                var n1 = Vector3.Cross(Moved(b) - Moved(a), Moved(c) - Moved(a));
                if (Vector3.Dot(n0, n1) >= 0f) continue;
                folded++;
                flagged[sets.NodeOf[a]] = flagged[sets.NodeOf[b]] = flagged[sets.NodeOf[c]] = true;
            }
        return folded;
    }

    [Fact]
    public void Cloth_welded_to_skin_that_is_swapped_out_is_cloth()
    {
        // A hem whose corner the author welded to the skin under it, as the Pioneer's Bottoms' is to its vanilla strip:
        // one skin triangle and one cloth triangle sharing a point. Fused, the hem's corner was skin — laid flat onto the
        // new body and never pushed out — though the skin it was fused to is thrown away by the swap.
        float[] pos = [0f, 0f, 0f, 0.01f, 0f, 0f, 0f, 0.01f, 0f,
                       0.01f, 0f, 0f, 0.02f, 0f, 0f, 0.02f, 0.01f, 0f];
        float[] nrm = [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1];
        var garment = BuildTwoPart(pos, nrm, [0, 1, 2], SkinMaterial, [3, 4, 5], ClothMaterial);

        var kept = BodyRetarget.Sets.From(garment);
        Assert.Equal(kept.NodeOf[1], kept.NodeOf[3]);
        Assert.Contains(kept.NodeOf[3], kept.SkinNodes);

        var apart = BodyRetarget.Sets.From(garment, swappedSkin: new HashSet<int> { 0 });
        Assert.NotEqual(apart.NodeOf[1], apart.NodeOf[3]);
        Assert.Contains(apart.NodeOf[1], apart.SkinNodes);
        Assert.Contains(apart.NodeOf[3], apart.ClothNodes);
    }

    [Fact]
    public void Cloth_welded_to_skin_the_swap_keeps_stays_welded()
    {
        // The same weld, but the skin mesh is one the swap leaves in (a heeled shoe's foot, a slot nobody resizes):
        // parted from it, the cloth would be pushed out and the seam to that skin would open.
        float[] pos = [0f, 0f, 0f, 0.01f, 0f, 0f, 0f, 0.01f, 0f,
                       0.01f, 0f, 0f, 0.02f, 0f, 0f, 0.02f, 0.01f, 0f];
        float[] nrm = [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1];
        var garment = BuildTwoPart(pos, nrm, [0, 1, 2], SkinMaterial, [3, 4, 5], ClothMaterial);

        // Another mesh is swapped; this skin (mesh 0) is not.
        var sets = BodyRetarget.Sets.From(garment, swappedSkin: new HashSet<int> { 1 });
        Assert.Equal(sets.NodeOf[1], sets.NodeOf[3]);
        Assert.Contains(sets.NodeOf[3], sets.SkinNodes);
    }

    /// <summary>A flat two-triangle quad of side <paramref name="side"/> in the XY plane, facing +Z.</summary>
    private static ModelParts Quad(float side)
    {
        float[] pos = [0f, 0f, 0f, side, 0f, 0f, side, side, 0f, 0f, side, 0f];
        float[] nrm = [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1];
        return Build(pos, nrm, [0, 1, 2, 0, 2, 3], ClothMaterial);
    }

    /// <summary>Triangles of <paramref name="m"/> that the delta turns over.</summary>
    private static int Folded(ModelParts m, SecondSkinWriter.Vec3[] delta, BodyRetarget.Sets sets)
    {
        Vector3 Moved(int v)
        {
            var d = delta[sets.NodeOf[v]];
            return At(m, v) + new Vector3(d.X, d.Y, d.Z);
        }

        int folded = 0;
        foreach (var part in m.Parts)
            for (int t = 0; t + 2 < part.Triangles.Length; t += 3)
            {
                int a = part.Triangles[t], b = part.Triangles[t + 1], c = part.Triangles[t + 2];
                var n0 = Vector3.Cross(At(m, b) - At(m, a), At(m, c) - At(m, a));
                var n1 = Vector3.Cross(Moved(b) - Moved(a), Moved(c) - Moved(a));
                if (Vector3.Dot(n0, n1) < 0f) folded++;
            }
        return folded;
    }

    [Fact]
    [Trait("Plan", "EDGE-vanilla-refit-cut-skin-7")]
    public void Clearing_the_body_leaves_cloth_buried_deeply_alone()
    {
        // Deeper than ClearDepth is the garment's own structure — an inner layer, a sole — and hauling it to the
        // surface tears the mesh without uncovering anything. Measured on a stocking: 17,212 nodes moved up to 30 mm
        // and edges grown by 54 mm, with the body still showing through.
        var body = Cube(0.20f, SkinMaterial);
        var garment = Patch(ClothMaterial, new Vector3(0f, 0f, 0.20f - BodyRetarget.ClearDepth - 0.005f));

        var solved = Solve(garment, body, body, clearBody: true);

        Assert.Equal(0, solved.Pushed);
    }

    [Fact]
    public void Hidden_cloth_beside_a_fresh_clip_is_not_dragged_out()
    {
        // What the explicit authored-inside exclusion does that the push amount alone does not. A node is only ever
        // pushed back to its OWN authored standoff, and a hidden node's is negative, so on its own it never moves — but
        // the slope-limited spread lifts every node towards its neighbours' push. Hidden cloth sitting beside a genuine
        // clip would be dragged out with it, which is the thing measured to hurt. Only set membership stops that.
        var (_, pairs) = CreatedClip(ClothMaterial);

        // A clip patch in the gap (vertices 0-2), joined by an edge to vertex 3, which the author tucked 2 mm inside body
        // A's +X face. Tiny far-off triangles keep the mesh's mean edge short, so the spread reaches vertex 3 in one hop.
        var pos = new List<float>
        {
            0.228f, -0.002f, 0f,
            0.232f, -0.002f, 0f,
            0.230f,  0.002f, 0f,
            0.198f,  0f,     0f,
        };
        var tris = new List<int> { 0, 1, 2, 0, 2, 3 };
        for (int i = 0; i < 40; i++)
        {
            int b = pos.Count / 3;
            float x = 5f + i * 0.01f;
            pos.AddRange([x, 5f, 5f, x + 0.001f, 5f, 5f, x, 5.001f, 5f]);
            tris.AddRange([b, b + 1, b + 2]);
        }
        var nrm = new float[pos.Count];
        for (int i = 0; i < nrm.Length; i += 3) nrm[i + 2] = 1f;
        var garment = Build(pos.ToArray(), nrm, tris.ToArray(), ClothMaterial);

        var solved = BodyRetarget.Solve(garment, pairs);

        Assert.True(Delta(solved, 0).Length() > 0f, "the clip beside it should have been pushed, or this proves nothing");
        Assert.Equal(0f, Delta(solved, 3).Length(), 6);
    }

    [Fact]
    public void Snapped_cloth_vertices_are_not_pushed()
    {
        // A CLOTH vertex sitting exactly on a body vertex is snapped, and lands exactly on that vertex of the new body.
        // The push amount alone would leave it there — it is on the surface, not in it — but the slope-limited spread
        // lifts every node towards its neighbours' push, so cloth lying on the skin beside a genuine clip would be
        // peeled off it. Only set membership stops that; the snap is also the one place float noise could put a node
        // 1e-8 m either side of a surface, where no inside test can be trusted.
        var (_, pairs) = CreatedClip(ClothMaterial);

        // A clip patch in the gap (vertices 0-2), joined by an edge to vertex 3, which sits exactly on the centre vertex
        // of body A's +X face. Tiny far-off triangles keep the mean edge short, so the spread reaches it in one hop.
        var pos = new List<float>
        {
            0.228f, -0.002f, 0f,
            0.232f, -0.002f, 0f,
            0.230f,  0.002f, 0f,
            0.200f,  0f,     0f,
        };
        var tris = new List<int> { 0, 1, 2, 0, 2, 3 };
        for (int i = 0; i < 40; i++)
        {
            int b = pos.Count / 3;
            float x = 5f + i * 0.01f;
            pos.AddRange([x, 5f, 5f, x + 0.001f, 5f, 5f, x, 5.001f, 5f]);
            tris.AddRange([b, b + 1, b + 2]);
        }
        var nrm = new float[pos.Count];
        for (int i = 0; i < nrm.Length; i += 3) nrm[i + 2] = 1f;
        var garment = Build(pos.ToArray(), nrm, tris.ToArray(), ClothMaterial);

        var solved = BodyRetarget.Solve(garment, pairs);

        Assert.True(solved.Snapped >= 1, "vertex 3 sits on a body vertex, so it should have snapped");
        Assert.True(Delta(solved, 0).Length() > 0f, "the clip beside it should have been pushed, or this proves nothing");
        Assert.Equal(0f, Delta(solved, 3).Length(), 6);
    }

    // ── held parts: unticked in the Studio's list ───────────────────────────────────────────────────────

    [Fact]
    public void A_held_part_stays_exactly_where_the_author_put_it()
    {
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);
        var garment = Patch(ClothMaterial, new Vector3(0f, 0f, 0.21f));

        var free = Solve(garment, source, target);
        Assert.True(Delta(free, 0).Length() > 0.01f, "unheld, this patch follows the growing body");

        var held = SolveHeld(garment, source, target, [0, 1, 2]);
        Assert.Equal(3, held.Held);
        for (int v = 0; v < 3; v++) Assert.Equal(0f, Delta(held, v).Length());
    }

    [Fact]
    public void A_held_skin_part_is_held_too()
    {
        // The brush never moves skin, so it offers no skin lock; the refit does move skin, so holding it has to work.
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);
        var garment = Copy(source, SkinMaterial);

        var solved = SolveHeld(garment, source, target, Enumerable.Range(0, garment.Positions.Length / 3));

        for (int v = 0; v < garment.Positions.Length / 3; v++) Assert.Equal(0f, Delta(solved, v).Length());
    }

    [Fact]
    public void A_point_shared_by_a_held_part_and_a_moving_one_is_held()
    {
        // Held per welded node, as the brush holds: vertex 3 sits exactly on vertex 0 (a uv seam between two parts).
        // If one copy moved and the other did not, the surface would crack open along the join.
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);
        var garment = Points(ClothMaterial,
                             new Vector3(0f, 0f, 0.21f), new Vector3(0.01f, 0f, 0.21f), new Vector3(0f, 0.01f, 0.21f),
                             new Vector3(0f, 0f, 0.21f));

        var solved = SolveHeld(garment, source, target, [0]);

        Assert.Equal(0f, Delta(solved, 0).Length());
        Assert.Equal(0f, Delta(solved, 3).Length());
        Assert.True(Delta(solved, 1).Length() > 0.01f, "the part that is not held still follows the body");
    }

    [Fact]
    public void A_held_part_is_not_dragged_by_a_neighbouring_push()
    {
        // The push-out spreads each push to its neighbours so it has no step; a held part beside a genuine clip must
        // not be lifted by that spread. The same scenario as the snapped and hidden-cloth tests, with vertex 3 held.
        var (_, pairs) = CreatedClip(ClothMaterial);
        var pos = new List<float>
        {
            0.228f, -0.002f, 0f,
            0.232f, -0.002f, 0f,
            0.230f,  0.002f, 0f,
            0.205f,  0f,     0f,
        };
        var tris = new List<int> { 0, 1, 2, 0, 2, 3 };
        for (int i = 0; i < 40; i++)
        {
            int b = pos.Count / 3;
            float x = 5f + i * 0.01f;
            pos.AddRange([x, 5f, 5f, x + 0.001f, 5f, 5f, x, 5.001f, 5f]);
            tris.AddRange([b, b + 1, b + 2]);
        }
        var nrm = new float[pos.Count];
        for (int i = 0; i < nrm.Length; i += 3) nrm[i + 2] = 1f;
        var garment = Build(pos.ToArray(), nrm, tris.ToArray(), ClothMaterial);

        var solved = BodyRetarget.Solve(garment, pairs, held: new HashSet<int> { 3 });

        Assert.True(Delta(solved, 0).Length() > 0f, "the clip beside it should have been pushed, or this proves nothing");
        Assert.Equal(0f, Delta(solved, 3).Length());
    }

    // ── replacing the skin: laying the garment's body mesh onto the new body ───────────────────────────

    [Fact]
    public void Replacing_the_skin_lays_sculpted_skin_onto_the_new_body()
    {
        // The author sculpted this skin 10 mm under the body's surface (a top pressing the chest). Resizing keeps that;
        // replacing lays it exactly on the new body. Its normals are the author's either way — see
        // The_refit_never_touches_the_author_s_normals.
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);
        var garment = Patch(SkinMaterial, new Vector3(0.01f, 0.01f, 0.19f));
        Assert.True(IdentityCorrespondence.TryBuild(source, target, "chest", out var built, out _));
        var pairs = new List<BodyRetarget.SlotPair> { new("_top", built!, target) };

        var resized = BodyRetarget.Solve(garment, pairs);
        var replaced = BodyRetarget.Solve(garment, pairs, replaceSkin: true);

        for (int v = 0; v < 3; v++)
        {
            float keptOffset = 0.25f - (At(garment, v) + Delta(resized, v)).Z;
            Assert.True(MathF.Abs(keptOffset - 0.01f) < 1e-4f, $"resizing should keep the 10 mm; it kept {keptOffset}");

            var laid = At(garment, v) + Delta(replaced, v);
            Assert.True(MathF.Abs(laid.Z - 0.25f) < 1e-5f, $"vertex {v} should sit on the new body's face, is at z={laid.Z}");
        }
        Assert.Equal(3, replaced.Laid);
    }

    [Fact]
    public void Replacing_the_skin_leaves_cloth_and_held_skin_alone()
    {
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);
        Assert.True(IdentityCorrespondence.TryBuild(source, target, "chest", out var built, out _));
        var pairs = new List<BodyRetarget.SlotPair> { new("_top", built!, target) };

        // Cloth: laying is for skin only; cloth keeps the transfer's answer either way.
        var cloth = Patch(ClothMaterial, new Vector3(0.01f, 0.01f, 0.21f));
        var a = BodyRetarget.Solve(cloth, pairs);
        var b = BodyRetarget.Solve(cloth, pairs, replaceSkin: true);
        for (int v = 0; v < 3; v++) Assert.Equal(Delta(a, v), Delta(b, v));
        Assert.Equal(0, b.Laid);

        // Held skin: the user asked for it to stay put, and laying must respect that like every other pass.
        var skin = Patch(SkinMaterial, new Vector3(0.01f, 0.01f, 0.19f));
        var held = BodyRetarget.Solve(skin, pairs, held: new HashSet<int> { 0, 1, 2 }, replaceSkin: true);
        for (int v = 0; v < 3; v++) Assert.Equal(0f, Delta(held, v).Length());
    }

    [Fact]
    public void Skin_far_from_the_body_is_not_laid_onto_it()
    {
        // More than LayReach off the body is not the body's surface: laying it would drag it across the gap.
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);
        Assert.True(IdentityCorrespondence.TryBuild(source, target, "chest", out var built, out _));
        var garment = Patch(SkinMaterial, new Vector3(0.01f, 0.01f, 0.20f + BodyRetarget.LayReach + 0.02f));

        var solved = BodyRetarget.Solve(garment, [new BodyRetarget.SlotPair("_top", built!, target)], replaceSkin: true);

        Assert.Equal(0, solved.Laid);
    }

    private static BodyRetarget.Solved SolveHeld(ModelParts garment, ModelParts source, ModelParts target,
                                                 IEnumerable<int> held)
    {
        Assert.True(IdentityCorrespondence.TryBuild(source, target, "chest", out var built, out string refusal),
                    refusal);
        return BodyRetarget.Solve(garment, [new BodyRetarget.SlotPair("_top", built!, target)],
                                  held: new HashSet<int>(held));
    }

    // ── the transfer ────────────────────────────────────────────────────────────────────────────────────

    [Fact]
    public void Cloth_resting_on_the_body_keeps_its_standoff()
    {
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);

        // 10 mm off the +Z face, well inside the near band, so it should follow the body exactly.
        var garment = Points(ClothMaterial, new Vector3(0f, 0f, 0.21f));
        var solved = Solve(garment, source, target);

        var landed = At(garment, 0) + Delta(solved, 0);
        Assert.True(MathF.Abs(landed.Z - 0.26f) < 1e-4f,
                    $"the vertex should have kept its 10 mm standoff over the grown body; it is at z={landed.Z}");
    }

    [Fact]
    public void Cloth_hanging_free_does_not_move()
    {
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);

        // Past the far band from any part of the body.
        var garment = Points(ClothMaterial, new Vector3(0f, 0f, 0.20f + BodyRetarget.FarBand + 0.05f));
        var solved = Solve(garment, source, target);

        var d = Delta(solved, 0);
        Assert.Equal(0f, d.Length(), 6);
    }

    [Fact]
    public void The_falloff_has_no_step()
    {
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);

        // A column of vertices marching away from the +Z face, each its own node.
        const int count = 60;
        const float spacing = 0.005f;
        var column = new Vector3[count];
        for (int i = 0; i < count; i++) column[i] = new Vector3(0f, 0f, 0.20f + 0.001f + i * spacing);

        var garment = Points(ClothMaterial, column);
        var solved = Solve(garment, source, target);

        float previous = float.MaxValue;
        float worstJump = 0f;
        for (int i = 0; i < count; i++)
        {
            float here = Delta(solved, i).Length();
            Assert.True(here <= previous + 1e-6f, $"the field grew with distance at sample {i}");
            if (i > 0) worstJump = MathF.Max(worstJump, MathF.Abs(previous - here));
            previous = here;
        }

        // The steepest a smoothstep over the band can be is 1.5 * range / width; anything near the full displacement
        // would be the crease a hard cutoff leaves.
        float ceiling = 1.5f * 0.05f * spacing / (BodyRetarget.FarBand - BodyRetarget.NearBand) * 1.2f;
        Assert.True(worstJump <= ceiling, $"a step of {worstJump:F6} between neighbours exceeds {ceiling:F6}");
        Assert.Equal(0f, previous, 6);
    }

    [Fact]
    public void The_snap_is_decided_per_node_across_a_uv_seam()
    {
        var source = Cube(0.20f, SkinMaterial);
        var target = Cube(0.25f, SkinMaterial);

        // The same point twice, as a uv seam stores it: two vertices, one node.
        var garment = Points(SkinMaterial, new Vector3(0f, 0f, 0.20f), new Vector3(0f, 0f, 0.20f));
        var solved = Solve(garment, source, target);

        var a = Delta(solved, 0);
        var b = Delta(solved, 1);
        Assert.Equal(a.X, b.X);
        Assert.Equal(a.Y, b.Y);
        Assert.Equal(a.Z, b.Z);
    }

    // ── the topology guard ──────────────────────────────────────────────────────────────────────────────

    [Fact]
    public void The_guard_accepts_the_same_topology_at_different_positions()
    {
        var a = Cube(0.20f, SkinMaterial);
        var b = Cube(0.25f, SkinMaterial);

        Assert.True(IdentityCorrespondence.TryBuild(a, b, "chest", out var built, out string refusal), refusal);
        Assert.NotNull(built);
        Assert.Equal(a.Positions.Length / 3, built!.Field.Count);
    }

    [Fact]
    public void The_guard_refuses_a_different_vertex_count()
    {
        var a = Cube(0.20f, SkinMaterial);
        var b = Points(SkinMaterial, new Vector3(0f, 0f, 0f));

        Assert.False(IdentityCorrespondence.TryBuild(a, b, "chest", out _, out string refusal));
        Assert.Contains("vertices", refusal);
    }

    [Fact]
    public void The_guard_accepts_a_pair_that_indexes_its_triangles_differently()
    {
        // Real size pairs do exactly this: one or two submeshes of every Neolithe family reference a different set of
        // vertex indices for the same triangle count, because each size was exported separately. Demanding identical
        // triangles refused every real pair, so the guard must not.
        var a = Cube(0.20f, SkinMaterial);
        var b = Cube(0.25f, SkinMaterial);

        var tris = (int[])b.Parts[0].Triangles.Clone();
        (tris[0], tris[1]) = (tris[1], tris[0]);
        var rewired = Replace(b, tris);

        var uv = Uv(a);
        Assert.True(IdentityCorrespondence.TryBuild(a, rewired, "chest", out _, out string refusal, uv, uv), refusal);
    }

    [Fact]
    public void The_guard_refuses_a_mesh_that_numbers_its_vertices_differently()
    {
        // Same vertex count, same submesh layout, but the uvs disagree — so vertex i of one is not vertex i of the
        // other, and a per-index displacement field would scramble the mesh. This is the check that replaced
        // comparing index buffers.
        var a = Cube(0.20f, SkinMaterial);
        var b = Cube(0.25f, SkinMaterial);

        var uvA = Uv(a);
        var uvB = Uv(a);
        for (int i = 0; i < uvB.Length; i += 2) uvB[i] += 0.25f;

        Assert.False(IdentityCorrespondence.TryBuild(a, b, "chest", out _, out string refusal, uvA, uvB));
        Assert.Contains("number their vertices the same way", refusal);
    }

    // ── by texture coordinate: bodies that are not the same mesh ─────────────────────────────────────────

    [Fact]
    public void A_renumbered_body_is_mapped_by_texture_coordinate()
    {
        // Same texture layout, same shape family, but every vertex renumbered — which is what a different mesh of the
        // same body looks like to the refit. Vertex for vertex is impossible; by uv, each point finds its twin exactly.
        var source = Cube(0.20f, SkinMaterial);
        var target = Scrambled(Cube(0.25f, SkinMaterial), out var targetUv);
        var sourceUv = CubeUv(source);

        Assert.False(IdentityCorrespondence.TryBuild(source, target, "chest", out _, out _, sourceUv, targetUv));
        Assert.True(BodyCorrespondence.TryBuild(source, sourceUv, target, targetUv, "chest", out var built,
                                                out string refusal), refusal);
        Assert.IsType<UvAtlasCorrespondence>(built);

        // The target is the source scaled by 1.25 about the origin, so every point should land at 1.25x itself.
        for (int v = 0; v < source.Positions.Length / 3; v++)
        {
            var p = At(source, v);
            Assert.True(built!.Field[v].HasValue, $"vertex {v} found no landing");
            var landed = p + built.Field[v]!.Value;
            Assert.True(Vector3.Distance(landed, p * 1.25f) < 1e-5f, $"vertex {v} landed at {landed}, wanted {p * 1.25f}");
        }
    }

    [Fact]
    public void A_refit_onto_a_renumbered_body_lands_the_skin_exactly()
    {
        // End to end through the solve: the garment's body mesh is a copy of the source, the target is a different mesh
        // of the grown body, and the skin must still land on it.
        var source = Cube(0.20f, SkinMaterial);
        var target = Scrambled(Cube(0.25f, SkinMaterial), out var targetUv);
        Assert.True(BodyCorrespondence.TryBuild(source, CubeUv(source), target, targetUv, "chest", out var built,
                                                out string refusal), refusal);

        var garment = Copy(source, SkinMaterial);
        var solved = BodyRetarget.Solve(garment, [new BodyRetarget.SlotPair("_top", built!, target)]);

        for (int v = 0; v < garment.Positions.Length / 3; v++)
        {
            var landed = At(garment, v) + Delta(solved, v);
            Assert.True(Vector3.Distance(landed, At(garment, v) * 1.25f) < 1e-5f,
                        $"vertex {v} landed at {landed}");
        }
    }

    [Fact]
    public void A_triangle_collapsed_in_uv_lands_its_own_vertex()
    {
        // Neolithe's neck opening is a ring of triangles with no area in uv: two corners share one coordinate. Vertex 3
        // here shares vertex 2's uv, so the uv names two places on the body, and triangle 1-3-2 is a line in the
        // texture. Treating it as "its first corner" once put a neck vertex 29 mm from home; it must land on itself.
        float[] pos =
        [
            0f,    0f,    0f,
            0.01f, 0f,    0f,
            0f,    0.01f, 0f,
            0.02f, 0.03f, 0f,
        ];
        float[] uv = [0f, 0f, 0.1f, 0f, 0f, 0.1f, 0f, 0.1f];
        float[] nrm = [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1];
        int[] tris = [0, 1, 2, 1, 3, 2];
        var source = Build(pos, nrm, tris, SkinMaterial);
        var target = Build(pos.Select(x => x * 1.1f).ToArray(), nrm, tris, SkinMaterial);

        Assert.True(UvAtlasCorrespondence.TryBuild(source, uv, target, uv, "chest", out var built, out string refusal),
                    refusal);
        for (int v = 0; v < 4; v++)
        {
            var landed = At(source, v) + built!.Field[v]!.Value;
            Assert.True(Vector3.Distance(landed, At(source, v) * 1.1f) < 1e-6f,
                        $"vertex {v} landed at {landed}, wanted {At(source, v) * 1.1f}");
        }
    }

    [Fact]
    [Trait("Plan", "EDGE-per-part-target-body-11")]
    public void Bodies_with_different_texture_layouts_are_refused()
    {
        // Nothing lines up by uv, so there is no way to say which point is which: the one case still refused.
        // Moved by part of a tile, not a whole one: a sheet repeats, so a whole-tile shift is the SAME layout and
        // pairs (see Two_bodies_a_whole_tile_apart_in_uv_still_pair).
        var source = Cube(0.20f, SkinMaterial);
        var target = Scrambled(Cube(0.25f, SkinMaterial), out var targetUv);
        for (int i = 0; i < targetUv.Length; i++) targetUv[i] += 0.37f;

        Assert.False(BodyCorrespondence.TryBuild(source, CubeUv(source), target, targetUv, "chest", out _,
                                                 out string refusal));
        Assert.Contains("texture layout", refusal);
    }

    [Fact]
    public void The_guard_accepts_a_variant_with_a_few_uvs_remapped()
    {
        // Neolithe's NSFW chests re-map about 1.2% of their uvs and are otherwise the same mesh vertex for vertex. That
        // must stay a vertex-for-vertex pair, not be refused and not drop to the approximate route.
        var a = Cube(0.20f, SkinMaterial);
        var b = Cube(0.25f, SkinMaterial);
        var uvA = Uv(a);
        var uvB = Uv(a);
        for (int i = 0; i < 2; i++) uvB[i] += 0.5f;   // one vertex of 54 re-mapped

        Assert.True(BodyCorrespondence.TryBuild(a, uvA, b, uvB, "chest", out var built, out string refusal), refusal);
        Assert.IsType<IdentityCorrespondence>(built);
    }

    [Fact]
    public void The_guard_refuses_when_the_uvs_cannot_be_read()
    {
        var a = Cube(0.20f, SkinMaterial);
        var b = Cube(0.25f, SkinMaterial);

        Assert.False(IdentityCorrespondence.TryBuild(a, b, "chest", out _, out string refusal, Uv(a), []));
        Assert.Contains("could not be read", refusal);
    }

    [Fact]
    public void The_guard_ignores_a_different_island_split()
    {
        // ModelPartReader welds islands from POSITIONS, so two sizes of one body can legitimately split into
        // different island counts where a gap closes as the body grows. The guard must not look at them.
        var a = Cube(0.20f, SkinMaterial);
        var b = Cube(0.25f, SkinMaterial);

        var withIslands = WithIslandParts(b, 3);

        Assert.True(IdentityCorrespondence.TryBuild(a, withIslands, "chest", out _, out string refusal), refusal);
    }

    // ── helpers ─────────────────────────────────────────────────────────────────────────────────────────

    private static BodyRetarget.Solved Solve(ModelParts garment, ModelParts source, ModelParts target,
                                             bool clearBody = false)
    {
        Assert.True(IdentityCorrespondence.TryBuild(source, target, "chest", out var built, out string refusal),
                    refusal);
        return BodyRetarget.Solve(garment, [new BodyRetarget.SlotPair("_top", built!, target)], clearBody: clearBody);
    }

    /// <summary>
    /// A real texture layout for <see cref="Cube"/>: each face gets its own cell of a 3x2 atlas, so no two faces
    /// overlap and a uv names exactly one point of the cube. Relies on Cube's vertex order (face, then 3x3 grid).
    /// </summary>
    private static float[] CubeUv(ModelParts cube)
    {
        int vc = cube.Positions.Length / 3;
        var uv = new float[vc * 2];
        for (int i = 0; i < vc; i++)
        {
            int face = i / 9, iu = i % 9 / 3, iv = i % 3;
            uv[i * 2] = (face % 3 + 0.05f + 0.45f * iu) / 3f;
            uv[i * 2 + 1] = (face / 3 + 0.05f + 0.45f * iv) / 2f;
        }
        return uv;
    }

    /// <summary>The same cube with every vertex renumbered (reversed), and its uvs carried along with them.</summary>
    private static ModelParts Scrambled(ModelParts cube, out float[] uv)
    {
        int vc = cube.Positions.Length / 3;
        var original = CubeUv(cube);
        var pos = new float[vc * 3];
        var nrm = new float[vc * 3];
        uv = new float[vc * 2];
        for (int n = 0; n < vc; n++)
        {
            int o = vc - 1 - n;   // new vertex n is old vertex o
            for (int k = 0; k < 3; k++)
            {
                pos[n * 3 + k] = cube.Positions[o * 3 + k];
                nrm[n * 3 + k] = cube.Normals[o * 3 + k];
            }
            uv[n * 2] = original[o * 2];
            uv[n * 2 + 1] = original[o * 2 + 1];
        }
        var tris = cube.Parts[0].Triangles.Select(o => vc - 1 - o).ToArray();
        return Build(pos, nrm, tris, cube.Parts[0].Material);
    }

    /// <summary>A distinct uv per vertex, so the guard's numbering proof has something real to compare.</summary>
    private static float[] Uv(ModelParts m)
    {
        int vc = m.Positions.Length / 3;
        var uv = new float[vc * 2];
        for (int i = 0; i < vc; i++)
        {
            uv[i * 2] = i * 0.001f;
            uv[i * 2 + 1] = 1f - i * 0.001f;
        }
        return uv;
    }

    private static Vector3 At(ModelParts m, int v)
        => new(m.Positions[v * 3], m.Positions[v * 3 + 1], m.Positions[v * 3 + 2]);

    private static Vector3 Delta(BodyRetarget.Solved solved, int v)
    {
        var d = solved.Edit.DeltaAt(v);
        return new Vector3(d.X, d.Y, d.Z);
    }

    /// <summary>
    /// A closed cube of half-extent <paramref name="half"/>, each face a 2x2 grid of quads so that faces have a centre
    /// vertex as well as corners. Closed, because the push-out's winding number needs a solid to be inside of.
    /// </summary>
    private static ModelParts Cube(float half, string material)
    {
        var pos = new List<float>();
        var nrm = new List<float>();
        var tris = new List<int>();

        Span<Vector3> axes = [Vector3.UnitX, Vector3.UnitY, Vector3.UnitZ];
        for (int a = 0; a < 3; a++)
        for (int sign = -1; sign <= 1; sign += 2)
        {
            var n = axes[a] * sign;
            var u = axes[(a + 1) % 3];
            var v = axes[(a + 2) % 3];
            // Wind the face so its normal points out on both sides of the cube.
            if (sign < 0) (u, v) = (v, u);

            int baseVertex = pos.Count / 3;
            for (int iu = 0; iu <= 2; iu++)
            for (int iv = 0; iv <= 2; iv++)
            {
                var p = n * half + u * ((iu - 1) * half) + v * ((iv - 1) * half);
                pos.Add(p.X); pos.Add(p.Y); pos.Add(p.Z);
                nrm.Add(n.X); nrm.Add(n.Y); nrm.Add(n.Z);
            }

            for (int iu = 0; iu < 2; iu++)
            for (int iv = 0; iv < 2; iv++)
            {
                int p00 = baseVertex + iu * 3 + iv;
                int p10 = baseVertex + (iu + 1) * 3 + iv;
                int p01 = baseVertex + iu * 3 + iv + 1;
                int p11 = baseVertex + (iu + 1) * 3 + iv + 1;
                tris.AddRange([p00, p10, p11]);
                tris.AddRange([p00, p11, p01]);
            }
        }

        return Build(pos.ToArray(), nrm.ToArray(), tris.ToArray(), material);
    }

    /// <summary>Where the grown body B's -X face ends up in <see cref="CreatedClip"/>.</summary>
    private const float GrownFace = 0.22f;

    /// <summary>
    /// A patch that the refit genuinely drives into a body — see the comment above the push-out tests. Body A (a cube
    /// at the origin) holds still; body B (a small cube at x = 0.35) grows from half 0.05 to half 0.13, so its -X face
    /// sweeps from x = 0.30 to <see cref="GrownFace"/>. The patch sits at x = 0.23.
    /// </summary>
    private static (ModelParts Garment, List<BodyRetarget.SlotPair> Pairs) CreatedClip(string material)
    {
        var a = Cube(0.20f, SkinMaterial);
        var bFrom = Cube(0.05f, SkinMaterial, new Vector3(0.35f, 0f, 0f));
        var bTo = Cube(0.13f, SkinMaterial, new Vector3(0.35f, 0f, 0f));

        Assert.True(IdentityCorrespondence.TryBuild(a, a, "chest", out var still, out string r1), r1);
        Assert.True(IdentityCorrespondence.TryBuild(bFrom, bTo, "legs", out var grow, out string r2), r2);

        var garment = Patch(material, new Vector3(0.23f, 0f, 0f));
        return (garment, [new BodyRetarget.SlotPair("_top", still!, a), new BodyRetarget.SlotPair("_dwn", grow!, bTo)]);
    }

    private static ModelParts Cube(float half, string material, Vector3 centre)
    {
        var cube = Cube(half, material);
        var pos = (float[])cube.Positions.Clone();
        for (int v = 0; v < pos.Length / 3; v++)
        {
            pos[v * 3] += centre.X;
            pos[v * 3 + 1] += centre.Y;
            pos[v * 3 + 2] += centre.Z;
        }
        return Build(pos, cube.Normals, cube.Parts[0].Triangles, material);
    }

    /// <summary>A copy of <paramref name="m"/>'s geometry drawn with another material.</summary>
    private static ModelParts Copy(ModelParts m, string material)
        => Build((float[])m.Positions.Clone(), (float[])m.Normals.Clone(),
                 (int[])m.Parts[0].Triangles.Clone(), material);

    /// <summary>
    /// A small triangle centred on <paramref name="centre"/>, facing +Z.
    /// <para/>
    /// Needed wherever a test cares which SET a node lands in, because skin membership is read off a part's triangles
    /// — exactly as <see cref="MeshVolumeSolve"/> reads it — so a part with no faces contributes no skin nodes and
    /// silently behaves like cloth.
    /// </summary>
    private static ModelParts Patch(string material, Vector3 centre)
    {
        const float r = 0.002f;
        var a = centre + new Vector3(-r, -r, 0f);
        var b = centre + new Vector3(r, -r, 0f);
        var c = centre + new Vector3(0f, r, 0f);
        float[] pos = [a.X, a.Y, a.Z, b.X, b.Y, b.Z, c.X, c.Y, c.Z];
        float[] nrm = [0, 0, 1, 0, 0, 1, 0, 0, 1];
        return Build(pos, nrm, [0, 1, 2], material);
    }

    /// <summary>Loose vertices with no triangles: the transfer works per node and does not need faces.</summary>
    private static ModelParts Points(string material, params Vector3[] points)
    {
        var pos = new float[points.Length * 3];
        var nrm = new float[points.Length * 3];
        for (int i = 0; i < points.Length; i++)
        {
            pos[i * 3] = points[i].X;
            pos[i * 3 + 1] = points[i].Y;
            pos[i * 3 + 2] = points[i].Z;
            nrm[i * 3 + 2] = 1f;
        }
        return Build(pos, nrm, [], material);
    }

    private static ModelParts Replace(ModelParts m, int[] triangles)
        => Build(m.Positions, m.Normals, triangles, m.Parts[0].Material);

    /// <summary>The same model with extra ISLAND parts bolted on, which the guard must ignore.</summary>
    private static ModelParts WithIslandParts(ModelParts m, int islands)
    {
        var parts = new List<ModelPart>(m.Parts);
        var whole = m.Parts[0];
        for (int i = 0; i < islands; i++)
            parts.Add(new ModelPart
            {
                Mesh = whole.Mesh,
                Submesh = whole.Submesh,
                Island = i,
                Label = $"{whole.Label}{(char)('b' + i)}",
                Material = whole.Material,
                Triangles = whole.Triangles.Take(3).ToArray(),
                Ordinals = [0],
                AttributeMask = 0,
                Min = whole.Min,
                Max = whole.Max,
                Toggleable = true,
            });

        return new ModelParts
        {
            Positions = m.Positions,
            Normals = m.Normals,
            MeshSpans = m.MeshSpans,
            Parts = parts,
            AttributeNames = m.AttributeNames,
            Min = m.Min,
            Max = m.Max,
            ShatteredSubmeshes = m.ShatteredSubmeshes,
        };
    }

    /// <summary>One vertex array, two submeshes with different materials — how a garment carries cloth beside skin.</summary>
    private static ModelParts BuildTwoPart(float[] pos, float[] nrm, int[] trisA, string materialA,
                                           int[] trisB, string materialB)
    {
        var a = Build(pos, nrm, trisA, materialA);
        var b = Build(pos, nrm, trisB, materialB);
        var partB = new ModelPart
        {
            Mesh = 0,
            Submesh = 1,
            Island = -1,
            Label = "0.1",
            Material = materialB,
            Triangles = trisB,
            Ordinals = b.Parts[0].Ordinals,
            AttributeMask = 0,
            Min = b.Min,
            Max = b.Max,
            Toggleable = true,
        };

        return new ModelParts
        {
            Positions = a.Positions,
            Normals = a.Normals,
            MeshSpans = a.MeshSpans,
            Parts = [a.Parts[0], partB],
            AttributeNames = [],
            Min = a.Min,
            Max = a.Max,
            ShatteredSubmeshes = new Dictionary<string, int>(),
        };
    }

    private static ModelParts Build(float[] pos, float[] nrm, int[] tris, string material)
    {
        int vc = pos.Length / 3;
        var min = new Vector3(float.MaxValue);
        var max = new Vector3(float.MinValue);
        for (int v = 0; v < vc; v++)
        {
            var p = new Vector3(pos[v * 3], pos[v * 3 + 1], pos[v * 3 + 2]);
            min = Vector3.Min(min, p);
            max = Vector3.Max(max, p);
        }
        if (vc == 0) { min = Vector3.Zero; max = Vector3.Zero; }

        var part = new ModelPart
        {
            Mesh = 0,
            Submesh = 0,
            Island = -1,
            Label = "0.0",
            Material = material,
            Triangles = tris,
            Ordinals = Enumerable.Range(0, tris.Length / 3).ToArray(),
            AttributeMask = 0,
            Min = min,
            Max = max,
            Toggleable = true,
        };

        return new ModelParts
        {
            Positions = pos,
            Normals = nrm,
            MeshSpans = [new MeshSpan(0, 0, vc)],
            Parts = [part],
            AttributeNames = [],
            Min = min,
            Max = max,
            ShatteredSubmeshes = new Dictionary<string, int>(),
        };
    }
}
