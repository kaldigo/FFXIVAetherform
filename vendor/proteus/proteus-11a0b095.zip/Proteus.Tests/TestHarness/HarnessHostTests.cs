using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Dalamud.Plugin.Services;
using NSubstitute;
using Proteus.TestHarness;
using Xunit;

namespace Proteus.Tests.TestHarness;

[Collection(HarnessTimingCollection.Name)]
public class HarnessHostTests : IDisposable
{
    private readonly TempDir temp = new();
    private readonly FakeFrameworkDispatcher dispatcher = new();
    private readonly FakeGame game;
    private readonly IPluginLog log = Substitute.For<IPluginLog>();
    private Action<string>? observer;
    private readonly string configDir;

    public HarnessHostTests()
    {
        configDir = temp.Sub("config");
        game = new FakeGame(dispatcher, temp.Sub("mods"));
    }

    public void Dispose()
    {
        dispatcher.Dispose();
        temp.Dispose();
    }

    private HarnessHost Host(bool isDev = true, IPluginLog? withLog = null)
        => new(configDir, isDev, game, dispatcher, o => observer = o, withLog ?? log, 1411, "stamp", HarnessFixture.FastTimings);

    private HarnessSession? SessionFile => HarnessSessionFile.Read(configDir);
    private bool Marker => File.Exists(HarnessSessionFile.MarkerIn(configDir));

    private static HttpClient Client(HarnessSession s)
    {
        var c = new HttpClient { BaseAddress = new Uri($"http://127.0.0.1:{s.Port}") };
        c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", s.Token);
        return c;
    }

    private string AddMod()
    {
        string root = temp.Sub("mods", "Outfit");
        File.WriteAllText(Path.Combine(root, "meta.json"), "{}");
        for (int i = 0; i < 50; i++) File.WriteAllText(Path.Combine(root, $"f{i}.mdl"), new string('x', 100));
        game.ModFolders["Outfit"] = "Outfit";
        return root;
    }

    private static async Task<string> StartRefit(HarnessSession s)
    {
        using var c = Client(s);
        var r = await c.PostAsync("/actions/refit", new StringContent("""{"mod":"Outfit","bodies":["rue"]}""", Encoding.UTF8, "application/json"));
        Assert.Equal(202, (int)r.StatusCode);
        return JsonDocument.Parse(await r.Content.ReadAsStringAsync()).RootElement.GetProperty("job").GetString()!;
    }

    private static async Task<JobView> WaitEnded(HarnessHost host, string id)
    {
        for (int i = 0; i < 500; i++)
        {
            if (host.Jobs?.Find(id)?.View() is { EndedAt: not null } v) return v;
            await Task.Delay(20);
        }
        throw new TimeoutException(id);
    }

    [Fact]
    public async Task On_StartsListening_WritesSessionFileAndMarker()
    {
        // [AC-qa-harness-2]
        using var host = Host();
        string said = host.Command("on");
        Assert.True(host.Listening);
        Assert.Contains($"127.0.0.1:{host.Port}", said);
        var s = SessionFile!;
        Assert.Equal(host.Port, s.Port);
        Assert.Equal(Environment.ProcessId, s.Pid);
        Assert.Equal(1411, s.Build);
        Assert.Equal(host.Session, s.Session);
        Assert.True(s.Token.Length >= 43);
        Assert.True(Marker);
        Assert.NotNull(observer);
        using var c = Client(s);
        Assert.Equal(200, (int)(await c.GetAsync("/health")).StatusCode);
    }

    [Fact]
    public void Off_Stops_DeletesSessionFileAndMarker()
    {
        // [AC-qa-harness-2]
        using var host = Host();
        host.Command("on");
        host.Command("off");
        Assert.False(host.Listening);
        Assert.Null(SessionFile);
        Assert.False(Marker);
        Assert.Null(observer);
    }

    [Fact]
    public void Autostart_WithMarker_Starts_WithoutMarker_DoesNot()
    {
        // [AC-qa-harness-2] Left on, it starts again at the next load and says so.
        using (var host = Host()) Assert.Null(host.TryAutostart());
        File.WriteAllText(HarnessSessionFile.MarkerIn(configDir), "on");
        using var again = Host();
        Assert.Contains("was left on", again.TryAutostart());
        Assert.True(again.Listening);
    }

    [Fact]
    public void Default_NotListening()
    {
        // [AC-qa-harness-2] Constructed is not started: no file, no port.
        using var host = Host();
        Assert.False(host.Listening);
        Assert.Null(SessionFile);
        Assert.Equal(0, host.Port);
    }

    [Fact]
    public void NotDev_RefusesOn_AndAutostart()
    {
        // [EDGE-qa-harness-4]
        File.WriteAllText(HarnessSessionFile.MarkerIn(configDir), "on");
        using var host = Host(isDev: false);
        Assert.Null(host.TryAutostart());
        Assert.Contains("dev-loaded", host.Command("on"));
        Assert.False(host.Listening);
        Assert.Null(SessionFile);
    }

    [Fact]
    public void IsTypedOnly_HarnessLines_AnyCase()
    {
        // [EDGE-qa-harness-5] The dev-command file can never turn it on.
        Assert.True(HarnessHost.IsTypedOnly("harness on"));
        Assert.True(HarnessHost.IsTypedOnly("  HARNESS off"));
        Assert.True(HarnessHost.IsTypedOnly("Harness"));
        Assert.False(HarnessHost.IsTypedOnly("refresh"));
        Assert.False(HarnessHost.IsTypedOnly("models harness"));
    }

    [Fact]
    public void OnTwice_Idempotent_SamePortAndToken()
    {
        // [EDGE-qa-harness-6]
        using var host = Host();
        host.Command("on");
        var first = SessionFile!;
        Assert.Contains("already", host.Command("on"));
        var second = SessionFile!;
        Assert.Equal(first.Port, second.Port);
        Assert.Equal(first.Token, second.Token);
    }

    [Fact]
    public void StaleSessionFile_Overwritten()
    {
        // [EDGE-qa-harness-7] A crash left a file: the next start writes its own.
        HarnessSessionFile.Write(configDir, new HarnessSession(1, "old", 1, 1, "x", "old-session", DateTime.UtcNow));
        using var host = Host();
        host.Command("on");
        Assert.Equal(host.Session, SessionFile!.Session);
        Assert.NotEqual("old", SessionFile!.Token);
    }

    [Fact]
    public void Delete_OnlyWhenSessionMatches()
    {
        // [EDGE-qa-harness-7] A stopping instance never deletes another session's file.
        using var host = Host();
        host.Command("on");
        HarnessSessionFile.Write(configDir, new HarnessSession(2, "theirs", 1, 1, "x", "another-session", DateTime.UtcNow));
        host.Command("off");
        Assert.Equal("another-session", SessionFile!.Session);
    }

    [Fact]
    public async Task Restart_NewSession_LogCursorResets()
    {
        // [EDGE-qa-harness-8] A reload with the marker: a new port, token and session; the log numbers from 1 again.
        string firstSession, firstToken;
        using (var host = Host())
        {
            host.Command("on");
            observer!("a line");
            observer!("another");
            firstSession = host.Session!;
            firstToken = SessionFile!.Token;
        }
        using var again = Host();
        again.TryAutostart();
        Assert.NotEqual(firstSession, again.Session);
        Assert.NotEqual(firstToken, SessionFile!.Token);
        observer!("first of the new session");
        using var c = Client(SessionFile!);
        var page = JsonDocument.Parse(await c.GetStringAsync("/log")).RootElement;
        Assert.Equal(1, page.GetProperty("lines")[0].GetProperty("seq").GetInt64());
    }

    [Fact]
    public async Task OffDuringBackup_PartialDeleted_JobCancelled()
    {
        // [EDGE-qa-harness-9] Off while the backup copies: the copy stops, its partial folder goes, the job is cancelled.
        AddMod();
        using var host = Host();
        host.Command("on");
        var s = SessionFile!;
        host.Jobs!.Backups.BetweenCheckAndClaim = _ => host.Command("off");
        string id = await StartRefit(s);
        var jobs = host.Jobs!;
        JobView? v = null;
        for (int i = 0; i < 500 && (v = jobs.Find(id)?.View()) is not { EndedAt: not null }; i++) await Task.Delay(20);
        Assert.Equal("cancelled", v!.State);
        Assert.Empty(jobs.Backups.List("Outfit"));
        Assert.Empty(Directory.EnumerateDirectories(Path.Combine(jobs.Backups.Root, "Outfit")));
        Assert.Null(SessionFile);
    }

    [Fact]
    public async Task OffMidRun_AfterChangeRuns_FileDeleted()
    {
        // [EDGE-qa-harness-9] Off mid-run: the run is cancelled, and Penumbra is still told.
        AddMod();
        using var host = Host();
        host.Command("on");
        var s = SessionFile!;
        game.RunBody = (_, _, ct) => { host.Command("off"); ct.ThrowIfCancellationRequested(); return 0; };
        var jobs = host.Jobs!;
        string id = await StartRefit(s);
        JobView? v = null;
        for (int i = 0; i < 500 && (v = jobs.Find(id)?.View()) is not { EndedAt: not null }; i++) await Task.Delay(20);
        Assert.Equal("cancelled", v!.State);
        Assert.Equal(1, game.AfterChanges);
        Assert.Null(SessionFile);
    }

    [Fact]
    public async Task Dispose_OffFrameworkThread_DoesNotBlock_AfterChangeSkipped()
    {
        // [EDGE-qa-harness-10] Unload with the framework stalled behind an after-change: Dispose returns at once, the
        // after-change is skipped when it finally comes up, and the marker stays.
        AddMod();
        var host = Host();
        host.Command("on");
        var s = SessionFile!;
        var reachedRun = new ManualResetEventSlim();
        game.RunBody = (_, _, _) => { dispatcher.Stall(); reachedRun.Set(); return 1; };
        var jobs = host.Jobs!;
        string id = await StartRefit(s);
        Assert.True(reachedRun.Wait(TimeSpan.FromSeconds(10)));
        await Task.Delay(100);
        var clock = System.Diagnostics.Stopwatch.StartNew();
        host.Dispose();
        Assert.True(clock.ElapsedMilliseconds < 1000, $"Dispose took {clock.ElapsedMilliseconds} ms");
        dispatcher.Resume();
        JobView? v = null;
        for (int i = 0; i < 500 && (v = jobs.Find(id)?.View()) is not { EndedAt: not null }; i++) await Task.Delay(20);
        Assert.Equal("after-change-skipped", v!.Error!.Code);
        Assert.Equal(0, game.AfterChanges);
        Assert.True(Marker);
        Assert.Null(game.NameSink);
    }

    [Fact]
    [Trait("Plan", "EDGE-idle-disk-io-41")]
    public async Task OffThreadStop_RestoresSidecars_NoRecomposite_WarnsOnlyFailures()
    {
        // [EDGE-idle-disk-io-41] An unload off the framework thread puts the sidecar back (file work only), asks for no
        // recomposite, and warns about nothing when nothing failed.
        AddMod();
        game.PutSidecar("Outfit", (16, "#111111"));
        var original = File.ReadAllBytes(game.MetaPath("Outfit"));
        var host = Host();
        host.Command("on");
        using (var c = Client(SessionFile!))
        {
            var r = await c.PostAsync("/actions/sidecar-edit",
                new StringContent("{\"mod\":\"Outfit\",\"row\":16,\"diffuse\":\"#ABCDEF\"}", System.Text.Encoding.UTF8, "application/json"));
            Assert.Equal(200, (int)r.StatusCode);
        }
        Assert.NotEqual(original, File.ReadAllBytes(game.MetaPath("Outfit")));
        int recompositesBefore = game.Recomposites.Count;

        Assert.False(dispatcher.OnFrameworkThread);
        host.Dispose();

        Assert.Equal(original, File.ReadAllBytes(game.MetaPath("Outfit")));
        Assert.Equal(recompositesBefore, game.Recomposites.Count);
        log.DidNotReceive().Warning(Arg.Is<string>(s => s.Contains("sidecars not put back")), Arg.Any<object[]>());
    }

    [Fact]
    [Trait("Plan", "AC-issue-sweep-d-13")]
    [Trait("Plan", "AC-issue-sweep-d-14")]
    [Trait("Plan", "AC-issue-sweep-d-15")]
    public async Task Off_releases_output_locks_and_clears_the_fault_and_override()
    {
        // [AC-issue-sweep-d-13] [AC-issue-sweep-d-14] [AC-issue-sweep-d-15] On and off the framework thread.
        foreach (bool onFramework in new[] { true, false })
        {
            var output = temp.Sub("out-" + onFramework);
            Directory.CreateDirectory(Path.Combine(output, "textures"));
            File.WriteAllBytes(Path.Combine(output, "textures", "ss_1_norm.tex"), [1, 2]);
            game.OutputDir = output;
            var host = Host();
            host.Command("on");
            using (var c = Client(SessionFile!))
            {
                async Task Post(string route, string json)
                {
                    var r = await c.PostAsync(route, new StringContent(json, System.Text.Encoding.UTF8, "application/json"));
                    Assert.Equal(200, (int)r.StatusCode);
                }
                await Post("/actions/output-lock", "{\"files\":[\"textures/ss_1_norm.tex\"],\"ms\":60000}");
                await Post("/actions/shell-fault", "{\"shell\":\"any\",\"until\":\"put-back\"}");
                await Post("/actions/auto-redraw", "{\"enabled\":false}");
            }
            if (onFramework) dispatcher.Run(() => host.Command("off"));
            else host.Dispose();

            Assert.Null(game.ShellFaultValue);
            Assert.Null(game.AutoRedrawOverrideValue);
            // The handle is gone: the file can be replaced again.
            var tmp = Path.Combine(output, "textures", "x.tmp");
            File.WriteAllBytes(tmp, [3]);
            File.Move(tmp, Path.Combine(output, "textures", "ss_1_norm.tex"), overwrite: true);
            if (onFramework) host.Dispose();
        }
    }

    [Fact]
    public async Task Token_NeverLogged()
    {
        // [EDGE-qa-harness-11]
        var lines = new ConcurrentQueue<string>();
        var recording = new Proteus.Services.CapturingPluginLog(Substitute.For<IPluginLog>()) { LineObserver = lines.Enqueue };
        using var host = Host(withLog: recording);
        host.Command("on");
        var s = SessionFile!;
        using var c = Client(s);
        await c.GetAsync("/health");
        host.Command("off");
        Assert.NotEmpty(lines);
        Assert.DoesNotContain(lines, l => l.Contains(s.Token));
    }

    [Fact]
    public async Task OnAgainWhileOldJobStopping_Refused()
    {
        // [EDGE-qa-harness-9] One job at a time across sessions: off cancels a job that may still be writing, and on
        // waits for it.
        AddMod();
        using var host = Host();
        host.Command("on");
        var release = new ManualResetEventSlim();
        game.RunBody = (_, _, _) => { release.Wait(TimeSpan.FromSeconds(10)); return 0; };
        var jobs = host.Jobs!;
        string id = await StartRefit(SessionFile!);
        await Task.Delay(100);
        host.Command("off");
        Assert.Contains("still stopping", host.Command("on"));
        Assert.False(host.Listening);
        Assert.False(Marker);
        release.Set();
        for (int i = 0; i < 500 && jobs.Find(id)?.View() is not { EndedAt: not null }; i++) await Task.Delay(20);
        Assert.Contains("listening", host.Command("on"));
        Assert.True(host.Listening);
    }

    [Fact]
    public void SessionFileUnwritable_StartUndone()
    {
        // [AC-qa-harness-2] Listening with no session file is a harness QA cannot find: the start is undone.
        Directory.CreateDirectory(HarnessSessionFile.PathIn(configDir));   // a folder where the file must go
        using var host = Host();
        Assert.Contains("could not start", host.Command("on"));
        Assert.False(host.Listening);
        Assert.Null(observer);
        Assert.False(Marker);
        Assert.False(File.Exists(HarnessSessionFile.PathIn(configDir) + ".tmp"));
    }

    [Fact]
    public void RedrawEvents_CountedWithTime()
    {
        // [AC-qa-harness-5] The adapter's counter: every local-player redraw counted, with its time.
        var counter = new RedrawCounter();
        Assert.Equal(0, counter.Count);
        Assert.Null(counter.LastUtc);
        counter.Note();
        counter.Note();
        Assert.Equal(2, counter.Count);
        Assert.True(DateTime.UtcNow - counter.LastUtc!.Value < TimeSpan.FromSeconds(5));
    }

    // ── put back as the harness stops ───────────────────────────────────────

    private static async Task Post(HarnessSession s, string path, string json)
    {
        using var c = Client(s);
        var r = await c.PostAsync(path, new StringContent(json, Encoding.UTF8, "application/json"));
        Assert.Equal(200, (int)r.StatusCode);
    }

    private async Task EquipAndHold(HarnessSession s)
    {
        game.ModFolders["Equinox"] = "Equinox";
        await Post(s, "/actions/equip", """{"slot":"Body","item":500}""");
        await Post(s, "/actions/mod-settings", """{"mod":"Equinox","enabled":false}""");
    }

    [Fact]
    public async Task Off_OnFramework_PutsBackInline()
    {
        // [AC-harness-equip-7] [EDGE-harness-equip-31]
        var gearBefore = new System.Collections.Generic.Dictionary<string, Worn>(game.Gear);
        using var host = Host();
        host.Command("on");
        await EquipAndHold(SessionFile!);
        bool? stoppingAtUndo = null, listeningAtUndo = null;
        game.OnSetGear = _ => { stoppingAtUndo = host.Changes!.Stopping; listeningAtUndo = host.Listening; };
        dispatcher.Run(() => host.Command("off"));
        Assert.Equal(gearBefore, game.Gear);
        Assert.Empty(game.Temporary);
        Assert.True(stoppingAtUndo);
        Assert.True(listeningAtUndo);
        Assert.False(host.Listening);
        Assert.Contains(log.ReceivedCalls(), c => c.GetArguments().OfType<string>().Any(a => a.Contains("put back as it stopped")));
    }

    [Fact]
    public async Task Dispose_OnFramework_PutsBackBeforeReturning()
    {
        // [AC-harness-equip-7] [EDGE-harness-equip-32]
        var gearBefore = new System.Collections.Generic.Dictionary<string, Worn>(game.Gear);
        var host = Host();
        host.Command("on");
        await EquipAndHold(SessionFile!);
        bool? sinkAtUndo = null;
        game.OnSetGear = _ => sinkAtUndo = game.NameSink != null;
        dispatcher.Run(host.Dispose);
        Assert.Equal(gearBefore, game.Gear);
        Assert.Empty(game.Temporary);
        Assert.True(sinkAtUndo);
    }

    // ── the binding session as the harness stops ────────────────────────────

    private static readonly Guid BoundDesign = Guid.Parse("dddddddd-0000-0000-0000-000000000009");

    private async Task ApplyDesign(HarnessSession s)
    {
        game.DesignNames[BoundDesign] = "Look";
        game.ApplyEffects[BoundDesign] = () => game.GlamourerNow = FakeGame.GlamState(("Body", 100), ("Legs", 555));
        await Post(s, "/actions/glamourer-apply", $$"""{"design":"{{BoundDesign}}"}""");
    }

    private List<string> Logged(string level)
        => log.ReceivedCalls().Where(c => c.GetMethodInfo().Name == level)
              .SelectMany(c => c.GetArguments()).SelectMany(a => a is object[] arr ? arr : [a]).OfType<string>().ToList();

    [Fact]
    [Trait("Plan", "EDGE-binding-reapply-34")]
    public async Task Stop_PutsBackBinding()
    {
        using var host = Host();
        host.Command("on");
        await ApplyDesign(SessionFile!);
        dispatcher.Run(() => host.Command("off"));
        Assert.Single(game.Restores);
        Assert.Equal(101UL, game.GlamourerNow["Equipment"]!["Legs"]!["ItemId"]!.ToObject<ulong>());
        Assert.Contains(Logged("Information"), l => l.Contains("binding: glamourer restored"));
    }

    [Fact]
    [Trait("Plan", "EDGE-binding-reapply-46")]
    public async Task Stop_DuringSettle_LeavesBindingRecorded_LogsAndNeverThrows()
    {
        using var host = Host();
        host.Command("on");
        await ApplyDesign(SessionFile!);
        host.Changes!.ApplySettling = true;   // as if an apply were still settling when the harness stops
        var ex = Record.Exception(() => dispatcher.Run(() => host.Command("off")));
        Assert.Null(ex);
        Assert.Empty(game.Restores);
        Assert.Contains(Logged("Warning"), w => w.Contains("still settling"));
    }

    [Fact]
    [Trait("Plan", "EDGE-binding-reapply-34")]
    public async Task Stop_OffFramework_LogsBindingLeftoversWithRecordPath()
    {
        var host = Host();
        host.Command("on");
        await ApplyDesign(SessionFile!);
        await Task.Run(host.Dispose);
        Assert.Empty(game.Restores);
        var warned = Logged("Warning");
        Assert.Contains(warned, w => w.Contains("not put back"));
        Assert.Contains(warned, w => w.Contains("glamourer state") && w.Contains("binding.json"));
    }

    [Fact]
    public async Task Stop_OffFramework_SkipsPutBack_LogsLeftovers_DoesNotBlock()
    {
        // [EDGE-harness-equip-33]
        var host = Host();
        host.Command("on");
        await EquipAndHold(SessionFile!);
        int setsBefore = game.GearSets.Count;
        var sw = System.Diagnostics.Stopwatch.StartNew();
        await Task.Run(host.Dispose);
        Assert.True(sw.Elapsed < TimeSpan.FromSeconds(1));
        dispatcher.Run(() => 0);   // drain: nothing was posted
        Assert.Equal(setsBefore, game.GearSets.Count);
        Assert.DoesNotContain(game.Calls, c => c.Member is nameof(IHarnessGame.ClearHold) or nameof(IHarnessGame.SweepHolds));
        var warned = log.ReceivedCalls().Where(c => c.GetMethodInfo().Name == "Warning")
                        .SelectMany(c => c.GetArguments()).SelectMany(a => a is object[] arr ? arr : [a]).OfType<string>().ToList();
        Assert.Contains(warned, w => w.Contains("not put back"));
        Assert.Contains(warned, w => w.Contains("Body") && w.Contains("Equinox"));
    }

    [Fact]
    public async Task OffTwice_PutBackOnce_OnAgainFresh()
    {
        // [EDGE-harness-equip-46]
        using var host = Host();
        host.Command("on");
        await EquipAndHold(SessionFile!);
        dispatcher.Run(() => host.Command("off"));
        int sets = game.GearSets.Count, sweeps = game.Sweeps.Count;
        dispatcher.Run(() => host.Command("off"));
        Assert.Equal(sets, game.GearSets.Count);
        Assert.Equal(sweeps, game.Sweeps.Count);
        host.Command("on");
        using var c = Client(SessionFile!);
        var state = JsonDocument.Parse(await c.GetStringAsync("/state")).RootElement;
        Assert.False(state.GetProperty("harnessChanges").GetProperty("stopping").GetBoolean());
        Assert.Empty(state.GetProperty("harnessChanges").GetProperty("gear").EnumerateArray());
        await Post(SessionFile!, "/actions/equip", """{"slot":"Legs","item":700}""");
    }

    [Fact]
    public async Task Restart_NewSession_EmptyChanges()
    {
        // [AC-harness-equip-7] [EDGE-harness-equip-41]
        using var host = Host();
        host.Command("on");
        string first = host.Session!;
        await EquipAndHold(SessionFile!);
        dispatcher.Run(() => host.Command("off"));
        host.Command("on");
        Assert.NotEqual(first, host.Session);
        using var c = Client(SessionFile!);
        var state = JsonDocument.Parse(await c.GetStringAsync("/state")).RootElement;
        Assert.Empty(state.GetProperty("harnessChanges").GetProperty("gear").EnumerateArray());
        Assert.Empty(state.GetProperty("harnessChanges").GetProperty("holds").EnumerateArray());
    }

    [Fact]
    public void Off_OnFramework_NothingRecorded_StillSweepsLeftovers()
    {
        // [EDGE-harness-equip-30] a crashed session's harness-key holds are swept by the next session's off.
        using var host = Host();
        host.Command("on");
        var coll = game.Collection!.Value;
        game.Temporary[(coll, "Leftover")] = new Proteus.Interop.PenumbraBridge.TemporaryHold(true, false, HarnessChanges.HoldSource, false, 0);
        game.TemporaryKeys[(coll, "Leftover")] = HarnessChanges.HoldKey;
        dispatcher.Run(() => host.Command("off"));
        Assert.Empty(game.Temporary);
    }
}
