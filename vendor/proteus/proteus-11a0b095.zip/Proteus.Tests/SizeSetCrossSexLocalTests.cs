using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Dalamud.Plugin.Services;
using NSubstitute;
using Proteus.Services;
using Xunit;
using Xunit.Abstractions;

namespace Proteus.Tests;

/// <summary>
/// A women's mod's men's versions in the size set, against the real files (sizeset-cross-sex): Sheer Elegance's top on
/// Bibo+, a Rue top, and Starlit's YAS-rigged skirt made men's onto TBSE and TBSE-X. Every run works on a copy.
/// </summary>
[Trait("Speed", "Slow")]
public sealed class SizeSetCrossSexLocalTests(ITestOutputHelper o) : IDisposable
{
    /// <summary>The mod copies this test made, deleted after it.</summary>
    private readonly List<string> copies = [];

    public void Dispose()
    {
        foreach (string root in copies)
            try { Directory.Delete(root, recursive: true); }
            catch (IOException) { }
    }

    internal const string Sheer = LocalData.Mods + ":BiboPlus Sheer Elegance";
    internal const string Starlit = LocalData.Mods + ":[Nini] Starlit Skirt";
    internal const string RueTop = LocalData.Mods + ":[alee] Thursday - Rue+";
    internal const string Yab = LocalData.Mods + ":hs-Yet Another Body+-4.2.0-tmi";

    private static readonly Lazy<Lumina.GameData> GameData = new(() => new Lumina.GameData(LocalData.Path(LocalData.GameData)));

    private static byte[]? Game(string path)
    {
        try { return GameData.Value.GetFile(path)?.Data; }
        catch (Exception) { return null; }
    }

    private static UVRemapService Maps() => new(Substitute.For<IPluginLog>(), LocalData.Path(LocalData.TbseUvMaps));

    internal static IReadOnlyList<BodyModIndex.Entry> Installed(params string[] bodyMods)
    {
        var dirs = bodyMods.Select(n => Path.GetFileName(LocalData.Path(n))).ToDictionary(d => d, d => d);
        return new BodyModIndex().RefreshState(dirs, LocalData.Path(LocalData.Mods)).List;
    }

    /// <summary>The mod copied to a temp folder (its models, manifest and record).</summary>
    private string Copy(string need)
    {
        string copy = Path.Combine(Path.GetTempPath(), "proteus-sizeset-men-" + Guid.NewGuid().ToString("N"));
        copies.Add(copy);
        SizeSetRefitTests.CopyModels(LocalData.Path(need), copy);
        return copy;
    }

    /// <summary>One of the author's sizes measured as a men's version's source: its made-for body bent for a man, how
    /// far that lies from the men's body, and what the job makes from it.</summary>
    internal sealed record Measured(string Option, string MadeFor, string? Layout, bool Yas, float BodyP90, float BodyMean,
                                    int Folds, double Coverage, long Ms, CrossSexRefitJob.Size? Size);

    /// <summary>
    /// Every one of the author's sizes of <paramref name="gamePath"/> in <paramref name="modNeed"/>, measured onto the
    /// men's body at <paramref name="targetRel"/> in <paramref name="targetNeed"/> — the steps the size set takes, each
    /// size with its own wearer (the game's skeleton).
    /// </summary>
    internal List<Measured> Measure(string modNeed, string gamePath, string targetNeed, string targetRel,
                                    IReadOnlyList<BodyModIndex.Entry> women)
    {
        var log = Substitute.For<IPluginLog>();
        string root = LocalData.Path(modNeed);
        var piece = SizeSetRefit.PiecesOf(root, Game, includeEnds: false)
                                .First(p => string.Equals(p.GamePath, gamePath, StringComparison.OrdinalIgnoreCase));
        string slot = piece.Slot;
        var mods = women.Select(b => (b.Dir, b.Catalog)).ToList();
        var men = OtherRaceRefit.OnlyRace(BodySizeCatalog.Read(LocalData.Path(targetNeed)), CrossSexRefit.Men);
        var onto = men.For(slot).First(b => RefitCore.Normal(b.Rel) == RefitCore.Normal(targetRel));
        string targetPath = men.PathOf(onto);
        var maps = Maps();
        var measured = new List<Measured>();
        foreach (var (option, file) in piece.Options)
        {
            byte[] bytes = File.ReadAllBytes(BodySizeCatalog.ResolveCaseInsensitive(root, file));
            var garment = ModelPartReader.Read(bytes)!;
            var bones = new HashSet<string>(SecondSkinWriter.Parse(bytes).BoneNames, StringComparer.Ordinal);
            var pick = RefitCore.DetectSource(garment, bones, slot, piece.Race, mods, mods[0].Dir, _ => true);
            if (pick == null || !AutoRefitDecisions.Proceed(pick.Confidence))
            {
                o.WriteLine($"{option ?? file}: made-for body not read");
                continue;
            }
            var entry = women.First(b => b.Dir == pick.Dir);
            string madeForPath = entry.Catalog.PathOf(pick.Option);
            string? layout = BodyCorrespondence.LayoutOf(ModelPartReader.Read(File.ReadAllBytes(madeForPath))!);
            bool yas = SupportedBodies.IsYas(bones);
            if (!SizeSetRefit.AcrossEligible(layout))
            {
                measured.Add(new Measured(option ?? file, $"{entry.Name} / {pick.Option.Label}", layout, yas, float.NaN,
                                          float.NaN, -1, 0, 0, null));
                continue;
            }
            string? cutFrom = piece.Group != null && option != null ? $"{piece.Group} / {option}" : null;
            var redirects = PenumbraModMeta.ReadAllRedirects(root);
            var wearerIn = OtherRaceWearer.Gather(CrossSexRefit.Men, gamePath, Game, _ => null,
                path => OtherRaceRefit.CarriedFile(redirects, cutFrom, path) is { } rel
                    ? File.ReadAllBytes(BodySizeCatalog.ResolveCaseInsensitive(root, rel)) : null,
                OtherRaceRefit.EstEntriesFor(PenumbraModMeta.TryReadGroups(root),
                                             PenumbraModMeta.TryReadDefaultData(root)?.Manipulations, cutFrom));
            var made = OtherRaceWearer.Build(wearerIn, ModelSkinReader.Read(bytes, null, null)!);
            Assert.True(made.Wearer != null, made.Refusal);
            var madeFor = entry.Catalog with { Options = [pick.Option] };
            var bent = BakedBodyCatalog.Lowered(madeFor, CrossSexRefit.Women, CrossSexRefit.Men, made.Wearer!, [slot],
                                                out var failed, byAlias: true, made.Planner);
            Assert.True(bent.For(slot).Count == 1, string.Join("; ", failed));
            var (p90, mean) = SizeSetRefit.BodyDistance(bent.PathOf(bent.For(slot)[0]), targetPath,
                                                        p => SizeSetRefit.BodyProbes(p));
            var clock = Stopwatch.StartNew();
            var job = CrossSexRefitJob.Run(new CrossSexRefitJob.Inputs(bytes, gamePath, CrossSexRefit.Men, madeFor, null, men,
                b => RefitCore.Normal(b.Rel) == RefitCore.Normal(targetRel), wearerIn, maps, log));
            var size = job.Sizes.FirstOrDefault();
            measured.Add(new Measured(option ?? file, $"{entry.Name} / {pick.Option.Label}", layout, yas, p90, mean,
                                      size?.Saved != null ? size.Folds : -1, size?.Landed?.VertexCoverage ?? 0,
                                      clock.ElapsedMilliseconds, size));
        }
        foreach (var m in measured)
            o.WriteLine($"{m.Option}: made on {m.MadeFor} ({m.Layout}{(m.Yas ? ", YAS" : "")}); bent body "
                        + $"{m.BodyP90 * 1000f:F1} mm (mean {m.BodyMean * 1000f:F1}); {m.Folds} folds, {m.Coverage:P1} "
                        + $"matched, {m.Ms} ms");
        return measured;
    }

    /// <summary>The one the size set chooses among <paramref name="measured"/>: rigged alike (not YAS) first, then the
    /// nearest bent body, ties to the author's order.</summary>
    internal static Measured Chosen(List<Measured> measured)
    {
        var may = measured.Where(m => m.Size != null).ToList();
        var alike = SizeSetRefit.RiggedAlike(may, m => m.Yas, targetYas: false);
        return SizeSetRefit.Choose(alike.Select(m => (m, new SizeSetRefit.SourceDistance(m.BodyP90, m.BodyMean, 0f, 0f,
                                                                                          measured.IndexOf(m))))
                                        .ToList()).Chosen;
    }

    /// <summary>The plan's step 1 rule: the size chosen folds no more than the fewest of the rest plus max(5, 10%).</summary>
    private void AssertChosenFoldsNearTheFewest(List<Measured> measured, string what)
    {
        var made = measured.Where(m => m.Folds >= 0).ToList();
        Assert.NotEmpty(made);
        var chosen = Chosen(measured);
        int fewest = made.Min(m => m.Folds);
        int allowed = fewest + Math.Max(5, (int)Math.Ceiling(fewest * 0.1));
        o.WriteLine($"{what}: chosen {chosen.Option} ({chosen.Folds} folds); fewest {fewest}; allowed {allowed}");
        Assert.True(chosen.Folds <= allowed,
                    $"{what}: the nearest bent body ({chosen.Option}) folds {chosen.Folds}, the fewest {fewest}");
    }

    [LocalDataFact(LocalData.GameData, Sheer, CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse,
                   CrossSexRefitLocalTests.TbseX, LocalData.TbseUvMaps)]
    [Trait("Plan", "AC-sizeset-cross-sex-3")]
    public void Sources_for_men_are_measured_sheer() // [AC-sizeset-cross-sex-3]
    {
        var women = Installed(CrossSexRefitLocalTests.Bibo);
        const string top = "chara/equipment/e6010/model/c0201e6010_top.mdl";
        AssertChosenFoldsNearTheFewest(Measure(Sheer, top, CrossSexRefitLocalTests.Tbse, TbseChestRel, women), "Sheer → TBSE");
        AssertChosenFoldsNearTheFewest(Measure(Sheer, top, CrossSexRefitLocalTests.TbseX, TbseXChestRel, women),
                                       "Sheer → TBSE-X");
    }

    [LocalDataFact(LocalData.GameData, RueTop, Yab, CrossSexRefitLocalTests.Rue, CrossSexRefitLocalTests.Bibo,
                   CrossSexRefitLocalTests.Tbse, LocalData.TbseUvMaps)]
    [Trait("Plan", "AC-sizeset-cross-sex-3")]
    public void Sources_for_men_are_measured_rue_top() // [AC-sizeset-cross-sex-3]
    {
        var women = Installed(Yab, CrossSexRefitLocalTests.Rue, CrossSexRefitLocalTests.Bibo);
        var piece = SizeSetRefit.PiecesOf(LocalData.Path(RueTop), Game, includeEnds: false).First(p => p.Slot == "_top");
        o.WriteLine($"{piece.GamePath} in {piece.Group}: {piece.Options.Count} sizes");
        var measured = Measure(RueTop, piece.GamePath, CrossSexRefitLocalTests.Tbse, TbseChestRel, women);
        if (measured.All(m => m.Size == null))
        {
            o.WriteLine("none of its sizes is on a layout the maps join: it gets no men's version");
            return;
        }
        AssertChosenFoldsNearTheFewest(measured, "Thursday top → TBSE");
    }

    [LocalDataFact(LocalData.GameData, Starlit, Yab, CrossSexRefitLocalTests.Rue, CrossSexRefitLocalTests.Bibo,
                   CrossSexRefitLocalTests.Tbse, LocalData.TbseUvMaps)]
    [Trait("Plan", "AC-sizeset-cross-sex-3")]
    public void Sources_for_men_are_measured_starlit_legs() // [AC-sizeset-cross-sex-3]
    {
        var women = Installed(Yab, CrossSexRefitLocalTests.Rue, CrossSexRefitLocalTests.Bibo);
        var piece = SizeSetRefit.PiecesOf(LocalData.Path(Starlit), Game, includeEnds: false).First(p => p.Slot == "_dwn");
        o.WriteLine($"{piece.GamePath} in {piece.Group}: {string.Join(", ", piece.Options.Select(x => x.Option))}");
        AssertChosenFoldsNearTheFewest(Measure(Starlit, piece.GamePath, CrossSexRefitLocalTests.Tbse, TbseLegsRel, women),
                                       "Starlit → TBSE");
    }

    /// <summary>A size set over <paramref name="bodies"/> with men's versions on, the men's skeleton from
    /// <paramref name="menSkeleton"/> (the game's when null); its notes and warnings printed.</summary>
    private SizeSetRefit.Result RunMen(string root, IReadOnlyList<string> keys, IReadOnlyList<BodyModIndex.Entry> bodies,
                                       bool remake = false, string? menSkeleton = null, Action<string>? progress = null,
                                       System.Threading.CancellationToken ct = default, Func<string, byte[]?>? readGame = null,
                                       IPluginLog? log = null, SizeSetRefit.RunLog? runLog = null)
    {
        log ??= Substitute.For<IPluginLog>();
        runLog ??= new SizeSetRefit.RunLog();
        var across = new SizeSetRefit.AcrossInputs(
            path => menSkeleton != null && path == OtherRaceWearer.BaseSkeletonPath(CrossSexRefit.Men) ? menSkeleton : null);
        int made = SizeSetRefit.Run(new SizeSetRefit.Request(root, keys, false, remake, bodies, readGame ?? Game,
                                                             Ends: false, Across: across),
                                    runLog, Maps(), log, progress ?? (_ => { }), ct);
        var result = new SizeSetRefit.Result(made, runLog.Notes.Distinct(StringComparer.Ordinal).ToList(),
                                             runLog.Warnings.Distinct(StringComparer.Ordinal).ToList(),
                                             SizeSetRefit.Summarize(runLog, made));
        o.WriteLine($"made {result.Made}");
        foreach (string note in result.Notes) o.WriteLine("note: " + note);
        foreach (string warning in result.Warnings ?? []) o.WriteLine("check: " + warning);
        return result;
    }

    /// <summary>What a substitute log was told at Information, formatted.</summary>
    private static List<string> Said(IPluginLog log)
        => log.ReceivedCalls().Where(c => c.GetMethodInfo().Name == nameof(IPluginLog.Information))
              .Select(c => c.GetArguments())
              .Where(a => a.Length == 2 && a[0] is string)
              .Select(a => string.Format((string)a[0]!, (object?[])(a[1] ?? Array.Empty<object>())))
              .ToList();

    /// <summary>
    /// Takes every men's version of <paramref name="gamePaths"/> out of <paramref name="option"/> in the copy at
    /// <paramref name="root"/> — its manifest entry and its record — so a run starts from a known state whatever the
    /// installed mod has been given since.
    /// </summary>
    private static void Without(string root, string group, string option, params string[] gamePaths)
    {
        bool Ours(string? path) => gamePaths.Any(p => string.Equals(p, path, StringComparison.OrdinalIgnoreCase));
        var manifests = new[] { Path.Combine(root, "meta.json") }.Concat(Directory.GetFiles(root, "group_*.json"));
        foreach (string file in manifests)
        {
            var json = System.Text.Json.Nodes.JsonNode.Parse(File.ReadAllText(file))!.AsObject();
            var groups = json["Groups"] is System.Text.Json.Nodes.JsonArray list ? list.OfType<System.Text.Json.Nodes.JsonObject>()
                       : (string?)json["Name"] == group ? [json] : [];
            bool changed = false;
            foreach (var g in groups.Where(g => (string?)g["Name"] == group))
                foreach (var o in (g["Options"] as System.Text.Json.Nodes.JsonArray ?? []).OfType<System.Text.Json.Nodes.JsonObject>()
                                                                                        .Where(o => (string?)o["Name"] == option))
                    if (o["Files"] is System.Text.Json.Nodes.JsonObject files)
                        foreach (string key in files.Select(f => f.Key).Where(Ours).ToList()) { files.Remove(key); changed = true; }
            if (changed) File.WriteAllText(file, json.ToJsonString(new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
        }
        string record = Path.Combine(root, "Proteus", "bodyretarget.json");
        if (!File.Exists(record)) return;
        var rec = System.Text.Json.Nodes.JsonNode.Parse(File.ReadAllText(record))!.AsObject();
        if (rec["Options"] is not System.Text.Json.Nodes.JsonArray entries) return;
        foreach (var e in entries.OfType<System.Text.Json.Nodes.JsonObject>()
                                 .Where(e => (string?)e["Name"] == option && Ours((string?)e["GamePath"])).ToList())
            entries.Remove(e);
        File.WriteAllText(record, rec.ToJsonString(new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
    }

    private static List<(string Name, string Json)> Groups(string root)
        => (PenumbraModMeta.TryReadGroups(root) ?? []).Select(g => (g.Name, g.Group.GetRawText())).ToList();

    private static string SheerTop => "chara/equipment/e6010/model/c0201e6010_top.mdl";

    /// <summary>The author's option Sheer's men's legs are cut from (read 2026-10-29).</summary>
    private const string SheerLegsCutFrom = "SFW- Opaque";
    private static string SheerMenTop => RacialModelBake.WithRace(SheerTop, CrossSexRefit.Men);

    private static float[] PositionsAt(string root, string group, string option, string gamePath)
    {
        var files = PenumbraModMeta.TryReadFileOptions(root, group)!.First(x => x.Name == option).Files;
        string rel = files.First(f => string.Equals(f.Key, gamePath, StringComparison.OrdinalIgnoreCase)).Value;
        return ModelPartReader.Read(File.ReadAllBytes(BodySizeCatalog.ResolveCaseInsensitive(root, rel)))!.Positions;
    }

    [LocalDataFact(LocalData.GameData, Sheer, CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse,
                   CrossSexRefitLocalTests.TbseX, LocalData.TbseUvMaps)]
    [Trait("Plan", "AC-sizeset-cross-sex-2")]
    [Trait("Plan", "AC-sizeset-cross-sex-4")]
    [Trait("Plan", "EDGE-sizeset-cross-sex-19")]
    [Trait("Plan", "EDGE-sizeset-cross-sex-24")]
    [Trait("Plan", "EDGE-sizeset-cross-sex-3")]
    [Trait("Plan", "AC-cross-sex-area-coverage-3")]
    [Trait("Plan", "AC-cross-sex-area-coverage-7")]
    [Trait("Plan", "EDGE-cross-sex-area-coverage-6")]
    [Trait("Plan", "AC-tbsex-nude-legs-1")]
    [Trait("Plan", "AC-tbsex-nude-legs-4")]
    [Trait("Plan", "AC-tbsex-nude-legs-7")]
    [Trait("Plan", "EDGE-tbsex-nude-legs-11")]
    [Trait("Plan", "EDGE-tbsex-nude-legs-12")]
    [Trait("Plan", "AC-equinox-legs-slits-7")]
    public void Sheer_elegance_gains_mens_versions() // [AC-sizeset-cross-sex-2] [AC-sizeset-cross-sex-4] [EDGE-sizeset-cross-sex-19] [EDGE-sizeset-cross-sex-24] [EDGE-sizeset-cross-sex-3] [AC-cross-sex-area-coverage-3] [AC-cross-sex-area-coverage-7] [EDGE-cross-sex-area-coverage-6] [AC-tbsex-nude-legs-1] [AC-tbsex-nude-legs-4] [AC-tbsex-nude-legs-7] [EDGE-tbsex-nude-legs-11] [EDGE-tbsex-nude-legs-12]
    {
        string root = Copy(Sheer);
        var across = SizeSetRefit.AcrossPieces(SizeSetRefit.PiecesOf(root, Game, includeEnds: false));
        o.WriteLine("crossed: " + string.Join(", ", across.Select(p => p.GamePath)));
        Assert.Contains(across, p => p.GamePath == SheerTop);
        // The mod ships the game's own men's trousers at c0101e6107_dwn: not a piece of the author's, so the women's legs
        // are crossed too.
        var legs = Assert.Single(across, p => p.Slot == "_dwn");
        var before = Groups(root);

        var runLog = new SizeSetRefit.RunLog();
        var result = RunMen(root, ["tbse@women", "tbse-x@women"],
                            Installed(CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse, CrossSexRefitLocalTests.TbseX),
                            runLog: runLog);
        var legsMade = runLog.Sizes.Where(s => s.Men && s.Slot == "_dwn" && s.Status == SizeSetRefit.SizeStatus.Made).ToList();
        Assert.Equal(["TBSE", "TBSE-X"], legsMade.Select(s => s.Option).Order(StringComparer.Ordinal));
        foreach (var made in legsMade) o.WriteLine($"{made.Option} legs cut from {made.CutFrom}, {made.Measures?.Folded} folded");
        Assert.Equal(SheerLegsCutFrom, legsMade.Single(s => s.Option == "TBSE").CutFrom);
        // The top on both. The legs are made on Bibo+'s nude Type A, whose crotch TBSE's SFW legs have no place for (88.3%
        // of the body, measured 2026-10-24): fitted to TBSE's Gen A legs instead (98.7%). TBSE-X's SFW legs match less
        // still, refused outright: fitted to its Flaccid M A legs instead (tbsex-nude-legs).
        Assert.Equal(4, result.Made);
        Assert.DoesNotContain(result.Notes, n => n.StartsWith(legs.Label + ": \"TBSE\"", StringComparison.Ordinal));
        Assert.DoesNotContain(result.Notes, n => n.StartsWith(legs.Label + ": \"TBSE-X\"", StringComparison.Ordinal));
        // Folded no worse than TBSE's Gen A fit by much (EDGE-12), both written down.
        int genAFolds = legsMade.Single(s => s.Option == "TBSE").Measures!.Folded;
        int flaccidFolds = legsMade.Single(s => s.Option == "TBSE-X").Measures!.Folded;
        Assert.True(flaccidFolds <= 1.25 * genAFolds + 10, $"TBSE-X legs {flaccidFolds} folds against TBSE's {genAFolds}");
        string legsMen = RacialModelBake.WithRace(legs.GamePath, CrossSexRefit.Men);
        across = [across.First(p => p.GamePath == SheerTop)];

        // One group appended after every other, the author's groups byte for byte as they were.
        var after = Groups(root);
        Assert.Equal(before.Count + 1, after.Count);
        for (int i = 0; i < before.Count; i++) Assert.Equal(before[i], after[i]);
        string men = Localization.Strings.SizeSet.MensGroup;
        Assert.Equal(men, after[^1].Name);
        Assert.Equal(BodyRetargetWriter.OriginalOption, PenumbraModMeta.SingleDefault(root, men));
        var options = PenumbraModMeta.TryReadFileOptions(root, men)!;
        Assert.Equal([BodyRetargetWriter.OriginalOption, "TBSE", "TBSE-X"], options.Select(x => x.Name));
        Assert.Empty(options[0].Files);
        foreach (var option in options.Skip(1))
        {
            foreach (var piece in across)
                Assert.Contains(option.Files.Keys, k => string.Equals(k, RacialModelBake.WithRace(piece.GamePath, CrossSexRefit.Men),
                                                                      StringComparison.OrdinalIgnoreCase));
            // Only the men's paths and the materials it publishes: nothing at a women's path.
            Assert.DoesNotContain(option.Files.Keys, k => k.Contains("/c0201", StringComparison.OrdinalIgnoreCase)
                                                          && k.EndsWith(".mdl", StringComparison.OrdinalIgnoreCase));
            var legsFile = option.Files.FirstOrDefault(f => string.Equals(f.Key, legsMen, StringComparison.OrdinalIgnoreCase));
            Assert.NotNull(legsFile.Value);
            // No material drawn by no mesh — Flaccid M A's piercing material in particular (EDGE-11).
            MaterialAssert.NoNewUndrawnNames(File.ReadAllBytes(BodySizeCatalog.ResolveCaseInsensitive(root, legsFile.Value)),
                                             File.ReadAllBytes(BodySizeCatalog.ResolveCaseInsensitive(root, legs.Options[0].File)));
            string meta = System.Text.Json.JsonSerializer.Serialize(option.Manipulations);
            Assert.Contains("Eqdp", meta);
        }

        // Its folds are said under "Check in game", never a refusal; and that men get one of the two variants.
        Assert.Contains(result.Warnings!, w => w.Contains("\"TBSE\"") && w.Contains("cloth face"));
        Assert.Contains(result.Warnings!, w => w.Contains("\"TBSE-X\"") && w.Contains("cloth face"));
        // equinox-legs-slits: the top is sized in "Chest size", the group the game draws it from (priority 1, over
        // "Content Type"), whose every option is a size — so it no longer says men get only its "SFW- Opaque" variant.
        Assert.DoesNotContain(result.Warnings!, w => w == string.Format(Localization.Strings.SizeSet.OneVariantFmt,
                                                                        across.First(p => p.GamePath == SheerTop).Label, "SFW- Opaque"));
    }

    [LocalDataFact(LocalData.GameData, Sheer, CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse, LocalData.TbseUvMaps)]
    [Trait("Plan", "AC-sizeset-cross-sex-4")]
    public void The_size_sets_mens_model_is_the_jobs() // [AC-sizeset-cross-sex-4]
    {
        string root = Copy(Sheer);
        var women = Installed(CrossSexRefitLocalTests.Bibo);
        var result = RunMen(root, ["tbse@women"], Installed(CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse));
        Assert.True(result.Made >= 1);
        var job = Chosen(Measure(Sheer, SheerTop, CrossSexRefitLocalTests.Tbse, TbseChestRel, women));
        var want = ModelPartReader.Read(job.Size!.Saved!.Model)!.Positions;
        var saved = PositionsAt(root, Localization.Strings.SizeSet.MensGroup, "TBSE", SheerMenTop);
        Assert.Equal(want.Length, saved.Length);
        for (int i = 0; i < want.Length; i++) Assert.True(MathF.Abs(want[i] - saved[i]) < 1e-5f, $"position {i} differs");
    }

    [LocalDataFact(LocalData.GameData, Sheer, CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse,
                   CrossSexRefitLocalTests.TbseX, LocalData.TbseUvMaps)]
    [Trait("Plan", "AC-sizeset-cross-sex-7")]
    [Trait("Plan", "EDGE-sizeset-cross-sex-12")]
    [Trait("Plan", "EDGE-sizeset-cross-sex-13")]
    public void Mens_versions_rerun_remake_cancel_and_undo() // [AC-sizeset-cross-sex-7] [EDGE-sizeset-cross-sex-12] [EDGE-sizeset-cross-sex-13]
    {
        string root = Copy(Sheer);
        var bodies = Installed(CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse, CrossSexRefitLocalTests.TbseX);
        string men = Localization.Strings.SizeSet.MensGroup;
        int made = RunMen(root, ["tbse@women"], bodies).Made;
        Assert.True(made >= 1);
        int at = Groups(root).FindIndex(g => g.Name == men);

        // Again: nothing to make.
        Assert.Equal(0, RunMen(root, ["tbse@women"], bodies).Made);
        // Made again: replaced in place.
        Assert.Equal(made, RunMen(root, ["tbse@women"], bodies, remake: true).Made);
        Assert.Equal(at, Groups(root).FindIndex(g => g.Name == men));
        Assert.Equal(["Original", "TBSE"], PenumbraModMeta.TryReadFileOptions(root, men)!.Select(x => x.Name));

        // Stopped while TBSE-X is made: TBSE stays, TBSE-X is not saved, the default is "Original".
        using var cancel = new System.Threading.CancellationTokenSource();
        Assert.ThrowsAny<OperationCanceledException>(() => RunMen(root, ["tbse@women", "tbse-x@women"], bodies, remake: true,
            progress: p => { if (p.Contains("TBSE-X", StringComparison.Ordinal)) cancel.Cancel(); }, ct: cancel.Token));
        Assert.Equal(["Original", "TBSE"], PenumbraModMeta.TryReadFileOptions(root, men)!.Select(x => x.Name));
        Assert.Equal(BodyRetargetWriter.OriginalOption, PenumbraModMeta.SingleDefault(root, men));

        // Undone: the group goes once only "Original" is left; the author's groups as they were.
        Assert.True(BodyRetargetWriter.Undo(root, men, "TBSE").Ok);
        Assert.DoesNotContain(Groups(root), g => g.Name == men);
    }

    /// <summary>The men's skeleton the collection gives: the game's (none), IVCS, or a file that is not there.</summary>
    public static TheoryData<string> MenSkeletons => new() { "game", "ivcs", "missing" };

    [LocalDataTheory(LocalData.GameData, Starlit, Yab, CrossSexRefitLocalTests.Rue, CrossSexRefitLocalTests.Bibo,
                     CrossSexRefitLocalTests.Tbse, CrossSexRefitLocalTests.IvcsMen, LocalData.TbseUvMaps)]
    [MemberData(nameof(MenSkeletons))]
    [Trait("Plan", "AC-sizeset-cross-sex-8")]
    [Trait("Plan", "EDGE-sizeset-cross-sex-8")]
    [Trait("Plan", "EDGE-sizeset-cross-sex-9")]
    [Trait("Plan", "AC-cross-sex-area-coverage-4")]
    [Trait("Plan", "AC-cross-sex-area-coverage-7")]
    [Trait("Plan", "EDGE-cross-sex-area-coverage-16")]
    [Trait("Plan", "EDGE-cross-sex-area-coverage-14")]
    public void Starlit_gains_mens_versions_with_its_bones_moved(string skeleton) // [AC-sizeset-cross-sex-8] [EDGE-sizeset-cross-sex-8] [EDGE-sizeset-cross-sex-9] [AC-cross-sex-area-coverage-4] [AC-cross-sex-area-coverage-7] [EDGE-cross-sex-area-coverage-16] [EDGE-cross-sex-area-coverage-14]
    {
        string root = Copy(Starlit);
        string? from = skeleton switch
        {
            "ivcs" => LocalData.Path(CrossSexRefitLocalTests.IvcsMen),
            "missing" => Path.Combine(root, "no-such-skeleton.sklb"),
            _ => null,
        };
        var log = Substitute.For<IPluginLog>();
        var result = RunMen(root, ["tbse@women"],
                            Installed(Yab, CrossSexRefitLocalTests.Rue, CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse),
                            menSkeleton: from, log: log);
        Assert.Equal(1, result.Made);
        // Made on Rue+'s nude legs, yet matching TBSE's SFW legs enough (90.1%): kept on them, as before.
        Assert.DoesNotContain(Said(log), l => l.Contains("the SFW legs matched", StringComparison.Ordinal));
        var sfw = BodySizeCatalog.Read(LocalData.Path(CrossSexRefitLocalTests.Tbse)).Options
                                 .First(b => RefitCore.Normal(b.Rel) == RefitCore.Normal(UvBakeInputs.TbseLegs[0].Rel));
        Assert.Contains(BodyRetargetWriter.ReadRecord(root)!.Options,
                        e => e.Name == "TBSE" && e.GamePath.EndsWith("_dwn.mdl", StringComparison.OrdinalIgnoreCase) && e.To == sfw.Label);
        // Every size of Starlit is rigged to YAS's own bones: moved onto the men's, and said.
        string moved = Assert.Single(result.Warnings!, w => w.Contains("\"TBSE\"") && w.Contains("→"));
        bool needs = result.Warnings!.Any(w => w.Contains("[IVCS]"));
        if (skeleton == "ivcs")
        {
            // IVCS has the men's own physics bones: the women's are moved onto them, which only IVCS gives.
            Assert.Contains("→ iv_", moved);
            Assert.True(needs, "the IVCS-only bones are said");
        }
        else
        {
            // The game's skeleton (or a collection file that is not there, which falls back to it) has none of them.
            Assert.DoesNotContain("→ iv_", moved);
            Assert.False(needs);
        }
        var piece = SizeSetRefit.PiecesOf(root, Game, includeEnds: false).First(p => p.Slot == "_dwn");
        var options = PenumbraModMeta.TryReadFileOptions(root, Localization.Strings.SizeSet.MensGroup)!;
        Assert.Contains(options.First(x => x.Name == "TBSE").Files.Keys,
                        k => string.Equals(k, RacialModelBake.WithRace(piece.GamePath, CrossSexRefit.Men), StringComparison.OrdinalIgnoreCase));
    }

    [LocalDataFact(LocalData.GameData, Sheer, CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse, LocalData.TbseUvMaps)]
    [Trait("Plan", "EDGE-sizeset-cross-sex-22")]
    [Trait("Plan", "EDGE-sizeset-cross-sex-23")]
    public void Unreadable_and_missing_bodies_are_said_once() // [EDGE-sizeset-cross-sex-22] [EDGE-sizeset-cross-sex-23]
    {
        // TBSE-X not installed: said once per piece, and TBSE still made.
        string root = Copy(Sheer);
        var result = RunMen(root, ["tbse@women", "tbse-x@women"], Installed(CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse));
        var top = SizeSetRefit.PiecesOf(root, Game, includeEnds: false).First(p => p.GamePath == SheerTop);
        Assert.Single(result.Notes, n => n == string.Format(Localization.Strings.SizeSet.NotInstalledFmt, top.Label, "TBSE-X"));
        Assert.True(result.Made >= 1);

        // No women's body its sizes read as made on: said once, with where to choose it, nothing written.
        string other = Copy(Sheer);
        var before = Groups(other);
        result = RunMen(other, ["tbse@women"], Installed(CrossSexRefitLocalTests.Tbse));
        Assert.Single(result.Notes, n => n == string.Format(Localization.Strings.SizeSet.UnreadableMadeOnFmt, top.Label));
        Assert.Equal(before, Groups(other));
    }

    [LocalDataFact(LocalData.GameData, Sheer, CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse, LocalData.TbseUvMaps)]
    [Trait("Plan", "AC-sizeset-cross-sex-5")]
    [Trait("Plan", "EDGE-sizeset-cross-sex-20")]
    public void No_mens_wearer_is_said_with_why() // [AC-sizeset-cross-sex-5] [EDGE-sizeset-cross-sex-20]
    {
        // The game's racial deformer can't be read: no men's wearer for any size. Said as that, nothing written.
        string root = Copy(Sheer);
        var before = Groups(root);
        var result = RunMen(root, ["tbse@women"], Installed(CrossSexRefitLocalTests.Bibo, CrossSexRefitLocalTests.Tbse),
                            readGame: path => path == OtherRaceWearer.PbdPath ? null : Game(path));
        Assert.Equal(0, result.Made);
        var top = SizeSetRefit.PiecesOf(root, Game, includeEnds: false).First(p => p.GamePath == SheerTop);
        string note = Assert.Single(result.Notes, n => n.StartsWith(top.Label + ": \"TBSE\"", StringComparison.Ordinal));
        Assert.Contains("deformer", note);
        Assert.DoesNotContain(result.Notes, n => n == string.Format(Localization.Strings.SizeSet.NoSourceForMenFmt, top.Label));
        Assert.Equal(before, Groups(root));
    }

    internal static string TbseChestRel =>SupportedBodies.Of("tbse", "_top", false)!.Sizes[0].Rel;
    internal static string TbseXChestRel => SupportedBodies.Of("tbse-x", "_top", false)!.Sizes[0].Rel;
    internal static string TbseLegsRel => SupportedBodies.Of("tbse", "_dwn", false)!.Sizes[0].Rel;

    internal const string Stormblessed = LocalData.Mods + ":Stormblessed - by Solona";

    [LocalDataFact(LocalData.GameData, Stormblessed, CrossSexNudeLegsLocalTests.LavaBod, CrossSexRefitLocalTests.Tbse,
                   LocalData.TbseUvMaps)]
    [Trait("Plan", "AC-cross-sex-area-coverage-1")]
    [Trait("Plan", "AC-cross-sex-area-coverage-8")]
    [Trait("Plan", "EDGE-cross-sex-area-coverage-8")]
    [Trait("Plan", "EDGE-cross-sex-area-coverage-14")]
    [Trait("Plan", "EDGE-cross-sex-area-coverage-17")]
    public void Stormblessed_gains_mens_legs() // [AC-cross-sex-area-coverage-1] [AC-cross-sex-area-coverage-8] [EDGE-cross-sex-area-coverage-8] [EDGE-cross-sex-area-coverage-14] [EDGE-cross-sex-area-coverage-17]
    {
        string root = Copy(Stormblessed);
        string men = Localization.Strings.SizeSet.MensGroup;
        var legs = SizeSetRefit.AcrossPieces(SizeSetRefit.PiecesOf(root, Game, includeEnds: false))
                               .First(p => p.Slot == "_dwn" && p.GamePath.Contains("e0633", StringComparison.Ordinal));
        string legsMen = RacialModelBake.WithRace(legs.GamePath, CrossSexRefit.Men);
        // The state this is about: "TBSE" already carries the men's top, made by an earlier run, and not yet the legs.
        Without(root, men, "TBSE", legs.GamePath, legsMen);
        var top = SizeSetRefit.AcrossPieces(SizeSetRefit.PiecesOf(root, Game, includeEnds: false))
                              .First(p => p.Slot == "_top" && p.GamePath.Contains("e0633", StringComparison.Ordinal));
        Assert.True((PenumbraModMeta.TryReadFileOptions(root, men) ?? []).Any(x => x.Name == "TBSE" && x.Files.Keys
                        .Any(k => string.Equals(k, RacialModelBake.WithRace(top.GamePath, CrossSexRefit.Men),
                                                StringComparison.OrdinalIgnoreCase))),
                    "the installed mod's \"TBSE\" no longer carries the men's top this test starts from");
        var authors = Groups(root).Where(g => g.Name != men).ToList();
        var bodies = Installed(CrossSexNudeLegsLocalTests.LavaBod, CrossSexRefitLocalTests.Tbse);
        var log = Substitute.For<IPluginLog>();
        var runLog = new SizeSetRefit.RunLog();

        var result = RunMen(root, ["tbse@women"], bodies, log: log, runLog: runLog);
        Assert.DoesNotContain(result.Notes, n => n.StartsWith(legs.Label + ": \"TBSE\"", StringComparison.Ordinal));
        // The report says made, with the share of the legs it was fitted to.
        var outcome = Assert.Single(runLog.Sizes, s => s.Men && s.Piece == legs.Label && s.Option == "TBSE");
        Assert.Equal(SizeSetRefit.SizeStatus.Made, outcome.Status);
        Assert.True(outcome.Measures?.Coverage >= 0.9, $"{outcome.Measures?.Coverage} matched");
        // Into the option that carries the top, the top not made again.
        var topOutcome = Assert.Single(runLog.Sizes, s => s.Men && s.Piece == top.Label && s.Option == "TBSE");
        Assert.Equal(SizeSetRefit.SizeStatus.Skipped, topOutcome.Status);
        Assert.Equal(SizeSetRefit.Codes.AlreadyThere, topOutcome.ReasonCode);
        Assert.Equal(men, Groups(root)[^1].Name);
        var option = PenumbraModMeta.TryReadFileOptions(root, men)!.First(x => x.Name == "TBSE");
        Assert.Contains(option.Files.Keys, k => string.Equals(k, legsMen, StringComparison.OrdinalIgnoreCase));
        Assert.Contains("Eqdp", System.Text.Json.JsonSerializer.Serialize(option.Manipulations));
        foreach (string file in option.Files.Values)
            Assert.True(File.Exists(BodySizeCatalog.ResolveCaseInsensitive(root, file)), $"{file} is not in the mod");

        // Fitted to TBSE's Gen A legs, said so, and the record names them.
        var genA = BodySizeCatalog.Read(LocalData.Path(CrossSexRefitLocalTests.Tbse)).Options
                                  .First(b => RefitCore.Normal(b.Rel) == RefitCore.Normal(UvBakeInputs.TbseLegs[1].Rel));
        var said = Said(log);
        foreach (string line in said.Where(l => l.Contains("for men", StringComparison.Ordinal))) o.WriteLine(line);
        Assert.Contains(said, l => l.Contains(legs.Label, StringComparison.Ordinal) && l.Contains("on " + genA.Label, StringComparison.Ordinal)
                                   && l.Contains("the SFW legs matched", StringComparison.Ordinal));
        Assert.Contains(BodyRetargetWriter.ReadRecord(root)!.Options,
                        e => e.Name == "TBSE" && string.Equals(e.GamePath, legsMen, StringComparison.OrdinalIgnoreCase) && e.To == genA.Label);

        // The author's groups as they were (by value: Penumbra had indented this copy with tabs); again, nothing to make.
        var now = Groups(root).Where(g => g.Name != men).ToList();
        Assert.Equal(authors.Select(g => g.Name), now.Select(g => g.Name));
        for (int i = 0; i < authors.Count; i++)
            Assert.True(System.Text.Json.Nodes.JsonNode.DeepEquals(System.Text.Json.Nodes.JsonNode.Parse(authors[i].Json),
                                                                   System.Text.Json.Nodes.JsonNode.Parse(now[i].Json)),
                        $"\"{authors[i].Name}\" changed");
        Assert.Equal(0, RunMen(root, ["tbse@women"], bodies).Made);
    }

    /// <summary>
    /// Stormblessed as the user has it: its men's group's "TBSE" already holding the men's top and legs, the boots and
    /// gloves the author packed for men only the game's own. Sized for men again with shoes and gloves on and no remake:
    /// the women's boots and gloves get men's versions in "TBSE", with their EQDP entries, and the top and legs are left
    /// as they are (mens-ends-crotch).
    /// </summary>
    [LocalDataFact(LocalData.GameData, Stormblessed, CrossSexNudeLegsLocalTests.LavaBod, CrossSexRefitLocalTests.Tbse,
                   LocalData.TbseUvMaps)]
    [Trait("Plan", "AC-mens-ends-crotch-1")]
    [Trait("Plan", "AC-mens-ends-crotch-2")]
    [Trait("Plan", "AC-mens-ends-crotch-3")]
    [Trait("Plan", "AC-mens-ends-crotch-4")]
    [Trait("Plan", "EDGE-mens-ends-crotch-1")]
    [Trait("Plan", "EDGE-mens-ends-crotch-23")]
    public void Stormblessed_gains_mens_boots_and_gloves() // [AC-mens-ends-crotch-1] [AC-mens-ends-crotch-2] [AC-mens-ends-crotch-3] [AC-mens-ends-crotch-4] [EDGE-mens-ends-crotch-1] [EDGE-mens-ends-crotch-23]
    {
        string root = Copy(Stormblessed);
        string men = Localization.Strings.SizeSet.MensGroup;
        var pieces = SizeSetRefit.PiecesOf(root, Game, includeEnds: true);
        Assert.DoesNotContain(pieces, p => p.GamePath.Contains("/c0101e0633_", StringComparison.Ordinal) && p.Slot is "_sho" or "_glv");
        var across = SizeSetRefit.AcrossPieces(pieces);
        Assert.Contains(across, p => p.Slot == "_sho");
        Assert.Contains(across, p => p.Slot == "_glv");
        var authors = Groups(root).Where(g => g.Name != men).ToList();

        var bodies = Installed(CrossSexNudeLegsLocalTests.LavaBod, CrossSexRefitLocalTests.Tbse);
        string[] keys = ["tbse@women"];
        var gameBodies = SizeSetRefit.GameBodies(keys, Game, ends: true);
        var log = Substitute.For<IPluginLog>();
        var runLog = new SizeSetRefit.RunLog();
        int made = SizeSetRefit.Run(new SizeSetRefit.Request(root, keys, false, false, bodies, Game, Ends: true,
                                                             race => gameBodies.GetValueOrDefault(race),
                                                             Across: new SizeSetRefit.AcrossInputs(_ => null)),
                                    runLog, Maps(), log, _ => { }, default);
        foreach (var line in Said(log).Where(l => l.Contains("for men", StringComparison.Ordinal))) o.WriteLine(line);
        foreach (var w in runLog.Warnings) o.WriteLine("check: " + w);
        foreach (var n in runLog.Notes) o.WriteLine("note: " + n);

        Assert.Equal(2, made);
        foreach (string slot in new[] { "_sho", "_glv" })
        {
            var outcome = Assert.Single(runLog.Sizes, s => s.Men && s.Slot == slot && s.Option == "TBSE");
            Assert.Equal(SizeSetRefit.SizeStatus.Made, outcome.Status);
            Assert.True(outcome.Measures?.Coverage >= 0.9, $"{slot}: {outcome.Measures?.Coverage}");
        }
        foreach (string slot in new[] { "_top", "_dwn" })
            Assert.Equal(SizeSetRefit.Codes.AlreadyThere,
                         Assert.Single(runLog.Sizes, s => s.Men && s.Slot == slot && s.Option == "TBSE").ReasonCode);

        var option = PenumbraModMeta.TryReadFileOptions(root, men)!.First(x => x.Name == "TBSE");
        string manips = System.Text.Json.JsonSerializer.Serialize(option.Manipulations);
        foreach (string slot in new[] { "_sho", "_glv" })
        {
            string path = $"chara/equipment/e0633/model/c0101e0633{slot}.mdl";
            Assert.Contains(option.Files.Keys, k => string.Equals(k, path, StringComparison.OrdinalIgnoreCase));
            Assert.True(File.Exists(BodySizeCatalog.ResolveCaseInsensitive(root, option.Files.First(
                f => string.Equals(f.Key, path, StringComparison.OrdinalIgnoreCase)).Value)));
        }
        Assert.Contains("Feet", manips);
        Assert.Contains("Hands", manips);
        // The boots have no skin and no installed body's legs their cloth sits on: made on the body the outfit's own legs
        // read as (LavaBod+'s Gen A, installed here), and said — since hands-feet-port's outfit-legs rule (build 1409).
        var boots = Assert.Single(runLog.Sizes, s => s.Men && s.Slot == "_sho" && s.Option == "TBSE");
        Assert.Contains(runLog.Warnings, w => w == string.Format(Localization.Strings.SizeSet.EndFromOutfitLegsFmt,
                                                                 across.First(p => p.Slot == "_sho").Label, "TBSE",
                                                                 boots.From, "c0201e0633_dwn.mdl"));

        var now = Groups(root).Where(g => g.Name != men).ToList();
        Assert.Equal(authors.Select(g => g.Name), now.Select(g => g.Name));
        Assert.Equal(men, Groups(root)[^1].Name);
    }
}
