using System;
using System.Collections.Generic;
using System.Linq;
using Proteus.Services;
using Xunit;

namespace Proteus.Tests;

/// <summary>
/// Refitting across bodies: the cloth's body weights come from the new body, every bone of the garment's own keeps
/// its weights, and no vertex ever has more than eight influences.
/// </summary>
public class BodyWeightsTests
{
    private const string Skin = "/mt_c0201b0001_bibo.mtrl";
    private const string Cloth = "/mt_c0201e6255_top_a.mtrl";
    private const string Piercings = "/mt_c0201b0001_piercings.mtrl";

    private static readonly IReadOnlySet<string> BodyBones = new HashSet<string> { "j_kosi", "j_mune_l", "j_mune_r" };

    // ── the rule for one vertex ────────────────────────────────────────────────────────────────────────

    [Fact]
    public void A_vertex_on_the_body_takes_the_new_body_s_weights()
    {
        var w = BodyRetarget.Combine([("j_kosi", 1f)], [("j_mune_l", 0.6f), ("j_kosi", 0.4f)], BodyBones, out bool cut)!;

        Assert.False(cut);
        Assert.Equal(0.6f, w.Single(i => i.Bone == "j_mune_l").W, 3);
        Assert.Equal(0.4f, w.Single(i => i.Bone == "j_kosi").W, 3);
    }

    [Fact]
    public void A_vertex_on_the_garment_s_own_bones_is_not_touched()
    {
        Assert.Null(BodyRetarget.Combine([("j_sk_b_a_l", 1f)], [("j_mune_l", 1f)], BodyBones, out _));
    }

    [Fact]
    public void A_blended_vertex_keeps_its_own_share_and_the_body_takes_the_rest()
    {
        var w = BodyRetarget.Combine([("j_sk_b_a_l", 0.3f), ("j_kosi", 0.7f)],
                                     [("j_mune_l", 0.5f), ("j_mune_r", 0.5f)], BodyBones, out _)!;

        Assert.Equal(("j_sk_b_a_l", 0.3f), w[0]);                              // first, and exactly
        Assert.Equal(0.35f, w.Single(i => i.Bone == "j_mune_l").W, 3);
        Assert.Equal(0.35f, w.Single(i => i.Bone == "j_mune_r").W, 3);
        Assert.DoesNotContain(w, i => i.Bone == "j_kosi");
    }

    [Fact]
    public void Six_skirt_influences_leave_room_for_two_body_ones()
    {
        var mine = Enumerable.Range(0, 6).Select(k => ($"j_sk_{k}", 0.1f)).Append(("j_kosi", 0.4f)).ToList();
        var body = Enumerable.Range(0, 5).Select(k => ($"j_mune_{k}", 0.1f + k * 0.05f)).ToList();
        var bones = new HashSet<string>(body.Select(b => b.Item1)) { "j_kosi" };

        var w = BodyRetarget.Combine(mine, body, bones, out bool cut)!;

        Assert.True(cut);
        Assert.Equal(8, w.Length);
        Assert.Equal(6, w.Count(i => i.Bone.StartsWith("j_sk_", StringComparison.Ordinal)));
        Assert.All(w.Where(i => i.Bone.StartsWith("j_sk_", StringComparison.Ordinal)), i => Assert.Equal(0.1f, i.W, 5));
        // The two strongest body influences, sharing the body's 0.4.
        Assert.Equal(["j_mune_4", "j_mune_3"], w.Skip(6).Select(i => i.Bone));
        Assert.Equal(0.4f, w.Skip(6).Sum(i => i.W), 4);
    }

    [Fact]
    public void Eight_skirt_influences_take_the_whole_vertex()
    {
        var mine = Enumerable.Range(0, 8).Select(k => ($"j_sk_{k}", 0.1f)).Append(("j_kosi", 0.2f)).ToList();
        var w = BodyRetarget.Combine(mine, [("j_mune_l", 1f)], BodyBones, out bool cut)!;

        Assert.True(cut);
        Assert.Equal(8, w.Length);
        Assert.All(w, i => Assert.StartsWith("j_sk_", i.Bone));
        Assert.Equal(1f, w.Sum(i => i.W), 4);
    }

    // ── through a real model file ──────────────────────────────────────────────────────────────────────

    /// <summary>A body: one skin mesh whose every vertex follows <paramref name="weights"/>.</summary>
    private static byte[] Body(params (string, float)[] weights)
        => SyntheticModel.Build([], new SyntheticModel.Mesh(Skin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3,
                                                                                         Weights: weights)));

    /// <summary>The refitted slot: from <paramref name="source"/> onto <paramref name="target"/>.</summary>
    private static BodyRetarget.SlotPair Pair(byte[] source, byte[] target)
    {
        var t = ModelPartReader.Read(target)!;
        Assert.True(IdentityCorrespondence.TryBuild(t, t, "chest", out var built, out string why), why);
        return new BodyRetarget.SlotPair("_top", built!, t, target, source);
    }

    /// <summary>Every vertex's influences, by bone name, in the part reader's order.</summary>
    private static List<(string Bone, float W)>[] Weights(byte[] mdl)
    {
        var skin = ModelSkinReader.Read(mdl, null, null)!;
        var all = new List<(string, float)>[skin.VertexCount];
        for (int v = 0; v < skin.VertexCount; v++)
        {
            all[v] = [];
            for (int k = 0; k < XivLiveMesh.SkinnedMesh.MaxInfluences; k++)
            {
                float w = skin.BoneWeights[v * 8 + k];
                if (w > 0f) all[v].Add((skin.BoneNames[skin.BoneIndices[v * 8 + k]], w));
            }
        }
        return all;
    }

    private static int[] VerticesOf(byte[] mdl, string material, int sub)
        => ModelPartReader.Read(mdl)!.Parts.Where(p => p.Island < 0 && p.Material == material)
                                          .ElementAt(sub).Triangles.Distinct().ToArray();

    [Fact]
    public void Refitting_across_rigs_rewrites_the_cloth_and_keeps_the_garment_s_own_bones()
    {
        var source = Body(("j_kosi", 1f));
        var target = Body(("j_mune_l", 0.6f), ("j_kosi", 0.4f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Skin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Cloth,
                new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f, Weights: [("j_kosi", 1f)]),
                new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f, Weights: [("j_sk_b_a_l", 1f)]),
                new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f,
                                       Weights: [("j_sk_b_a_l", 0.5f), ("j_kosi", 0.5f)])));
        var pairs = new[] { Pair(source, target) };

        // The rule underneath: cloth lying ON the body is now rigged as the body outright (see the tests below), which
        // would hide it here, where every sheet lies 1 mm off.
        var plan = BodyRetarget.WithTuning(NoHug, () => BodyRetarget.PlanWeights(garment, pairs));
        Assert.NotNull(plan);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out var report)!;
        Assert.Equal(0, report.Unplaced);

        var before = Weights(garment);
        var after = Weights(rebuilt);

        // On the body: the new body's weights, j_mune_l included although the garment never had that bone.
        Assert.Contains("j_mune_l", SecondSkinWriter.Parse(rebuilt).BoneNames);
        foreach (int v in VerticesOf(garment, Cloth, 0))
        {
            Assert.Equal(0.6f, after[v].Single(i => i.Bone == "j_mune_l").W, 2);
            Assert.Equal(0.4f, after[v].Single(i => i.Bone == "j_kosi").W, 2);
        }

        // On the skirt alone: exactly as it was.
        foreach (int v in VerticesOf(garment, Cloth, 1))
            Assert.Equal(before[v], after[v]);

        // Half skirt, half body: the skirt's half kept, the body's half from the new body.
        foreach (int v in VerticesOf(garment, Cloth, 2))
        {
            Assert.Equal(0.5f, after[v].Single(i => i.Bone == "j_sk_b_a_l").W, 2);
            Assert.Equal(0.3f, after[v].Single(i => i.Bone == "j_mune_l").W, 2);
            Assert.Equal(0.2f, after[v].Single(i => i.Bone == "j_kosi").W, 2);
        }
    }

    /// <summary>
    /// SKIN needing more than four influences is widened to eight, because <c>skin.shpk</c> reads eight — a body
    /// mod's own meshes are the proof, the Neolithe body carrying 1058 five-influence vertices and drawing right.
    /// </summary>
    [Fact]
    public void Skin_needing_more_than_four_influences_is_widened_to_eight()
    {
        var source = Body(("j_kosi", 1f));
        var target = Body(("j_mune_l", 0.25f), ("j_mune_r", 0.25f), ("j_kosi", 0.25f), ("j_sebo_b", 0.25f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Skin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f,
                Weights: [("j_sk_b_a_l", 0.2f), ("j_sk_b_a_r", 0.2f), ("j_kosi", 0.6f)])));
        var pairs = new[] { Pair(source, target) };

        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, BodyRetarget.PlanWeights(garment, pairs),
                                           out _)!;

        var after = Weights(rebuilt);
        Assert.All(VerticesOf(garment, Skin, 0), v =>
        {
            Assert.Equal(6, after[v].Count);                                    // two skirt, four body
            Assert.True(after[v].Count <= 8);
            Assert.Equal(1f, after[v].Sum(i => i.W), 2);
        });
        var decl = SecondSkinWriter.Parse(rebuilt).Decls[0];
        Assert.Contains(decl, e => e.Usage == SecondSkinWriter.UseBlendWeight && e.Type == 17);
    }

    /// <summary>
    /// CLOTH is not. The character shaders declare their vertex input as <c>float4 blendWeight</c> and
    /// <c>int4 blendIndices</c>, so a fifth influence is never read: the weights the shader sees would sum to less
    /// than one and draw the vertex pulled toward the origin, a dent whose inner surface reads as a dark band.
    /// <para/>
    /// So the mesh keeps its four slots, and what is dropped is folded back into the largest — the weights the
    /// shader reads still come to exactly one, which is the whole point.
    /// </summary>
    [Fact]
    public void Cloth_needing_more_than_four_influences_keeps_its_four()
    {
        var source = Body(("j_kosi", 1f));
        var target = Body(("j_mune_l", 0.25f), ("j_mune_r", 0.25f), ("j_kosi", 0.25f), ("j_sebo_b", 0.25f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f,
                Weights: [("j_sk_b_a_l", 0.2f), ("j_sk_b_a_r", 0.2f), ("j_kosi", 0.6f)])));
        var pairs = new[] { Pair(source, target) };

        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, BodyRetarget.PlanWeights(garment, pairs),
                                           out _)!;

        var after = Weights(rebuilt);
        Assert.All(VerticesOf(garment, Cloth, 0), v =>
        {
            Assert.True(after[v].Count <= 4, $"vertex {v} kept {after[v].Count} influences");
            Assert.Equal(1f, after[v].Sum(i => i.W), 2);
        });
        var decl = SecondSkinWriter.Parse(rebuilt).Decls[0];
        Assert.DoesNotContain(decl, e => e.Usage == SecondSkinWriter.UseBlendWeight && e.Type == 17);
    }

    [Fact]
    public void The_bytes_always_come_to_255_even_when_the_first_influence_is_tiny()
    {
        // A kept skirt influence of 0.4% leads (one byte); four body weights each round UP. The error must not land on
        // the one-byte influence, which cannot absorb it.
        (string, float)[] w = [("j_sk_b_a_l", 0.004f), ("a", 0.2495f), ("b", 0.2495f), ("c", 0.2495f), ("d", 0.2495f)];
        var names = w.Select(i => i.Item1).ToList();
        Span<byte> wb = stackalloc byte[8], ib = stackalloc byte[8];
        int dropped = 0;

        int trimmed = 0;
        int used = SecondSkinWriter.EncodeBlend(w, 8, bone => names.IndexOf(bone), wb, ib, ref dropped, ref trimmed);

        Assert.Equal(5, used);
        int sum = 0;
        for (int k = 0; k < 8; k++) sum += wb[k];
        Assert.Equal(255, sum);
        Assert.Equal(1, wb[0]);                                                // the skirt's byte, untouched
    }

    /// <summary>
    /// Too many influences for the slots: the HEAVIEST are kept, not the first.
    /// <para/>
    /// The planner lists a vertex's own garment bones ahead of the new body's share and plans to eight slots. Taking
    /// the front of the list on a four-slot cloth mesh therefore drops the body share whole wherever the garment's
    /// own bones already fill four — and that vertex stays rigged to the body the garment was made for while the
    /// cloth beside it follows the new one, which comes apart as soon as a bone turns.
    /// </summary>
    [Fact]
    public void Trimming_to_the_slots_keeps_the_heaviest_not_the_first()
    {
        // Four small garment bones first, then the body's share — the order Combine returns.
        (string, float)[] w = [("own_a", 0.05f), ("own_b", 0.05f), ("own_c", 0.05f), ("own_d", 0.05f),
                               ("body_l", 0.40f), ("body_r", 0.40f)];
        var names = w.Select(i => i.Item1).ToList();
        Span<byte> wb = stackalloc byte[8], ib = stackalloc byte[8];
        int dropped = 0, trimmed = 0;

        int used = SecondSkinWriter.EncodeBlend(w, 4, bone => names.IndexOf(bone), wb, ib, ref dropped, ref trimmed);

        Assert.Equal(4, used);
        Assert.Equal(2, trimmed);
        Assert.Equal(0, dropped);

        // Both body bones survived; two of the four small garment ones went.
        var kept = new List<string>();
        for (int k = 0; k < 4; k++)
            if (wb[k] > 0) kept.Add(names[ib[k]]);
        Assert.Contains("body_l", kept);
        Assert.Contains("body_r", kept);

        int sum = 0;
        for (int k = 0; k < 4; k++) sum += wb[k];
        Assert.Equal(255, sum);
    }

    /// <summary>A list that fits is written in the order given, untouched, and counts no trim.</summary>
    [Fact]
    public void A_list_that_fits_the_slots_is_not_reordered()
    {
        (string, float)[] w = [("own_a", 0.1f), ("body_l", 0.9f)];
        var names = w.Select(i => i.Item1).ToList();
        Span<byte> wb = stackalloc byte[8], ib = stackalloc byte[8];
        int dropped = 0, trimmed = 0;

        int used = SecondSkinWriter.EncodeBlend(w, 4, bone => names.IndexOf(bone), wb, ib, ref dropped, ref trimmed);

        Assert.Equal(2, used);
        Assert.Equal(0, trimmed);
        Assert.Equal(0, ib[0]);                                                // own_a still leads
        Assert.Equal(1, ib[1]);
    }

    /// <summary>What a trim gave up is counted, so a refit can say so rather than losing it silently.</summary>
    [Fact]
    public void A_refit_reports_what_the_slots_could_not_hold()
    {
        var source = Body(("j_kosi", 1f));
        var target = Body(("j_mune_l", 0.25f), ("j_mune_r", 0.25f), ("j_kosi", 0.25f), ("j_sebo_b", 0.25f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f,
                Weights: [("j_sk_b_a_l", 0.2f), ("j_sk_b_a_r", 0.2f), ("j_kosi", 0.6f)])));
        var pairs = new[] { Pair(source, target) };

        // Off the body-following passes: on the body the cloth takes the body's four bones and nothing overflows.
        BodyRetarget.Rebuild(garment, pairs, swapSkin: false,
                             BodyRetarget.WithTuning(NoHug, () => BodyRetarget.PlanWeights(garment, pairs)),
                             out var report);

        Assert.True(report.Reweighted > 0, "the refit should have reweighted something");
        Assert.True(report.Slotted > 0, "six influences into four slots should be reported");
    }

    [Fact]
    public void Between_body_mods_the_cloth_is_reweighted_even_when_the_rigs_match()
    {
        // YAB's and Rue's plain sizes rig the same bones; each weights them to its own shape.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, Weights: [("j_kosi", 1f)])));
        var pairs = new[] { Pair(Body(("j_kosi", 0.7f), ("j_mune_l", 0.3f)), Body(("j_mune_l", 0.6f), ("j_kosi", 0.4f))) };

        Assert.Null(BodyRetarget.PlanWeights(garment, pairs));                // within one body mod: the author's weights
        // The change rule underneath, for cloth off the body: this sheet lies ON it, where it is now rigged as the body.
        var plan = BodyRetarget.WithTuning(NoHug, () => BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true));
        Assert.NotNull(plan);

        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out var report, acrossBodies: true)!;
        Assert.Equal(2, report.ExtrasDropped);                                // and the old body's piercings go
        // The bodies differ by 0.3 moved from j_kosi to j_mune_l, and the cloth takes that change: 0.7 and 0.3, not
        // the new body's 0.4 and 0.6 outright.
        foreach (int v in VerticesOf(garment, Cloth, 0))
        {
            Assert.Equal(0.3f, Weights(rebuilt)[v].Single(i => i.Bone == "j_mune_l").W, 2);
            Assert.Equal(0.7f, Weights(rebuilt)[v].Single(i => i.Bone == "j_kosi").W, 2);
        }
    }

    /// <summary>Two legs 2 cm apart, each rigged to its own side: the left at z = 0, the right at z = 0.02.</summary>
    private static byte[] Legs((string, float)[] left, (string, float)[] right)
        => SyntheticModel.Build([], new SyntheticModel.Mesh(Skin,
               new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: left),
               new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.02f, Weights: right)));

    [Fact]
    public void A_pant_leg_close_to_the_other_leg_never_takes_its_weights()
    {
        // The inside of the left pant leg, 15 mm off the left thigh and 5 mm off the right: the right thigh is nearer,
        // and it is still the wrong leg.
        var source = Legs([("j_asi_a_l", 1f)], [("j_asi_a_r", 1f)]);
        var target = Legs([("j_asi_a_l", 0.8f), ("j_asi_b_l", 0.2f)], [("j_asi_a_r", 0.8f), ("j_asi_b_r", 0.2f)]);
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.015f,
                                                                  Weights: [("j_asi_a_l", 1f)])));
        var pairs = new[] { Pair(source, target) };

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true, before: garment);
        Assert.NotNull(plan);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;

        foreach (int v in VerticesOf(garment, Cloth, 0))
        {
            var w = Weights(rebuilt)[v];
            Assert.DoesNotContain(w, i => i.Bone.EndsWith("_r", StringComparison.Ordinal));
            // And its own leg's change is taken: the left thigh's 0.2 moved to j_asi_b_l.
            Assert.Equal(0.2f, w.Single(i => i.Bone == "j_asi_b_l").W, 2);
        }
    }

    [Fact]
    public void A_pant_leg_close_to_the_other_leg_never_follows_its_change_of_size()
    {
        // Only the right thigh grows, a centimetre outward. The inside of the left pant leg is nearer the right thigh,
        // and it must stay where the left thigh — which did not move — puts it.
        var sourceModel = Legs([("j_asi_a_l", 1f)], [("j_asi_a_r", 1f)]);
        var targetModel = SyntheticModel.Build([], new SyntheticModel.Mesh(Skin,
            new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: [("j_asi_a_l", 1f)]),
            new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.03f, Weights: [("j_asi_a_r", 1f)])));
        var garmentModel = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.015f,
                                                                  Weights: [("j_asi_a_l", 1f)])));
        var source = ModelPartReader.Read(sourceModel)!;
        var target = ModelPartReader.Read(targetModel)!;
        var garment = ModelPartReader.Read(garmentModel)!;
        Assert.True(IdentityCorrespondence.TryBuild(source, target, "legs", out var built, out string why), why);
        var pairs = new[] { new BodyRetarget.SlotPair("_dwn", built!, target, targetModel, sourceModel) };

        var sided = BodyRetarget.Solve(garment, pairs, pushOut: false,
                                       garmentSkin: ModelSkinReader.Read(garmentModel, null, null));
        var blind = BodyRetarget.Solve(garment, pairs, pushOut: false);

        foreach (int v in VerticesOf(garmentModel, Cloth, 0))
        {
            Assert.Equal(0f, sided.Edit.DeltaAt(v).Z, 4);
            Assert.True(blind.Edit.DeltaAt(v).Z > 0.005f, "without its side the cloth should have followed the right thigh");
        }
    }

    [Fact]
    public void Cloth_rigged_mostly_to_one_leg_never_comes_out_more_to_the_other()
    {
        // The inside seam near the crotch, rigged 60/40: it belongs to neither leg for the lookups, but the other leg's
        // share must never grow past the author's.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 1,
                                                                  Weights: [("j_asi_a_l", 0.6f), ("j_asi_a_r", 0.4f)])));
        var own = ModelSkinReader.Read(garment, null, null)!;
        var bones = new HashSet<string> { "j_asi_a_l", "j_asi_a_r", "j_kosi" };
        var result = new (string Bone, float W)[]?[own.VertexCount];
        for (int v = 0; v < result.Length; v++) result[v] = [("j_asi_a_l", 0.2f), ("j_kosi", 0.1f), ("j_asi_a_r", 0.7f)];

        BodyRetarget.KeepToSide(own, result, bones);

        foreach (var w in result)
        {
            Assert.Equal(0.4f, w!.Single(i => i.Bone == "j_asi_a_r").W, 3);
            Assert.Equal(1f, w!.Sum(i => i.W), 3);
            // The 0.3 taken off the right leg goes to the rest of the body share, as it stood: 2:1 left to the hip.
            Assert.Equal(0.4f, w!.Single(i => i.Bone == "j_asi_a_l").W, 3);
            Assert.Equal(0.2f, w!.Single(i => i.Bone == "j_kosi").W, 3);
        }
    }

    [Theory]
    [InlineData(0.001f)]   // lying on the thigh, where the skin-hug passes would take the skin's weights outright
    [InlineData(0.015f)]   // hanging off it, where the change between the bodies is taken
    public void A_skirt_never_takes_the_legs_weights(float off)
    {
        // A skirt panel over the thigh, rigged to the hip and its own chain alone; both bodies rig the thigh, the new
        // one with Rue's thigh physics too. (Four bones: all a synthetic vertex holds.)
        var source = Body(("j_asi_a_l", 0.7f), ("j_kosi", 0.3f));
        var target = Body(("j_asi_a_l", 0.3f), ("iv_daitai_phys_l", 0.3f), ("j_kosi", 0.2f), ("iv_shiri_l", 0.2f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: off,
                                                                  Weights: [("j_kosi", 0.6f), ("j_sk_f_a_l", 0.4f)])));
        var pairs = new[] { Pair(source, target) };

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true, before: garment);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;

        foreach (int v in VerticesOf(garment, Cloth, 0))
        {
            var w = Weights(rebuilt)[v];
            Assert.DoesNotContain(w, i => BodyRetarget.IsLegBone(i.Bone));
            Assert.DoesNotContain(w, i => i.Bone.Contains("daitai", StringComparison.Ordinal));
            Assert.Equal(1f, w.Sum(i => i.W), 3);
            Assert.Contains(w, i => i.Bone == "j_kosi");
            // The buttocks are the hip a skirt hangs from: it follows them.
            Assert.Contains(w, i => i.Bone == "iv_shiri_l");
        }
    }

    [Theory]
    [InlineData(0.001f)]
    [InlineData(0.015f)]
    public void A_skirt_hem_with_a_trace_of_thigh_is_still_a_skirt(float off)
    {
        // What weighting a skirt in Blender off a body leaves along the hem: 4% thigh. It keeps that trace and gains
        // nothing — not the thigh's full share, not its physics.
        var source = Body(("j_asi_a_l", 0.7f), ("j_kosi", 0.3f));
        var target = Body(("j_asi_a_l", 0.4f), ("iv_daitai_phys_l", 0.3f), ("j_kosi", 0.2f), ("iv_shiri_l", 0.1f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: off,
                Weights: [("j_kosi", 0.56f), ("j_sk_f_a_l", 0.4f), ("j_asi_a_l", 0.04f)])));
        var pairs = new[] { Pair(source, target) };

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true, before: garment);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;

        foreach (int v in VerticesOf(garment, Cloth, 0))
        {
            var w = Weights(rebuilt)[v];
            Assert.True(w.Where(i => BodyRetarget.IsLegBone(i.Bone)).Sum(i => i.W) <= 0.045f,
                        "the hem gained leg weight: " + string.Join(", ", w));
            Assert.DoesNotContain(w, i => i.Bone.Contains("daitai", StringComparison.Ordinal));
            Assert.Equal(1f, w.Sum(i => i.W), 3);
        }
    }

    [Fact]
    public void A_skirt_lying_on_the_thigh_keeps_its_chain_and_takes_no_hip_down_there()
    {
        // The edge of a front panel lying on the thigh, 1 mm off it, rigged mostly to the skirt chain. Cloth on the skin
        // is normally rigged as the skin; a skirt on the leg is not — it keeps swinging with its chain, and the hip's
        // share stays what the author gave it rather than taking the leg's place all the way down the thigh.
        // Both bodies are nearly all thigh there, with a sliver of hip (so the hip is a body bone at all).
        var source = Body(("j_asi_a_l", 0.95f), ("j_kosi", 0.05f));
        var target = Body(("j_asi_a_l", 0.55f), ("iv_daitai_phys_l", 0.4f), ("j_kosi", 0.05f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f,
                                                                  Weights: [("j_sk_f_b_l", 0.8f), ("j_kosi", 0.2f)])));
        var pairs = new[] { Pair(source, target) };

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true, before: garment);
        Assert.NotNull(plan);
        Assert.True(plan.Reweighted > 0, "nothing was reweighted, so the test proves nothing");
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;

        foreach (int v in VerticesOf(garment, Cloth, 0))
        {
            var w = Weights(rebuilt)[v];
            // Within the sliver of hip the skin itself has there: not the near-whole vertex the leg's share became.
            Assert.True(w.Single(i => i.Bone == "j_sk_f_b_l").W >= 0.7f, "the chain was taken off: " + string.Join(", ", w));
            Assert.True(w.Single(i => i.Bone == "j_kosi").W <= 0.3f, "the hip came down the thigh: " + string.Join(", ", w));
            Assert.DoesNotContain(w, i => BodyRetarget.IsLegBone(i.Bone));
        }
    }

    [Fact]
    public void A_skirt_s_leg_reading_goes_to_the_author_s_own_weights()
    {
        var author = new (string, float)[] { ("j_kosi", 0.6f), ("j_sebo_c", 0.4f) };

        // 90% thigh: 90% the author's, and the reading's own 10% of hip kept as it is — not scaled up to all hip.
        var mostly = BodyRetarget.WithoutLegs([("j_asi_a_l", 0.6f), ("iv_daitai_phys_l", 0.3f), ("j_kosi", 0.1f)], author)!;
        Assert.Equal(0.64f, mostly.Single(i => i.Bone == "j_kosi").W, 3);
        Assert.Equal(0.36f, mostly.Single(i => i.Bone == "j_sebo_c").W, 3);
        Assert.DoesNotContain(mostly, i => BodyRetarget.IsLegBone(i.Bone));

        // All thigh: the author's outright, rather than nothing at all.
        var all = BodyRetarget.WithoutLegs([("j_asi_a_l", 1f)], author)!;
        Assert.Equal(0.6f, all.Single(i => i.Bone == "j_kosi").W, 3);
        Assert.Equal(0.4f, all.Single(i => i.Bone == "j_sebo_c").W, 3);

        // No leg in it: untouched.
        (string, float)[] hip = [("j_kosi", 0.7f), ("iv_shiri_l", 0.3f)];
        Assert.Same(hip, BodyRetarget.WithoutLegs(hip, author));
    }

    [Theory]
    [InlineData("j_asi_a_l", true)]
    [InlineData("j_asi_e_r", true)]
    [InlineData("iv_asi_oya_a_l", true)]
    [InlineData("ya_daitai_phys_l", true)]
    [InlineData("iv_daitai_phys_r", true)]
    [InlineData("iv_shiri_l", false)]
    [InlineData("j_kosi", false)]
    [InlineData("j_sk_f_a_l", false)]
    public void Which_bones_are_the_legs(string bone, bool leg) => Assert.Equal(leg, BodyRetarget.IsLegBone(bone));

    [Fact]
    public void Pants_keep_the_legs_weights()
    {
        // Rigged to the thigh by its author: the new body's thigh, physics included, is what it follows.
        var source = Body(("j_asi_a_l", 1f));
        var target = Body(("j_asi_a_l", 0.7f), ("ya_daitai_phys_l", 0.3f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f,
                                                                  Weights: [("j_asi_a_l", 1f)])));
        var pairs = new[] { Pair(source, target) };

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true, before: garment);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;

        foreach (int v in VerticesOf(garment, Cloth, 0))
            Assert.Equal(0.3f, Weights(rebuilt)[v].Single(i => i.Bone == "ya_daitai_phys_l").W, 2);
    }

    [Fact]
    public void Cloth_over_the_crotch_belongs_to_neither_leg()
    {
        Assert.Equal(1, BodyRetarget.SideOf([("j_asi_a_l", 1f)], 0.9f, 0.25f));
        Assert.Equal(-1, BodyRetarget.SideOf([("j_asi_a_r", 0.6f), ("j_kosi", 0.4f)], 0.9f, 0.25f));
        Assert.Equal(0, BodyRetarget.SideOf([("j_asi_a_l", 0.5f), ("j_asi_a_r", 0.4f), ("j_kosi", 0.1f)], 0.9f, 0.25f));
        Assert.Equal(0, BodyRetarget.SideOf([("j_kosi", 0.9f), ("j_asi_a_l", 0.1f)], 0.9f, 0.25f));
        // A skirt's chain is sided too, but only body bones say which leg is under the cloth.
        Assert.Equal(0, BodyRetarget.SideOf([("j_sk_s_a_l", 0.8f), ("j_kosi", 0.2f)], 0.9f, 0.25f, BodyBones));
    }

    /// <summary>The rules for cloth off the body, with the passes for cloth lying on it switched off.</summary>
    private static readonly BodyRetarget.Tuning NoHug = new(NoSkinHug: true);

    [Fact]
    public void Cloth_lying_on_the_body_is_rigged_as_the_body()
    {
        // 1 mm off: the skin's weights outright — the skirt's share gone, the body's taken whole, not the change between
        // the bodies. Rigged the same, skin and cloth bend together in any pose.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f,
                Weights: [("j_sk_b_a_l", 0.3f), ("j_kosi", 0.7f)])));
        var pairs = new[] { Pair(Body(("j_kosi", 1f)), Body(("j_mune_l", 0.6f), ("j_kosi", 0.4f))) };

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;

        foreach (int v in VerticesOf(garment, Cloth, 0))
        {
            var w = Weights(rebuilt)[v];
            Assert.DoesNotContain(w, i => i.Bone == "j_sk_b_a_l");
            Assert.Equal(0.6f, w.Single(i => i.Bone == "j_mune_l").W, 2);
            Assert.Equal(0.4f, w.Single(i => i.Bone == "j_kosi").W, 2);
        }
    }

    [Fact]
    public void A_skirt_hanging_clear_of_the_body_keeps_its_own_bones()
    {
        // 3 cm off — past where the garment's own bones are taken off cloth near the body — the skirt still swings.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.03f,
                Weights: [("j_sk_b_a_l", 0.3f), ("j_kosi", 0.7f)])));
        var pairs = new[] { Pair(Body(("j_kosi", 1f)), Body(("j_mune_l", 0.6f), ("j_kosi", 0.4f))) };

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;

        foreach (int v in VerticesOf(garment, Cloth, 0))
            Assert.Equal(0.3f, Weights(rebuilt)[v].Single(i => i.Bone == "j_sk_b_a_l").W, 2);
    }

    [Fact]
    public void Where_the_two_bodies_agree_the_author_s_weighting_stands()
    {
        // TBSE and TBSE-X weight their shared bones alike; the author weighted a loose shirt by hand, unlike the skin.
        var body = new (string, float)[] { ("j_kosi", 0.7f), ("j_mune_l", 0.3f) };
        var author = new List<(string, float)> { ("j_sebo_c", 0.8f), ("j_kosi", 0.2f) };

        var changed = BodyRetarget.Change(author, body, body, new HashSet<string>(BodyBones) { "j_sebo_c" });

        Assert.Equal(0.8f, changed.Single(i => i.Bone == "j_sebo_c").W, 4);
        Assert.Equal(0.2f, changed.Single(i => i.Bone == "j_kosi").W, 4);
        Assert.DoesNotContain(changed, i => i.Bone == "j_mune_l");
    }

    [Fact]
    public void A_bone_the_new_body_adds_takes_its_share_from_what_the_old_body_had_there()
    {
        // TBSE-X hands part of the chest to its pec bone; the cloth over it follows, the rest of its weighting kept.
        var oldBody = new (string, float)[] { ("j_mune_l", 1f) };
        var newBody = new (string, float)[] { ("j_mune_l", 0.8f), ("iv_kyokin_phys_l", 0.2f) };
        var author = new List<(string, float)> { ("j_mune_l", 0.5f), ("j_sebo_c", 0.5f) };
        var bones = new HashSet<string>(BodyBones) { "iv_kyokin_phys_l", "j_sebo_c" };

        var changed = BodyRetarget.Change(author, oldBody, newBody, bones);

        Assert.Equal(0.3f, changed.Single(i => i.Bone == "j_mune_l").W, 4);
        Assert.Equal(0.5f, changed.Single(i => i.Bone == "j_sebo_c").W, 4);
        Assert.Equal(0.2f, changed.Single(i => i.Bone == "iv_kyokin_phys_l").W, 4);
        Assert.Equal(1f, changed.Sum(i => i.W), 4);
    }

    [Fact]
    public void A_change_that_would_go_below_zero_stops_there_and_the_body_share_is_kept()
    {
        // The old body put the vertex on j_mune_l, which the author never used; the new body moves it to iv_c_mune.
        var oldBody = new (string, float)[] { ("j_mune_l", 1f) };
        var newBody = new (string, float)[] { ("iv_c_mune_l", 1f) };
        var author = new List<(string, float)> { ("j_sebo_c", 0.6f), ("j_sk_f_a_l", 0.4f) };
        var bones = new HashSet<string>(BodyBones) { "iv_c_mune_l", "j_sebo_c" };

        var changed = BodyRetarget.Change(author, oldBody, newBody, bones);
        Assert.DoesNotContain(changed, i => i.Bone == "j_mune_l");            // -0.6 stops at nothing
        var w = BodyRetarget.Combine(author, changed, bones, out _)!;

        Assert.Equal(0.4f, w.Single(i => i.Bone == "j_sk_f_a_l").W, 4);       // the skirt, exactly
        Assert.Equal(0.6f, w.Where(i => i.Bone != "j_sk_f_a_l").Sum(i => i.W), 4);   // the body keeps its 0.6
        Assert.Equal(1f, w.Sum(i => i.W), 4);
    }

    /// <summary>[EDGE-within-body-weights-2] Within one body mod, a slot whose rig stays keeps the author's weights.</summary>
    [Fact]
    public void A_slot_that_keeps_its_rig_keeps_the_author_s_weights_when_another_slot_changes_rig()
    {
        // Rue+ Yiggle Medium to Large with the hands going Short Nails to Yiggle Stabbies: only the hands' rig changes,
        // and the chest's cloth used to be reweighted whole for it — ragged under the bust.
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth,
                new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f, Weights: [("j_kosi", 1f)]),
                new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetX: 20f, OffsetZ: 0.001f, Weights: [("j_te_l", 1f)])));
        var chest = Pair(Body(("j_kosi", 0.7f), ("j_mune_l", 0.3f)), Body(("j_mune_l", 0.6f), ("j_kosi", 0.4f)));
        var hands = Pair(BodyAt(20f, ("j_te_l", 1f)), BodyAt(20f, ("j_te_l", 0.5f), ("iv_hito_c_l", 0.5f)));
        var pairs = new[] { chest, hands };

        var plan = BodyRetarget.PlanWeights(garment, pairs);
        Assert.NotNull(plan);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;

        foreach (int v in VerticesOf(garment, Cloth, 0))
            Assert.Equal([("j_kosi", 1f)], Weights(rebuilt)[v]);
        foreach (int v in VerticesOf(garment, Cloth, 1))
            Assert.Contains(Weights(rebuilt)[v], i => i.Bone == "iv_hito_c_l");
    }

    /// <summary>A body like <see cref="Body"/>, <paramref name="x"/> across — another slot, out of the first's reach.</summary>
    private static byte[] BodyAt(float x, params (string, float)[] weights)
        => SyntheticModel.Build([], new SyntheticModel.Mesh(Skin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3,
                                                                                         OffsetX: x, Weights: weights)));

    /// <summary>[EDGE-within-body-weights-1] Within one body mod, two sizes rigged alike: nothing to rewrite.</summary>
    [Fact]
    public void Two_bodies_rigged_alike_keep_the_author_s_weights()
    {
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: [("j_kosi", 1f)])));
        var pairs = new[] { Pair(Body(("j_kosi", 1f)), Body(("j_kosi", 1f))) };

        Assert.Null(BodyRetarget.PlanWeights(garment, pairs));
    }

    [Fact]
    public void The_old_body_s_piercings_are_left_out_of_a_refit_across_bodies()
    {
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, Weights: [("j_kosi", 1f)])));
        var pairs = new[] { Pair(Body(("j_kosi", 1f)), Body(("j_mune_l", 1f))) };

        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false,
                                           BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true), out var report,
                                           acrossBodies: true)!;

        Assert.Equal(2, report.ExtrasDropped);
        Assert.DoesNotContain(ModelPartReader.Read(rebuilt)!.Parts, p => p.Material == Piercings);
        Assert.True(BodyRetarget.IsBodyExtraMaterial("/mt_c0201b0001_bibopube.mtrl"));
        Assert.True(BodyRetarget.IsBodyExtraMaterial("/mt_c0201b0001_neolithe_piercings.mtrl"));
        Assert.False(BodyRetarget.IsBodyExtraMaterial(Skin));
        Assert.False(BodyRetarget.IsBodyExtraMaterial("/mt_c0201e0000_top_neolithe_undies.mtrl"));
    }

    /// <summary>
    /// Rue+'s Gen A legs to its Gen B: one mesh, but B rigs genital bones A does not, so the cloth is reweighted. The
    /// pubic hair was carried along with the skin it sits on and still fits; with the author's skin kept nothing would
    /// replace it, and the refit came out bald.
    /// </summary>
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public void Within_one_body_mod_a_rig_change_keeps_the_pubic_hair_and_piercings(bool acrossBodies, bool replaceSkin)
    {
        const string Pubes = "/mt_c0201b0001_bibopube.mtrl";
        byte[] bytes = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Pubes, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, Weights: [("j_kosi", 1f)])));
        var pairs = new[] { Pair(Body(("j_kosi", 1f)), Body(("j_kosi", 0.8f), ("iv_omanko", 0.2f))) };

        // Through Plan, as the Studio, the size set and the automatic refit call it: the flag has to reach the rebuild.
        var plan = BodyRetarget.Plan(ModelPartReader.Read(bytes)!, bytes, pairs, "_top", pushOut: false,
                                     replaceSkin: replaceSkin, acrossBodies: acrossBodies);

        var materials = ModelPartReader.Read(plan.Model)!.Parts.Select(p => p.Material).ToHashSet();
        Assert.NotNull(plan.Report.Swap);                                      // the rig changed, so it was rebuilt
        Assert.Equal(acrossBodies ? 4 : 0, plan.Report.Swap!.Value.ExtrasDropped);
        Assert.Equal(!acrossBodies, materials.Contains(Pubes));
        Assert.Equal(!acrossBodies, materials.Contains(Piercings));
        Assert.Contains(Cloth, materials);

        // Their names go with them: the game loads every material the model names, and one the new body has no file
        // for hides the whole model. The meshes kept still draw what they drew.
        var table = SecondSkinWriter.MaterialNames(plan.Model);
        Assert.Equal(!acrossBodies, table.Contains(Pubes));
        Assert.Equal(!acrossBodies, table.Contains(Piercings));
        Assert.Equal(table.Count, table.Distinct().Count());
        Assert.Equal(materials.Order(), SecondSkinWriter.DrawnMaterialNames(plan.Model).Order());
    }

    /// <summary>
    /// The old body's pubic hair and piercings dropped across body mods, their materials declared before and between the
    /// cloth's: the names leave the table and each cloth mesh still draws its own material, moved down to its new index.
    /// </summary>
    [Fact]
    public void Dropped_extras_take_their_material_names_and_the_cloth_keeps_its_own()
    {
        const string Pubes = "/mt_c0201b0001_bibopube.mtrl";
        const string Lace = "/mt_c0201e6255_top_b.mtrl";
        byte[] bytes = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Pubes, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Lace, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, Weights: [("j_kosi", 1f)])));
        Assert.Equal([Pubes, Cloth, Piercings, Lace], SecondSkinWriter.MaterialNames(bytes));
        var pairs = new[] { Pair(Body(("j_kosi", 1f)), Body(("j_kosi", 0.8f), ("iv_omanko", 0.2f))) };

        var plan = BodyRetarget.Plan(ModelPartReader.Read(bytes)!, bytes, pairs, "_top", pushOut: false,
                                     replaceSkin: false, acrossBodies: true);

        Assert.Equal([Cloth, Lace], SecondSkinWriter.MaterialNames(plan.Model));
        // Each kept mesh by its triangles: the 3-triangle cloth still draws Cloth, the 4-triangle lace Lace.
        var meshes = ModelPartReader.Read(plan.Model)!.Parts.Where(p => p.Island < 0).GroupBy(p => p.Mesh)
                                    .Select(g => (g.First().Material, Tris: g.Sum(p => p.Triangles.Length / 3)))
                                    .OrderBy(m => m.Tris).ToList();
        Assert.Equal([(Cloth, 3), (Lace, 4)], meshes);
    }

    /// <summary>
    /// An extras material a kept mesh still draws stays named: only the mesh left out goes, and the one kept still draws
    /// it. Every mesh of it left out, the name goes too.
    /// </summary>
    [Fact]
    public void An_extras_material_a_kept_mesh_still_draws_stays_named()
    {
        byte[] host = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, TrianglesPerIsland: 4, Weights: [("j_kosi", 1f)])));
        Assert.Equal([Piercings, Cloth], SecondSkinWriter.MaterialNames(host));

        var one = SecondSkinWriter.Build([], [], host, out _, dropHostMesh: m => m == 0,
                                         dropHostMaterial: BodyRetarget.IsBodyExtraMaterial);
        Assert.Equal([Piercings, Cloth], SecondSkinWriter.MaterialNames(one));
        Assert.Equal([(Cloth, 3), (Piercings, 4)], Meshes(one));

        var both = SecondSkinWriter.Build([], [], host, out _, dropHostMesh: m => m != 1,
                                          dropHostMaterial: BodyRetarget.IsBodyExtraMaterial);
        Assert.Equal([Cloth], SecondSkinWriter.MaterialNames(both));
        Assert.Equal([(Cloth, 3)], Meshes(both));

        static List<(string, int)> Meshes(byte[] model)
            => ModelPartReader.Read(model)!.Parts.Where(p => p.Island < 0).GroupBy(p => p.Mesh)
                              .Select(g => (g.First().Material, g.Sum(p => p.Triangles.Length / 3)))
                              .OrderBy(m => m.Item2).ToList();
    }

    /// <summary>
    /// A top with its own chest skin and its own two-triangle ring, refitted onto a body that rigs genital bones the old
    /// one does not (so the cloth is reweighted) and draws a one-triangle ring of its own.
    /// </summary>
    private static (byte[] Garment, BodyRetarget.SlotPair Pair) PiercedTop()
    {
        byte[] garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Skin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.003f,
                                                                  Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, TrianglesPerIsland: 2, OffsetZ: 0.001f,
                                                                      Weights: [("j_kosi", 1f)])));
        byte[] target = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Skin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3,
                                                                 Weights: [("j_kosi", 0.8f), ("iv_omanko", 0.2f)])),
            new SyntheticModel.Mesh(Piercings, new SyntheticModel.Sub(0, OffsetZ: 0.001f, Weights: [("j_kosi", 1f)])));
        return (garment, Pair(Body(("j_kosi", 1f)), target));
    }

    private static int PiercingTriangles(byte[] mdl)
        => ModelPartReader.Read(mdl)!.Parts.Where(p => p.Island < 0 && p.Material == Piercings)
                                           .Sum(p => p.Triangles.Length / 3);

    [Fact]
    [Trait("Plan", "AC-refit-piercings-option-6")]
    public void With_piercings_off_the_old_body_s_go_across_bodies_and_stay_within_one()
    {
        // [AC-refit-piercings-option-6] First, that the case is reached: asked for, within one body mod, the garment's
        // own ring gives way to the body's (two triangles become one). Then, not asked for: across body mods the old
        // ring goes with the old body's extras and none comes in; within one, the author's stays as it was.
        var (garment, pair) = PiercedTop();
        var parts = ModelPartReader.Read(garment)!;
        BodyRetarget.Planned Refit(bool across, bool carry)
            => BodyRetarget.Plan(parts, garment, [pair], "_top", pushOut: false, replaceSkin: true, acrossBodies: across,
                                 carryPiercings: carry);

        var swapped = Refit(across: false, carry: true);
        Assert.Equal(1, swapped.Report.Swap!.Value.Adorned);
        Assert.Equal(1, PiercingTriangles(swapped.Model));

        var across = Refit(across: true, carry: false);
        Assert.Equal(0, across.Report.Swap!.Value.Adorned);
        Assert.Equal(0, PiercingTriangles(across.Model));
        Assert.True(across.Report.Swap!.Value.ExtrasDropped >= 2);

        var within = Refit(across: false, carry: false);
        Assert.Equal(0, within.Report.Swap!.Value.Adorned);
        Assert.Equal(2, PiercingTriangles(within.Model));
    }

    [Fact]
    [Trait("Plan", "EDGE-refit-piercings-option-4")]
    public void Old_piercings_stay_when_no_weights_were_planned()
    {
        // [EDGE-refit-piercings-option-4] Across body mods with no weights (a body unreadable): the old ring stays, as
        // before build 1147, and none comes in.
        var (garment, pair) = PiercedTop();
        var rebuilt = BodyRetarget.Rebuild(garment, [pair], swapSkin: true, weights: null, out var report,
                                           acrossBodies: true);
        Assert.NotNull(rebuilt);
        Assert.Equal(0, report.Adorned);
        Assert.Equal(2, PiercingTriangles(rebuilt!));
    }

    // ── within one body mod: only the change between the two bodies ─────────────────────────────────────

    /// <summary>
    /// One body mod's two sizes, rigged apart (Rue+'s Gen A legs and Gen B): the same skin with a far piece that only
    /// the target rigs to a bone of its own. Same vertex layout in both, so the old body's weights can be read.
    /// </summary>
    private static (byte[] Source, byte[] Target) RigChange((string, float)[] source, (string, float)[] target)
        => (SyntheticModel.Build([], new SyntheticModel.Mesh(Skin,
                new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: source),
                new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetX: 20f, Weights: [("j_kosi", 1f)]))),
            SyntheticModel.Build([], new SyntheticModel.Mesh(Skin,
                new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: target),
                new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetX: 20f, Weights: [("iv_omanko", 1f)]))));

    /// <summary>
    /// A garment carrying its own skin, rigged as the old body (0.5 / 0.5), and cloth 1 mm off it rigged a little apart
    /// (0.55 / 0.45: within the copy rule's tolerance). The new body moves 0.1 from j_kosi to j_sebo_a under it, so the
    /// three answers differ: the author's 0.55 / 0.45, the change 0.45 / 0.55, the new skin outright 0.4 / 0.6.
    /// </summary>
    private static (byte[] Garment, BodyRetarget.SlotPair[] Pairs) ClothOnItsSkin()
    {
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Skin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3,
                Weights: [("j_kosi", 0.5f), ("j_sebo_a", 0.5f)])),
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f,
                Weights: [("j_kosi", 0.55f), ("j_sebo_a", 0.45f)])));
        var (source, target) = RigChange([("j_kosi", 0.5f), ("j_sebo_a", 0.5f)], [("j_kosi", 0.4f), ("j_sebo_a", 0.6f)]);
        return (garment, [Pair(source, target)]);
    }

    private static void AssertCloth(byte[] model, float kosi, float sebo)
    {
        foreach (int v in VerticesOf(model, Cloth, 0))
        {
            var w = Weights(model)[v];
            Assert.Equal(kosi, w.Single(i => i.Bone == "j_kosi").W, 2);
            Assert.Equal(sebo, w.Single(i => i.Bone == "j_sebo_a").W, 2);
        }
    }

    /// <summary>
    /// [AC-within-body-weights-3] [EDGE-within-body-weights-8] Cloth on its skin, within one body mod: the author's
    /// weights plus the change between the two bodies — not the new skin's outright, which is what took the Starlit
    /// Skirt's thigh weight away on Rue+'s Gen A to Gen B. Through Plan, as every caller refits.
    /// </summary>
    [Fact]
    public void Within_one_body_mod_cloth_on_the_skin_keeps_the_author_s_weights_and_the_change()
    {
        var (garment, pairs) = ClothOnItsSkin();

        var plan = BodyRetarget.Plan(ModelPartReader.Read(garment)!, garment, pairs, "_top", pushOut: false,
                                     acrossBodies: false);

        Assert.NotNull(plan.Report.Swap);                                      // the rig changed, so it was reweighted
        AssertCloth(plan.Model, 0.45f, 0.55f);                                 // the change: neither 0.55 nor 0.4
    }

    /// <summary>[AC-within-body-weights-5] The same cloth across body mods is still rigged as the new skin.</summary>
    [Fact]
    public void Across_body_mods_cloth_on_the_skin_is_still_rigged_as_the_new_skin()
    {
        var (garment, pairs) = ClothOnItsSkin();

        var plan = BodyRetarget.Plan(ModelPartReader.Read(garment)!, garment, pairs, "_top", pushOut: false,
                                     acrossBodies: true);

        AssertCloth(plan.Model, 0.4f, 0.6f);
    }

    /// <summary>[AC-within-body-weights-5] Across body mods the copy rule alone, skin hug off, still copies the skin.</summary>
    [Fact]
    public void Across_body_mods_the_copy_rule_rigs_cloth_on_its_skin_as_the_new_skin()
    {
        var (garment, pairs) = ClothOnItsSkin();

        var plan = BodyRetarget.WithTuning(NoHug, () => BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true,
                                                                                 before: garment));
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _, acrossBodies: true)!;

        AssertCloth(rebuilt, 0.4f, 0.6f);
    }

    /// <summary>
    /// [EDGE-within-body-weights-3] Without the garment as authored there is no own skin to read: the change is taken
    /// against the old body mod, and it is the same change.
    /// </summary>
    [Fact]
    public void Within_one_body_mod_without_the_authored_garment_the_change_is_against_the_old_body()
    {
        var (garment, pairs) = ClothOnItsSkin();

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: false, before: null);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;

        AssertCloth(rebuilt, 0.45f, 0.55f);
    }

    /// <summary>
    /// [EDGE-within-body-weights-4] Within one body mod the copy and hug knobs change nothing; the diagnostic flag brings
    /// the old behaviour back, for comparing against it.
    /// </summary>
    [Fact]
    public void Skin_hug_tuning_has_no_effect_within_one_body_mod()
    {
        var (garment, pairs) = ClothOnItsSkin();
        byte[] Refit(BodyRetarget.Tuning t)
            => BodyRetarget.Rebuild(garment, pairs, swapSkin: false,
                   BodyRetarget.WithTuning(t, () => BodyRetarget.PlanWeights(garment, pairs, before: garment)), out _)!;

        var plain = Refit(new BodyRetarget.Tuning());
        var off = Refit(new BodyRetarget.Tuning(CopyTolerance: -1f, NoSkinHug: true));
        var old = Refit(new BodyRetarget.Tuning(CrossBodyPassesWithinBody: true));

        Assert.Equal(Weights(plain), Weights(off));
        AssertCloth(old, 0.4f, 0.6f);
    }

    /// <summary>A skirt 5.5 mm off its skin, partly on a chain of its own.</summary>
    private static (byte[] Garment, BodyRetarget.SlotPair[] Pairs) ChainNearTheBody()
    {
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Skin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, Weights: [("j_kosi", 1f)])),
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.0055f,
                Weights: [("j_sk_s_a_l", 0.3f), ("j_kosi", 0.7f)])));
        var (source, target) = RigChange([("j_kosi", 1f)], [("j_kosi", 1f)]);
        return (garment, [Pair(source, target)]);
    }

    private static float Chain(byte[] model)
        => VerticesOf(model, Cloth, 0).Max(v => Weights(model)[v].Where(i => i.Bone == "j_sk_s_a_l").Sum(i => i.W));

    /// <summary>[AC-within-body-weights-4] Within one body mod, cloth near the body keeps its own chain as authored.</summary>
    [Fact]
    public void Within_one_body_mod_cloth_near_the_body_keeps_the_garment_s_own_bones()
    {
        var (garment, pairs) = ChainNearTheBody();

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: false, before: garment);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;

        Assert.Equal(0.3f, Chain(rebuilt), 2);
    }

    /// <summary>[AC-within-body-weights-5] Across body mods the chain still comes off cloth near the body.</summary>
    [Fact]
    public void Across_body_mods_cloth_near_the_body_still_drops_the_garment_s_own_bones()
    {
        var (garment, pairs) = ChainNearTheBody();

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true, before: garment);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _, acrossBodies: true)!;

        Assert.True(Chain(rebuilt) < 0.29f, $"the chain kept {Chain(rebuilt):0.000}");
    }

    [Fact]
    public void Two_bodies_a_whole_tile_apart_in_uv_still_pair()
    {
        // Bibo+ stores its legs at v -0.67..-0.02 where Neolithe stores them at 0.02..0.98. A sheet repeats, so those
        // are the same texels; compared as stored they had nothing in common and the pair was refused.
        var body = ModelPartReader.Read(SyntheticModel.Build([],
            new SyntheticModel.Mesh(Skin, new SyntheticModel.Sub(0, TrianglesPerIsland: 4))))!;
        int vc = body.Positions.Length / 3;
        var uv = new float[vc * 2];
        for (int v = 0; v < vc; v++) { uv[v * 2] = 0.1f + 0.2f * (v % 3); uv[v * 2 + 1] = 0.2f + 0.15f * (v % 4); }
        var shifted = uv.Select((x, i) => i % 2 == 1 ? x - 1f : x).ToArray();

        Assert.True(BodyCorrespondence.TryBuild(body, shifted, body, uv, "legs", out var c, out string why), why);
        Assert.Contains("100.0%", c!.Describe());
    }

    [Fact]
    public void A_held_part_keeps_the_bones_the_author_gave_it()
    {
        // Unticking a part holds it where the author put it. It has to hold the bones too: a rigid heel held in place
        // but reweighted stands still in the bind pose and flies apart in a posed one.
        var source = Body(("j_asi_d_l", 1f));
        var target = Body(("j_asi_e_l", 1f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f,
                                                                  Weights: [("j_asi_d_l", 1f)])));
        var pairs = new[] { Pair(source, target) };
        var mine = VerticesOf(garment, Cloth, 0);

        Assert.NotNull(BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true));
        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true, held: mine.ToHashSet());

        Assert.Equal(0, plan?.Reweighted ?? 0);
        Assert.All(mine, v => Assert.Null(plan?.For(0)?[v]));
    }

    [Fact]
    public void Cloth_out_of_reach_of_the_body_keeps_the_weights_it_had()
    {
        // A thigh-high stocking refitted on the FEET slot: the body is the foot, and the cloth up the leg is nowhere
        // near it. Weighting that cloth to the foot's bones is what tore a stocking apart.
        var source = Body(("j_asi_d_l", 1f));
        var target = Body(("j_asi_e_l", 1f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.001f,
                                                                  Weights: [("j_asi_d_l", 1f)])),
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.5f,
                                                                  Weights: [("j_asi_d_l", 1f)])));
        var pairs = new[] { Pair(source, target) };

        var plan = BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true)!;
        var near = VerticesOf(garment, Cloth, 0);
        var far = VerticesOf(garment, Cloth, 1);
        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false, plan, out _)!;
        var w = Weights(rebuilt);

        // On the body: it follows the new body's bone. Half a metre off it: untouched.
        Assert.All(near, v => Assert.Equal("j_asi_e_l", w[v].OrderByDescending(i => i.W).First().Bone));
        Assert.All(far, v => Assert.Equal([("j_asi_d_l", 1f)], w[v]));
    }

    [Fact]
    public void Cloth_between_full_and_out_of_reach_takes_part_of_the_change()
    {
        // 3 cm off both bodies: half way from WeightFull to WeightReach, so half the change. A hard line at the reach
        // is what two layers of cloth fell either side of.
        var source = Body(("j_asi_d_l", 1f));
        var target = Body(("j_asi_e_l", 1f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.03f,
                                                                  Weights: [("j_asi_d_l", 1f)])));
        var pairs = new[] { Pair(source, target) };

        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false,
                                           BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true), out _)!;

        Assert.All(VerticesOf(garment, Cloth, 0), v =>
        {
            Assert.Equal(0.5f, Weights(rebuilt)[v].Single(i => i.Bone == "j_asi_d_l").W, 2);
            Assert.Equal(0.5f, Weights(rebuilt)[v].Single(i => i.Bone == "j_asi_e_l").W, 2);
        });
        Assert.Equal(1f, BodyRetarget.Fade(BodyRetarget.WeightFull), 5);
        Assert.Equal(0f, BodyRetarget.Fade(BodyRetarget.WeightReach), 5);
    }

    [Fact]
    public void Two_layers_the_author_weighted_alike_stay_alike()
    {
        // A printed panel over a shirt, 2 mm apart, weighted identically by the author — the game's Oversized Plain
        // Neotunic. Each looks the bodies up for itself; here one sits just inside the reach and one just outside, so
        // on their own one takes a little of the change and the other none. They must still move as one.
        var source = Body(("j_asi_d_l", 1f));
        var target = Body(("j_asi_e_l", 1f));
        var garment = SyntheticModel.Build([],
            new SyntheticModel.Mesh(Cloth, new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.035f,
                                                                  Weights: [("j_asi_d_l", 1f)])),
            new SyntheticModel.Mesh("/mt_c0201e6255_top_b.mtrl",
                                    new SyntheticModel.Sub(0, TrianglesPerIsland: 3, OffsetZ: 0.0385f,
                                                           Weights: [("j_asi_d_l", 1f)])));
        var pairs = new[] { Pair(source, target) };

        var rebuilt = BodyRetarget.Rebuild(garment, pairs, swapSkin: false,
                                           BodyRetarget.PlanWeights(garment, pairs, acrossBodies: true), out _)!;
        var w = Weights(rebuilt);
        var shirt = VerticesOf(garment, Cloth, 0);
        var panel = VerticesOf(garment, "/mt_c0201e6255_top_b.mtrl", 0);

        float E(int v) => w[v].SingleOrDefault(i => i.Bone == "j_asi_e_l").W;
        Assert.All(shirt, v => Assert.True(E(v) > 0.05f, $"the shirt took the change ({E(v):F3})"));
        for (int k = 0; k < shirt.Length; k++)
            Assert.Equal(E(shirt[k]), E(panel[k]), 2);
    }

    [Fact]
    public void Bodies_in_different_texture_layouts_with_no_map_between_them_are_refused()
    {
        var bibo = ModelPartReader.Read(SyntheticModel.Build([],
            new SyntheticModel.Mesh(Skin, new SyntheticModel.Sub(0, TrianglesPerIsland: 3))))!;
        var gen3 = ModelPartReader.Read(SyntheticModel.Build([],
            new SyntheticModel.Mesh("/mt_c0201b0001_eve.mtrl", new SyntheticModel.Sub(0, TrianglesPerIsland: 3,
                                                                                    OffsetX: 0.5f))))!;
        var uv = new float[gen3.Positions.Length / 3 * 2];

        Assert.Equal("bibo", BodyCorrespondence.LayoutOf(bibo));
        Assert.Equal("gen3", BodyCorrespondence.LayoutOf(gen3));
        // No maps on disk for this service: bibo to gen3 has nothing to go through.
        var uvRemap = new UVRemapService(NSubstitute.Substitute.For<Dalamud.Plugin.Services.IPluginLog>(), ".");
        Assert.False(BodyCorrespondence.TryBuild(gen3, uv, bibo, uv, "chest", out _, out string refusal, uvRemap));
        Assert.Contains("different texture layouts", refusal);
    }
}
