using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Proteus.Services;
using Xunit;
using static Proteus.Services.ShaderUpgradePlan;
using Kit = Proteus.Tests.ShaderUpgradeTestKit;

namespace Proteus.Tests;

/// <summary>
/// The gear shader upgrade's writes into a worn mod, and their undo (<see cref="ShaderUpgradeWriter"/>). These edit
/// somebody else's mod, so what matters most is what they leave alone: the author's files, every other redirect, the
/// groups, and an author's later update.
/// </summary>
public class ShaderUpgradeWriterTests
{
    private const string Red = "red/top.mtrl";
    private static string Spec(string mod) => Path.Combine(mod, "tex", "top_s.tex");
    private static IReadOnlyList<Worn> WornRed(string mod) => [Kit.Worn(Kit.TopPath, mod, Red)];

    private static List<PenumbraModMeta.Redirect> Redirects(string mod) => PenumbraModMeta.ReadAllRedirects(mod);

    private static List<(string Group, string Option)> Groups(string mod)
        => HairPortPlan.ReadOwners(mod)!.Select(o => (o.Group, o.Option)).ToList();

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-2")]
    public void Index_mask_material_is_upgraded_in_place_after_a_backup()
    {
        using var kit = new Kit();
        var mod = kit.Dress("Old Top", Kit.FormA());
        var outcome = kit.Upgrade(mod, WornRed(mod));
        Assert.Equal([Red], outcome.Written);
        Assert.Equal("character.shpk", CharacterShaderUpgrade.ShaderOf(Kit.Get(mod, Red)));
        Assert.Equal(Kit.FormA(), Kit.Get(mod, "Proteus/shaderupgrade-backup/red/top.mtrl"));
        Assert.True(ShaderUpgradeWriter.IsUpgraded(mod, Red));
        var e = Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
        Assert.False(e.Pending);
        Assert.Equal("index-mask", e.Form);
        // The other option's copy of the file is not drawn, so it is not touched.
        Assert.Equal(Kit.FormA(), Kit.Get(mod, "blue/top.mtrl"));
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-4")]
    public void Only_materials_masks_added_redirects_and_proteus_files_change()
    {
        using var kit = new Kit();
        var mod = kit.Dress("Bandana", Kit.FormB(), withSpec: true);
        Kit.Put(mod, "readme.txt", "hello"u8.ToArray());
        var before = Kit.Hashes(mod);
        var redirectsBefore = Redirects(mod);
        var groupsBefore = Groups(mod);

        var outcome = kit.Upgrade(mod, WornRed(mod), _ => Spec(mod));
        Assert.True(outcome.ChangedAny);

        var after = Kit.Hashes(mod);
        foreach (var (rel, hash) in before)
            if (rel != Red) Assert.Equal(hash, after[rel]);
        var added = after.Keys.Except(before.Keys).ToList();
        Assert.All(added, rel => Assert.True(rel.StartsWith("Shader Upgrade/") || rel.StartsWith("Proteus/"), rel));
        Assert.Contains(added, r => r.StartsWith("Shader Upgrade/"));
        Assert.Equal(groupsBefore, Groups(mod));
        var newRedirects = Redirects(mod).Except(redirectsBefore).ToList();
        Assert.All(newRedirects, r => Assert.StartsWith("Shader Upgrade", r.File.Replace('\\', '/')));
        Assert.Equal(redirectsBefore.Count, Redirects(mod).Count - newRedirects.Count);
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-4")]
    [Trait("Plan", "EDGE-dt-shader-upgrade-55")]
    public void A_v3_folder_is_never_written()
    {
        using var kit = new Kit();
        var mod = kit.LegacyMod("Old", new Dictionary<string, string> { [Kit.TopPath] = "top.mtrl" });
        Kit.Put(mod, "top.mtrl", Kit.FormA());
        var before = Kit.Hashes(mod);
        var plan = kit.Plan([Kit.Worn(Kit.TopPath, mod, "top.mtrl")]);
        Assert.Empty(plan.PerMod);
        Assert.Equal(LeftReason.LegacyMod, Assert.Single(plan.Left).Reason);
        // And the writer refuses it under its lock even when handed a write.
        var write = new MaterialWrite("top.mtrl", [Kit.TopPath], LegacyForm.IndexMask, Sha8(Kit.FormA()),
                                      WindNeutral(CharacterShaderUpgrade.Upgrade(Kit.FormA())!)!, null);
        var outcome = ShaderUpgradeWriter.Apply(mod, [write], () => true, Kit.WriteTex, TexEncoding.Uncompressed);
        Assert.Equal(LeftReason.LegacyMod, Assert.Single(outcome.Left).Reason);
        Assert.Equal(before, Kit.Hashes(mod));
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-5")]
    [Trait("Plan", "EDGE-dt-shader-upgrade-68")]
    public void Writes_stop_when_mayWrite_turns_false()
    {
        using var kit = new Kit();
        var mod = kit.Mod("Two", new Dictionary<string, string> { [Kit.TopPath] = "a.mtrl", [Kit.DwnPath] = "b.mtrl" });
        Kit.Put(mod, "a.mtrl", Kit.FormA());
        Kit.Put(mod, "b.mtrl", Kit.FormA());
        // The setting goes off as soon as one file has been written.
        bool AnyWritten() => new[] { "a.mtrl", "b.mtrl" }.Any(r => CharacterShaderUpgrade.ShaderOf(Kit.Get(mod, r)) == "character.shpk");
        var outcome = kit.Upgrade(mod, [Kit.Worn(Kit.TopPath, mod, "a.mtrl"), Kit.Worn(Kit.DwnPath, mod, "b.mtrl")],
                                  mayWrite: () => !AnyWritten());
        Assert.Single(outcome.Written);
        Assert.Equal(1, new[] { "a.mtrl", "b.mtrl" }.Count(r => CharacterShaderUpgrade.ShaderOf(Kit.Get(mod, r)) == "character.shpk"));
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-11")]
    public void Diffuse_material_gets_a_mask_file_and_redirects_beside_its_own()
    {
        using var kit = new Kit();
        var mod = kit.Dress("Bandana", Kit.FormB(), withSpec: true);
        Assert.True(kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)).ChangedAny);
        var mtrl = Kit.Get(mod, Red);
        var maskGame = MaskSlotPath(mtrl)!;
        Assert.StartsWith("chara/equipment/e6024/texture/dt_", maskGame);
        var red = HairPortPlan.ReadOwners(mod)!.Single(o => o.Option == "Red");
        var maskRel = HairPortPlan.FileFor(red, maskGame)!.Replace('\\', '/');
        Assert.StartsWith("Shader Upgrade/", maskRel);
        Assert.True(TextureLoader.IsCompleteTex(Path.Combine(mod, maskRel)));
        // Blue ships the same file name but its own copy: it gets the redirect only if it ships THIS file.
        Assert.Null(HairPortPlan.FileFor(HairPortPlan.ReadOwners(mod)!.Single(o => o.Option == "Blue"), maskGame));
        Assert.Equal(Kit.Fixture("legacy_spec_s.tex"), Kit.Get(mod, "tex/top_s.tex"));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-62")]
    public void Mask_redirect_lands_in_every_owner_of_the_material_and_undo_takes_each_out()
    {
        using var kit = new Kit();
        var mod = kit.Mod("Shared", null, ("Colour", "Single", [
            ("Red", new Dictionary<string, string> { [Kit.TopPath] = "top.mtrl", [Kit.SpecPath] = "s.tex" }),
            ("Blue", new Dictionary<string, string> { [Kit.TopPath] = "top.mtrl", [Kit.SpecPath] = "s.tex" })]));
        Kit.Put(mod, "top.mtrl", Kit.FormB());
        Kit.Put(mod, "s.tex", Kit.Fixture("legacy_spec_s.tex"));
        Assert.True(kit.Upgrade(mod, [Kit.Worn(Kit.TopPath, mod, "top.mtrl")], _ => Path.Combine(mod, "s.tex")).ChangedAny);
        var maskGame = MaskSlotPath(Kit.Get(mod, "top.mtrl"))!;
        Assert.All(HairPortPlan.ReadOwners(mod)!.Where(o => !o.IsDefault), o => Assert.NotNull(HairPortPlan.FileFor(o, maskGame)));
        Assert.Equal(ShaderUpgradeWriter.Undone.Restored, ShaderUpgradeWriter.RevertOrForget(mod, "top.mtrl", false, out _));
        Assert.All(HairPortPlan.ReadOwners(mod)!, o => Assert.Null(HairPortPlan.FileFor(o, maskGame)));
        Assert.False(Directory.Exists(Path.Combine(mod, "Shader Upgrade")));
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-12")]
    public void Undo_worn_restores_backups_removes_added_redirects_and_unnamed_masks_and_declines()
    {
        using var kit = new Kit();
        var mod = kit.Dress("Bandana", Kit.FormB(), withSpec: true);
        var before = Kit.Hashes(mod);
        var redirectsBefore = Redirects(mod);
        Assert.True(kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)).ChangedAny);
        Assert.Equal(ShaderUpgradeWriter.Undone.Restored, ShaderUpgradeWriter.RevertOrForget(mod, Red, decline: true, out _));
        Assert.Equal(Kit.FormB(), Kit.Get(mod, Red));
        Assert.Equal(redirectsBefore, Redirects(mod));
        Assert.False(Directory.Exists(Path.Combine(mod, "Shader Upgrade")));
        Assert.False(Directory.Exists(Path.Combine(mod, "Proteus", "shaderupgrade-backup")));
        Assert.True(ShaderUpgradeWriter.IsDeclined(mod, Red));
        var after = Kit.Hashes(mod);
        Assert.Equal(before, after.Where(kv => !kv.Key.StartsWith("Proteus/")).ToDictionary());
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-66")]
    public void Undo_without_decline_leaves_no_declined_entry()
    {
        using var kit = new Kit();
        var mod = kit.Dress("D", Kit.FormA());
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
        ShaderUpgradeWriter.RevertOrForget(mod, Red, decline: false, out _);
        Assert.False(ShaderUpgradeWriter.IsDeclined(mod, Red));
        Assert.False(File.Exists(Path.Combine(mod, "Proteus", "shaderupgrade.json")));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-66")]
    public void ClearDeclines_touches_only_named_files()
    {
        using var kit = new Kit();
        var mod = kit.Mod("Two", new Dictionary<string, string> { [Kit.TopPath] = "a.mtrl", [Kit.DwnPath] = "b.mtrl" });
        Kit.Put(mod, "a.mtrl", Kit.FormA());
        Kit.Put(mod, "b.mtrl", Kit.FormA());
        kit.Upgrade(mod, [Kit.Worn(Kit.TopPath, mod, "a.mtrl"), Kit.Worn(Kit.DwnPath, mod, "b.mtrl")]);
        ShaderUpgradeWriter.RevertOrForget(mod, "a.mtrl", true, out _);
        ShaderUpgradeWriter.RevertOrForget(mod, "b.mtrl", true, out _);
        ShaderUpgradeWriter.ClearDeclines(mod, ["a.mtrl"]);
        Assert.False(ShaderUpgradeWriter.IsDeclined(mod, "a.mtrl"));
        Assert.True(ShaderUpgradeWriter.IsDeclined(mod, "b.mtrl"));
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-13")]
    [Trait("Plan", "EDGE-dt-shader-upgrade-61")]
    [Trait("Plan", "EDGE-issue-sweep-a-5")]
    public void Undo_after_author_update_keeps_the_file_and_only_our_redirects_and_masks_go()
    {
        using var kit = new Kit();
        var mod = kit.Dress("Bandana", Kit.FormB(), withSpec: true);
        Assert.True(kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)).ChangedAny);
        var update = CharacterShaderUpgrade.Upgrade(Kit.FormA())!;   // the author ships a Dawntrail file
        File.WriteAllBytes(Path.Combine(mod, "red", "top.mtrl"), update);
        Assert.False(ShaderUpgradeWriter.IsUpgraded(mod, Red));   // names no mask of ours: not counted as upgraded
        Assert.Equal(ShaderUpgradeWriter.Undone.Forgotten, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        Assert.Equal(update, Kit.Get(mod, Red));
        Assert.False(Directory.Exists(Path.Combine(mod, "Shader Upgrade")));
        Assert.DoesNotContain(Redirects(mod), r => r.File.Replace('\\', '/').StartsWith("Shader Upgrade"));
        Assert.False(Directory.Exists(Superseded(mod)));   // a diffuse entry has its mask: nothing archived
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-13")]
    public void Author_update_is_kept_by_undo_and_upgraded_again_when_legacy()
    {
        using var kit = new Kit();
        var mod = kit.Dress("D", Kit.FormA());
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
        var update = Kit.FormA();
        BitConverter.TryWriteBytes(update.AsSpan(GearMaterialWriter.ColorTableStart(update)), (Half)0.75f);
        File.WriteAllBytes(Path.Combine(mod, "red", "top.mtrl"), update);
        Assert.Equal(ShaderUpgradeWriter.Undone.Forgotten, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        Assert.Equal(update, Kit.Get(mod, Red));
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
        Assert.Equal(update, Kit.Get(mod, "Proteus/shaderupgrade-backup/red/top.mtrl"));
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-13")]
    [Trait("Plan", "EDGE-dt-shader-upgrade-73")]
    public void Author_update_between_walks_then_undo_keeps_the_authors_file()
    {
        using var kit = new Kit();
        var mod = kit.Dress("D", Kit.FormA());
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);   // walk 1: backup B1 = the original
        var f2 = Kit.FormA();
        BitConverter.TryWriteBytes(f2.AsSpan(GearMaterialWriter.ColorTableStart(f2)), (Half)0.5f);
        File.WriteAllBytes(Path.Combine(mod, "red", "top.mtrl"), f2);   // the author's new legacy file, no undo first
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);   // walk 2: forgets B1, backs F2 up, upgrades
        Assert.Equal(f2, Kit.Get(mod, "Proteus/shaderupgrade-backup/red/top.mtrl"));
        Assert.Equal(ShaderUpgradeWriter.Undone.Restored, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        Assert.Equal(f2, Kit.Get(mod, Red));   // never the first backup
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-13")]
    [Trait("Plan", "EDGE-dt-shader-upgrade-73")]
    public void Diffuse_author_update_between_walks_reuses_the_mask_it_was_told_to()
    {
        using var kit = new Kit();
        var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
        Assert.True(kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)).ChangedAny);
        // The author ships a new legacy diffuse file, its _s unchanged: the next plan reuses the mask already there.
        var f2 = Kit.FormB();
        BitConverter.TryWriteBytes(f2.AsSpan(GearMaterialWriter.ColorTableStart(f2)), (Half)0.5f);
        File.WriteAllBytes(Path.Combine(mod, "red", "top.mtrl"), f2);
        var plan = kit.Plan(WornRed(mod), _ => Spec(mod));
        Assert.Null(Assert.Single(plan.PerMod[0].Writes).Mask!.Rgba);
        var outcome = ShaderUpgradeWriter.Apply(mod, plan.PerMod[0].Writes, () => true, Kit.WriteTex, TexEncoding.Uncompressed);
        Assert.Equal([Red], outcome.Written);   // the forget of the old entry kept the mask this write reuses
        Assert.True(TextureLoader.IsCompleteTex(Path.Combine(mod, MaskSlotPathRel(mod))));
        Assert.Equal(ShaderUpgradeWriter.Undone.Restored, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        Assert.Equal(f2, Kit.Get(mod, Red));
    }

    private static string MaskSlotPathRel(string mod)
        => HairPortPlan.FileFor(HairPortPlan.ReadOwners(mod)!.Single(o => o.Option == "Red"), MaskSlotPath(Kit.Get(mod, Red))!)!;

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-13")]
    public void An_orphan_backup_never_stands_in_for_the_original()
    {
        using var kit = new Kit();
        var mod = kit.Dress("D", Kit.FormA());
        // A backup left by a write that failed before its record: not this file's original.
        var orphan = CharacterShaderUpgrade.Upgrade(Kit.FormA())!;
        Kit.Put(mod, "Proteus/shaderupgrade-backup/red/top.mtrl", orphan);
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
        Assert.Equal(Kit.FormA(), Kit.Get(mod, "Proteus/shaderupgrade-backup/red/top.mtrl"));
        ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _);
        Assert.Equal(Kit.FormA(), Kit.Get(mod, Red));
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-13")]
    [Trait("Plan", "EDGE-dt-shader-upgrade-73")]
    public void A_stale_backup_that_cannot_be_deleted_aborts_the_unit_and_the_next_walk_replaces_it()
    {
        using var kit = new Kit();
        var mod = kit.Dress("D", Kit.FormA());
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
        var f2 = Kit.FormA();
        BitConverter.TryWriteBytes(f2.AsSpan(GearMaterialWriter.ColorTableStart(f2)), (Half)0.4f);
        File.WriteAllBytes(Path.Combine(mod, "red", "top.mtrl"), f2);
        var backup = Path.Combine(mod, "Proteus", "shaderupgrade-backup", "red", "top.mtrl");
        using (new FileStream(backup, FileMode.Open, FileAccess.Read, FileShare.Read))   // File.Delete now throws
        {
            var outcome = kit.Upgrade(mod, WornRed(mod));
            Assert.Equal(LeftReason.WriteFailed, Assert.Single(outcome.Left).Reason);
            Assert.Equal(f2, Kit.Get(mod, Red));
            Assert.Empty(ShaderUpgradeWriter.ReadRecord(mod)?.Files ?? []);
        }
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
        Assert.Equal(f2, File.ReadAllBytes(backup));
        Assert.Equal(ShaderUpgradeWriter.Undone.Restored, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        Assert.Equal(f2, Kit.Get(mod, Red));
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-13")]
    public void Undo_refuses_a_material_edited_after_its_upgrade_and_keeps_its_original_and_mask()
    {
        using var kit = new Kit();
        var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
        Assert.True(kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)).ChangedAny);
        var entry = ShaderUpgradeWriter.ReadRecord(mod)!.Files.Single();
        var mask = entry.Mask!;
        // Saved from a material editor: still our character.shpk output naming our mask, one colour changed.
        var edited = Kit.Get(mod, Red);
        BitConverter.TryWriteBytes(edited.AsSpan(GearMaterialWriter.ColorTableStart(edited) + 2), (Half)0.3f);
        File.WriteAllBytes(Path.Combine(mod, "red", "top.mtrl"), edited);
        Assert.True(ShaderUpgradeWriter.IsUpgraded(mod, Red));   // still counted, not lost from the status

        Assert.Equal(ShaderUpgradeWriter.Undone.Refused, ShaderUpgradeWriter.RevertOrForget(mod, Red, true, out var why));
        Assert.Contains("red/top.mtrl", why);
        Assert.Equal(edited, Kit.Get(mod, Red));
        Assert.Equal(Kit.FormB(), Kit.Get(mod, "Proteus/shaderupgrade-backup/red/top.mtrl"));
        Assert.True(File.Exists(Path.Combine(mod, mask.Rel)));
        Assert.Contains(Redirects(mod), r => r.GamePath == mask.GamePath);
        Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
        Assert.True(ShaderUpgradeWriter.IsDeclined(mod, Red));

        // Copied back by hand as the message says: the next walk leaves it (declined), the next undo tidies up.
        File.Copy(Path.Combine(mod, "Proteus", "shaderupgrade-backup", "red", "top.mtrl"), Path.Combine(mod, "red", "top.mtrl"), true);
        var replan = kit.Plan(WornRed(mod), _ => Spec(mod));
        Assert.Empty(replan.PerMod);
        Assert.Equal(LeftReason.Declined, Assert.Single(replan.Left).Reason);
        Assert.False(kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)).ChangedAny);
        Assert.Equal(Kit.FormB(), Kit.Get(mod, Red));
        Assert.Equal(ShaderUpgradeWriter.Undone.Nothing, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        Assert.Empty(ShaderUpgradeWriter.ReadRecord(mod)?.Files ?? []);
        Assert.False(File.Exists(Path.Combine(mod, mask.Rel)));
        Assert.DoesNotContain(Redirects(mod), r => r.GamePath == mask.GamePath);
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-13")]
    public void A_legacy_file_still_naming_our_mask_is_not_taken_for_an_author_update()
    {
        using var kit = new Kit();
        var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
        Assert.True(kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)).ChangedAny);
        // Our output with its shader set back by hand: legacy again, matching neither hash, naming our mask. Simulated by
        // a record whose source hash differs and whose mask is the game path the legacy file names.
        File.Copy(Path.Combine(mod, "Proteus", "shaderupgrade-backup", "red", "top.mtrl"), Path.Combine(mod, "red", "top.mtrl"), true);
        var at = Path.Combine(mod, "Proteus", "shaderupgrade.json");
        var json = System.Text.Json.Nodes.JsonNode.Parse(File.ReadAllText(at))!;
        var file = json["Files"]![0]!;
        file["SourceSha8"] = "0000000000000000";
        file["Mask"]!["GamePath"] = Kit.SpecPath;
        File.WriteAllText(at, json.ToJsonString());

        var outcome = kit.Upgrade(mod, WornRed(mod), _ => Spec(mod));
        Assert.False(outcome.ChangedAny);
        Assert.Equal(LeftReason.WriteFailed, Assert.Single(outcome.Left).Reason);
        Assert.True(File.Exists(Path.Combine(mod, "Proteus", "shaderupgrade-backup", "red", "top.mtrl")));
        Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
    }

    [Fact]
    [Trait("Plan", "AC-dt-shader-upgrade-4")]
    public void A_skipped_diffuse_unit_leaves_no_mask_folder()
    {
        using var kit = new Kit();
        var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
        var plan = kit.Plan(WornRed(mod), _ => Spec(mod));
        var changed = Kit.FormB();
        BitConverter.TryWriteBytes(changed.AsSpan(GearMaterialWriter.ColorTableStart(changed)), (Half)0.2f);
        File.WriteAllBytes(Path.Combine(mod, "red", "top.mtrl"), changed);   // changed since planning: skipped
        var outcome = ShaderUpgradeWriter.Apply(mod, plan.PerMod[0].Writes, () => true, Kit.WriteTex, TexEncoding.Uncompressed);
        Assert.Empty(outcome.Written);
        Assert.False(Directory.Exists(Path.Combine(mod, "Shader Upgrade")));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-64")]
    public void Masks_are_encoded_outside_the_write_lock()
    {
        using var kit = new Kit();
        var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
        var plan = kit.Plan(WornRed(mod), _ => Spec(mod));
        bool heldDuringEncode = true;
        var outcome = ShaderUpgradeWriter.Apply(mod, plan.PerMod[0].Writes, () => true, (rgba, w, h, path, e) =>
        {
            heldDuringEncode = System.Threading.Monitor.IsEntered(MeshVolumeService.WriteLock)
                            || System.Threading.Monitor.IsEntered(ModManifestLock.Gate);
            return Kit.WriteTex(rgba, w, h, path, e);
        }, TexEncoding.Uncompressed);
        Assert.True(outcome.ChangedAny);
        Assert.False(heldDuringEncode);
        Assert.Empty(Directory.GetFiles(Path.Combine(mod, "Shader Upgrade"), "*.part"));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-59")]
    public void A_pending_entry_replanned_with_another_mask_takes_the_old_one_out()
    {
        using var kit = new Kit();
        var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
        ShaderUpgradeWriter.AfterStep = s => { if (s == "redirects") throw new CrashSim(); };
        try { kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)); } catch (CrashSim) { }
        finally { ShaderUpgradeWriter.AfterStep = null; }
        var oldMask = ShaderUpgradeWriter.ReadRecord(mod)!.Files.Single().Mask!;
        // Replanned with another strategy: another mask. The old mask's redirects and file go before the new ones land.
        var plan = kit.Plan(WornRed(mod), _ => Spec(mod), MaskGloss.MidConstant);
        Assert.Single(ShaderUpgradeWriter.Apply(mod, plan.PerMod[0].Writes, () => true, Kit.WriteTex, TexEncoding.Uncompressed).Written);
        Assert.DoesNotContain(Redirects(mod), r => r.GamePath == oldMask.GamePath);
        Assert.False(File.Exists(Path.Combine(mod, oldMask.Rel)));
        ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _);
        Assert.False(Directory.Exists(Path.Combine(mod, "Shader Upgrade")));
    }

    private sealed class CrashSim : Exception;

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-19")]
    [Trait("Plan", "EDGE-issue-sweep-a-1")]
    public void Material_write_failure_leaves_file_and_takes_out_its_mask()
    {
        using var kit = new Kit();
        var mod = kit.Dress("Bandana", Kit.FormB(), withSpec: true);
        var redirectsBefore = Redirects(mod);
        ShaderUpgradeWriter.AfterStep = step => { if (step == "redirects") throw new IOException("disk full"); };
        var outcome = kit.Upgrade(mod, WornRed(mod), _ => Spec(mod));
        ShaderUpgradeWriter.AfterStep = null;
        Assert.Empty(outcome.Written);
        Assert.Equal(LeftReason.WriteFailed, Assert.Single(outcome.Left).Reason);
        Assert.Equal(Kit.FormB(), Kit.Get(mod, Red));
        Assert.Equal(redirectsBefore, Redirects(mod));
        Assert.False(Directory.Exists(Path.Combine(mod, "Shader Upgrade")) && Directory.EnumerateFiles(Path.Combine(mod, "Shader Upgrade")).Any());
        Assert.Empty(ShaderUpgradeWriter.ReadRecord(mod)?.Files ?? []);
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-59")]
    public void A_crash_after_the_pending_entry_is_completed_or_cleaned_at_every_step()
    {
        foreach (var step in new[] { "pending", "mask", "redirects", "material" })
        {
            // Completed by the next Apply.
            using (var kit = new Kit())
            {
                var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
                Crash(kit, mod, step);
                Assert.True(ShaderUpgradeWriter.ReadRecord(mod)!.Files.Single().Pending || step == "material");
                if (step != "material") Assert.True(kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)).ChangedAny, step);
                Assert.Equal("character.shpk", CharacterShaderUpgrade.ShaderOf(Kit.Get(mod, Red)));
                Assert.Equal(Kit.FormB(), Kit.Get(mod, "Proteus/shaderupgrade-backup/red/top.mtrl"));
            }
            // Or cleaned by an undo.
            using (var kit = new Kit())
            {
                var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
                var redirectsBefore = Redirects(mod);
                Crash(kit, mod, step);
                ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _);
                Assert.Equal(Kit.FormB(), Kit.Get(mod, Red));
                Assert.Equal(redirectsBefore, Redirects(mod));
                Assert.False(Directory.Exists(Path.Combine(mod, "Shader Upgrade")), step);
                Assert.Empty(ShaderUpgradeWriter.ReadRecord(mod)?.Files ?? []);
            }
        }

        static void Crash(Kit kit, string mod, string at)
        {
            // A process kill: the step completes, then nothing more runs (not even the cleanup).
            ShaderUpgradeWriter.AfterStep = s => { if (s == at) throw new CrashException(); };
            try { kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)); }
            catch (CrashException) { }
            finally { ShaderUpgradeWriter.AfterStep = null; }
        }
    }

    private sealed class CrashException : Exception;

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-24")]
    public void Record_and_backups_move_with_the_folder()
    {
        using var kit = new Kit();
        var mod = kit.Dress("Before", Kit.FormA());
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
        var moved = Path.Combine(kit.ModsRoot, "After");
        Directory.Move(mod, moved);
        Assert.True(ShaderUpgradeWriter.IsUpgraded(moved, Red));
        Assert.Equal(ShaderUpgradeWriter.Undone.Restored, ShaderUpgradeWriter.RevertOrForget(moved, Red, false, out _));
        Assert.Equal(Kit.FormA(), Kit.Get(moved, Red));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-39")]
    public void Mask_gate_refuses_bad_files_and_writes_atomically()
    {
        using var kit = new Kit();
        var mod = kit.Dress("M", Kit.FormA());
        var px = new byte[8 * 8 * 4];
        for (int i = 0; i < px.Length; i += 4) { px[i] = (byte)i; px[i + 1] = 9; px[i + 2] = 255; px[i + 3] = 255; }
        var mask = new MaskWrite("Shader Upgrade/aaaaaaaaaaaaaaaa_mask.tex", "chara/x/dt_a_mask.tex", 8, 8, px, []);
        var dir = Path.Combine(mod, "Shader Upgrade");

        Assert.Throws<ShaderUpgradeWriter.WriteRefused>(() => ShaderUpgradeWriter.WriteMask(mod, mask, TexEncoding.Uncompressed,
            (rgba, _, _, path, e) => Kit.WriteTex(new byte[4 * 4 * 4], 4, 4, path, e)));
        Assert.Empty(Directory.GetFiles(dir));
        Assert.Throws<ShaderUpgradeWriter.WriteRefused>(() =>
            ShaderUpgradeWriter.WriteMask(mod, mask, TexEncoding.Uncompressed, (_, _, _, _, _) => false));
        Assert.Empty(Directory.GetFiles(dir));
        Assert.Throws<ShaderUpgradeWriter.WriteRefused>(() =>
            ShaderUpgradeWriter.WriteMask(mod, mask with { Rel = "red/evil_mask.tex" }, TexEncoding.Uncompressed, Kit.WriteTex));
        var path = ShaderUpgradeWriter.WriteMask(mod, mask, TexEncoding.Uncompressed, Kit.WriteTex);
        Assert.Equal([path], Directory.GetFiles(dir));
        Assert.True(TextureLoader.IsCompleteTex(path));

        var head = File.ReadAllBytes(path)[..16];
        long len = new FileInfo(path).Length;
        Assert.True(IsSoundMaskHeader(head, len, 8, 8));
        Assert.False(IsSoundMaskHeader(head, len - 1, 8, 8));
        var twoMips = (byte[])head.Clone(); twoMips[14] = 2;
        Assert.False(IsSoundMaskHeader(twoMips, len, 8, 8));
        var (s, w, h) = Kit.Spec();
        var good = MaskFrom(s, w, h, MaskGloss.InverseSpecular).Rgba;
        Assert.True(IsSoundMaskBuffer(good, w, h, s, w, h, MaskGloss.InverseSpecular));
        var badB = (byte[])good.Clone(); badB[2] = 200;
        Assert.False(IsSoundMaskBuffer(badB, w, h, s, w, h, MaskGloss.InverseSpecular));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-39")]
    public void The_mods_specular_file_is_never_written()
    {
        using var kit = new Kit();
        var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
        var s = Kit.Get(mod, "tex/top_s.tex");
        kit.Upgrade(mod, WornRed(mod), _ => Spec(mod));
        ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _);
        Assert.Equal(s, Kit.Get(mod, "tex/top_s.tex"));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-46")]
    public void A_gloss_change_does_not_touch_upgraded_files()
    {
        using var kit = new Kit();
        var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
        kit.Upgrade(mod, WornRed(mod), _ => Spec(mod));
        var after = Kit.Get(mod, Red);
        Assert.Empty(kit.Plan(WornRed(mod), _ => Spec(mod), MaskGloss.MidConstant).PerMod);   // character.shpk now: skipped
        Assert.Equal(after, Kit.Get(mod, Red));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-58")]
    public void A_file_changed_since_planning_is_skipped()
    {
        using var kit = new Kit();
        var mod = kit.Dress("D", Kit.FormA());
        var plan = kit.Plan(WornRed(mod));
        var changed = Kit.FormA();
        BitConverter.TryWriteBytes(changed.AsSpan(GearMaterialWriter.ColorTableStart(changed)), (Half)0.3f);
        File.WriteAllBytes(Path.Combine(mod, "red", "top.mtrl"), changed);
        var outcome = ShaderUpgradeWriter.Apply(mod, plan.PerMod[0].Writes, () => true, Kit.WriteTex, TexEncoding.Uncompressed);
        Assert.Empty(outcome.Written);
        Assert.True(outcome.Rewalk);
        Assert.Equal(changed, Kit.Get(mod, Red));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-65")]
    public void Identical_masks_share_a_file_and_survive_a_partial_undo()
    {
        using var kit = new Kit();
        var mod = kit.Mod("Twin", null,
            ("Top", "Single", [("A", new Dictionary<string, string> { [Kit.TopPath] = "a.mtrl", [Kit.SpecPath] = "s.tex" })]),
            ("Legs", "Single", [("B", new Dictionary<string, string> { [Kit.DwnPath] = "b.mtrl", [Kit.SpecPath] = "s.tex" })]));
        Kit.Put(mod, "a.mtrl", Kit.FormB());
        Kit.Put(mod, "b.mtrl", Kit.FormB());
        Kit.Put(mod, "s.tex", Kit.Fixture("legacy_spec_s.tex"));
        kit.Upgrade(mod, [Kit.Worn(Kit.TopPath, mod, "a.mtrl"), Kit.Worn(Kit.DwnPath, mod, "b.mtrl")], _ => Path.Combine(mod, "s.tex"));
        var masks = Directory.GetFiles(Path.Combine(mod, "Shader Upgrade"));
        Assert.Single(masks);
        ShaderUpgradeWriter.RevertOrForget(mod, "a.mtrl", false, out _);
        Assert.True(File.Exists(masks[0]));   // b still names it
        ShaderUpgradeWriter.RevertOrForget(mod, "b.mtrl", false, out _);
        Assert.False(File.Exists(masks[0]));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-67")]
    public void A_vanished_mod_folder_fails_cleanly()
    {
        using var kit = new Kit();
        var mod = kit.Dress("Gone", Kit.FormA());
        var plan = kit.Plan(WornRed(mod));
        Directory.Delete(mod, true);
        var outcome = ShaderUpgradeWriter.Apply(mod, plan.PerMod[0].Writes, () => true, Kit.WriteTex, TexEncoding.Uncompressed);
        Assert.Empty(outcome.Written);
        Assert.True(outcome.Rewalk);
        Assert.False(Directory.Exists(mod));
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-70")]
    public void Concurrent_manifest_edits_survive_and_a_removed_option_fails_cleanly()
    {
        using var kit = new Kit();
        var mod = kit.Dress("B", Kit.FormB(), withSpec: true);
        var plan = kit.Plan(WornRed(mod), _ => Spec(mod));
        // Someone adds a redirect to Red after planning: it survives our merge.
        PenumbraModMeta.MergeOptionRedirects(mod, "Colour", "Red", new Dictionary<string, string> { ["chara/x/extra.tex"] = "extra.tex" });
        Assert.Single(ShaderUpgradeWriter.Apply(mod, plan.PerMod[0].Writes, () => true, Kit.WriteTex, TexEncoding.Uncompressed).Written);
        Assert.Contains(Redirects(mod), r => r.GamePath == "chara/x/extra.tex");

        // An option removed since planning: write-failed, and the mask is taken out again.
        using var kit2 = new Kit();
        var mod2 = kit2.Dress("C", Kit.FormB(), withSpec: true);
        var plan2 = kit2.Plan(WornRed(mod2), _ => Spec(mod2));
        var meta = File.ReadAllText(Path.Combine(mod2, "meta.json")).Replace("\"Name\":\"Red\"", "\"Name\":\"Crimson\"");
        File.WriteAllText(Path.Combine(mod2, "meta.json"), meta);
        var outcome = ShaderUpgradeWriter.Apply(mod2, plan2.PerMod[0].Writes, () => true, Kit.WriteTex, TexEncoding.Uncompressed);
        Assert.Equal(LeftReason.WriteFailed, Assert.Single(outcome.Left).Reason);
        Assert.Equal(Kit.FormB(), Kit.Get(mod2, Red));
        Assert.False(Directory.Exists(Path.Combine(mod2, "Shader Upgrade")) && Directory.EnumerateFiles(Path.Combine(mod2, "Shader Upgrade")).Any());
    }

    [Fact]
    [Trait("Plan", "EDGE-dt-shader-upgrade-72")]
    public void Apply_refuses_a_sidecar_pack_folder()
    {
        using var kit = new Kit();
        var mod = kit.Dress("Pack", Kit.FormA());
        Kit.Put(mod, "Proteus/metadata.json", "{}"u8.ToArray());
        var before = Kit.Hashes(mod);
        var write = new MaterialWrite(Red, [Kit.TopPath], LegacyForm.IndexMask, Sha8(Kit.FormA()),
                                      WindNeutral(CharacterShaderUpgrade.Upgrade(Kit.FormA())!)!, null);
        var outcome = ShaderUpgradeWriter.Apply(mod, [write], () => true, Kit.WriteTex, TexEncoding.Uncompressed);
        Assert.Equal(LeftReason.ProteusPack, Assert.Single(outcome.Left).Reason);
        Assert.Equal(before, Kit.Hashes(mod));
    }

    // ── issue sweep A: #68 (an unreadable material is an unknown state) and #66 (an edit we can't detect) ──

    private static string Superseded(string mod) => Path.Combine(mod, "Proteus", ShaderUpgradeWriter.SupersededSubdir);
    private static string RedPath(string mod) => Path.Combine(mod, "red", "top.mtrl");
    private static string RedBackup(string mod) => Path.Combine(mod, "Proteus", "shaderupgrade-backup", "red", "top.mtrl");

    private static byte[] EditColour(byte[] mtrl, float value)
    {
        var edited = (byte[])mtrl.Clone();
        BitConverter.TryWriteBytes(edited.AsSpan(GearMaterialWriter.ColorTableStart(edited) + 2), (Half)value);
        return edited;
    }

    [Fact]
    [Trait("Plan", "AC-issue-sweep-a-1")]
    [Trait("Plan", "EDGE-issue-sweep-a-3")]
    public void An_unreadable_material_after_a_failed_unit_keeps_its_entry_and_backup()
    {
        // Locked: the material was written, then the unit failed while something held the file.
        using (var kit = new Kit())
        {
            var mod = kit.Dress("D", Kit.FormA());
            FileStream? hold = null;
            ShaderUpgradeWriter.AfterStep = s =>
            {
                if (s != "material") return;
                hold = new FileStream(RedPath(mod), FileMode.Open, FileAccess.ReadWrite, FileShare.None);
                throw new IOException("record write failed");
            };
            ShaderUpgradeWriter.Outcome outcome;
            try { outcome = kit.Upgrade(mod, WornRed(mod)); }
            finally { ShaderUpgradeWriter.AfterStep = null; }
            try
            {
                Assert.True(outcome.Rewalk);
                Assert.Equal(LeftReason.WriteFailed, Assert.Single(outcome.Left).Reason);
                Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
                Assert.Equal(Kit.FormA(), File.ReadAllBytes(RedBackup(mod)));
            }
            finally { hold?.Dispose(); }
            Assert.True(ShaderUpgradeWriter.IsUpgraded(mod, Red));
            Assert.Equal(ShaderUpgradeWriter.Undone.Restored, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
            Assert.Equal(Kit.FormA(), Kit.Get(mod, Red));
        }
        // Empty (an outside tool part-way through a save): unknown too.
        using (var kit = new Kit())
        {
            var mod = kit.Dress("D", Kit.FormA());
            ShaderUpgradeWriter.AfterStep = s =>
            {
                if (s != "material") return;
                File.WriteAllBytes(RedPath(mod), []);
                throw new IOException("record write failed");
            };
            ShaderUpgradeWriter.Outcome outcome;
            try { outcome = kit.Upgrade(mod, WornRed(mod)); }
            finally { ShaderUpgradeWriter.AfterStep = null; }
            Assert.True(outcome.Rewalk);
            Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
            Assert.Equal(Kit.FormA(), File.ReadAllBytes(RedBackup(mod)));
        }
        // Missing: an unknown state too, kept for the next walk.
        using (var kit = new Kit())
        {
            var mod = kit.Dress("D", Kit.FormA());
            ShaderUpgradeWriter.AfterStep = s =>
            {
                if (s != "material") return;
                File.Delete(RedPath(mod));
                throw new IOException("record write failed");
            };
            ShaderUpgradeWriter.Outcome outcome;
            try { outcome = kit.Upgrade(mod, WornRed(mod)); }
            finally { ShaderUpgradeWriter.AfterStep = null; }
            Assert.True(outcome.Rewalk);
            Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
            Assert.Equal(Kit.FormA(), File.ReadAllBytes(RedBackup(mod)));
        }
    }

    [Fact]
    [Trait("Plan", "EDGE-issue-sweep-a-2")]
    public void A_failed_record_write_after_the_material_keeps_the_upgrade_undoable()
    {
        using var kit = new Kit();
        var mod = kit.Dress("D", Kit.FormA());
        ShaderUpgradeWriter.AfterStep = s => { if (s == "material") throw new IOException("record write failed"); };
        try { kit.Upgrade(mod, WornRed(mod)); }
        finally { ShaderUpgradeWriter.AfterStep = null; }
        Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
        Assert.Equal(ShaderUpgradeWriter.Undone.Restored, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        Assert.Equal(Kit.FormA(), Kit.Get(mod, Red));
    }

    [Fact]
    [Trait("Plan", "AC-issue-sweep-a-1")]
    [Trait("Plan", "EDGE-issue-sweep-a-26")]
    public void Undo_of_a_locked_or_empty_material_fails_and_forgets_nothing()
    {
        foreach (var formB in new[] { false, true })
        {
            using var kit = new Kit();
            var mod = formB ? kit.Dress("B", Kit.FormB(), withSpec: true) : kit.Dress("A", Kit.FormA());
            var original = formB ? Kit.FormB() : Kit.FormA();
            Assert.True((formB ? kit.Upgrade(mod, WornRed(mod), _ => Spec(mod)) : kit.Upgrade(mod, WornRed(mod))).ChangedAny);
            var redirects = Redirects(mod);
            var mask = ShaderUpgradeWriter.ReadRecord(mod)!.Files.Single().Mask;
            using (new FileStream(RedPath(mod), FileMode.Open, FileAccess.ReadWrite, FileShare.None))
            {
                Assert.Equal(ShaderUpgradeWriter.Undone.Failed, ShaderUpgradeWriter.RevertOrForget(mod, Red, true, out var why));
                Assert.Contains(Red, why);
            }
            Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
            Assert.False(ShaderUpgradeWriter.IsDeclined(mod, Red));
            Assert.Equal(original, File.ReadAllBytes(RedBackup(mod)));
            Assert.Equal(redirects, Redirects(mod));
            if (mask != null) Assert.True(File.Exists(Path.Combine(mod, mask.Rel)));
            Assert.False(Directory.Exists(Superseded(mod)));
            // An empty file (a save still being written) is as unknown as a locked one.
            var upgraded = Kit.Get(mod, Red);
            File.WriteAllBytes(RedPath(mod), []);
            Assert.Equal(ShaderUpgradeWriter.Undone.Failed, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out var whyEmpty));
            Assert.Contains("is empty", whyEmpty);
            Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
            Assert.Equal(original, File.ReadAllBytes(RedBackup(mod)));
            Assert.Equal(redirects, Redirects(mod));
            if (mask != null) Assert.True(File.Exists(Path.Combine(mod, mask.Rel)));
            Assert.False(Directory.Exists(Superseded(mod)));
            File.WriteAllBytes(RedPath(mod), upgraded);
            Assert.Equal(ShaderUpgradeWriter.Undone.Restored, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
            Assert.Equal(original, Kit.Get(mod, Red));
        }
    }

    [Fact]
    [Trait("Plan", "AC-issue-sweep-a-2")]
    [Trait("Plan", "EDGE-issue-sweep-a-8")]
    public void Undo_of_an_edited_index_mask_material_archives_its_original()
    {
        // Edited after the upgrade (a material editor's save): kept, and the author's original archived.
        using (var kit = new Kit())
        {
            var mod = kit.Dress("A", Kit.FormA());
            Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
            var edited = EditColour(Kit.Get(mod, Red), 0.3f);
            File.WriteAllBytes(RedPath(mod), edited);
            Assert.Equal(ShaderUpgradeWriter.Undone.Forgotten, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out var why));
            Assert.Contains(ShaderUpgradeWriter.SupersededSubdir, why);
            Assert.Equal(edited, Kit.Get(mod, Red));
            Assert.Equal(Kit.FormA(), File.ReadAllBytes(Path.Combine(Superseded(mod), "red", "top.mtrl")));
            Assert.False(File.Exists(RedBackup(mod)));
            Assert.Empty(ShaderUpgradeWriter.ReadRecord(mod)?.Files ?? []);
        }
        // Truly missing at undo: forgotten, the original archived all the same.
        using (var kit = new Kit())
        {
            var mod = kit.Dress("A", Kit.FormA());
            Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
            File.Delete(RedPath(mod));
            Assert.Equal(ShaderUpgradeWriter.Undone.Forgotten, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
            Assert.Equal(Kit.FormA(), File.ReadAllBytes(Path.Combine(Superseded(mod), "red", "top.mtrl")));
            Assert.Empty(ShaderUpgradeWriter.ReadRecord(mod)?.Files ?? []);
        }
    }

    [Fact]
    [Trait("Plan", "EDGE-issue-sweep-a-4")]
    public void Undo_of_an_untouched_or_original_index_mask_file_archives_nothing()
    {
        using (var kit = new Kit())
        {
            var mod = kit.Dress("A", Kit.FormA());
            Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
            Assert.Equal(ShaderUpgradeWriter.Undone.Restored, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
            Assert.False(Directory.Exists(Superseded(mod)));
        }
        using (var kit = new Kit())
        {
            var mod = kit.Dress("A", Kit.FormA());
            Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
            File.WriteAllBytes(RedPath(mod), Kit.FormA());   // the original put back by hand
            Assert.Equal(ShaderUpgradeWriter.Undone.Nothing, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
            Assert.False(File.Exists(RedBackup(mod)));
            Assert.False(Directory.Exists(Superseded(mod)));
        }
    }

    [Fact]
    [Trait("Plan", "EDGE-issue-sweep-a-6")]
    public void A_second_archive_of_the_same_file_gets_its_own_name()
    {
        using var kit = new Kit();
        var mod = kit.Dress("A", Kit.FormA());
        var first = Kit.FormA();
        var second = EditColour(Kit.FormA(), 0.6f);   // the author's later legacy file
        foreach (var legacy in new[] { first, second })
        {
            File.WriteAllBytes(RedPath(mod), legacy);
            Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
            File.WriteAllBytes(RedPath(mod), EditColour(Kit.Get(mod, Red), 0.2f));
            Assert.Equal(ShaderUpgradeWriter.Undone.Forgotten, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        }
        var files = Directory.GetFiles(Path.Combine(Superseded(mod), "red"));
        Assert.Equal(2, files.Length);
        Assert.Equal(first, File.ReadAllBytes(Path.Combine(Superseded(mod), "red", "top.mtrl")));
        Assert.Equal(second, File.ReadAllBytes(Assert.Single(files, f => Path.GetFileName(f) != "top.mtrl")));
    }

    [Fact]
    [Trait("Plan", "EDGE-issue-sweep-a-7")]
    public void A_failed_archive_move_fails_the_undo_and_forgets_nothing()
    {
        using var kit = new Kit();
        var mod = kit.Dress("A", Kit.FormA());
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
        File.WriteAllBytes(RedPath(mod), EditColour(Kit.Get(mod, Red), 0.3f));
        File.WriteAllBytes(Superseded(mod), [1, 2, 3]);   // a file where the archive folder should be
        Assert.Equal(ShaderUpgradeWriter.Undone.Failed, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
        Assert.Equal(Kit.FormA(), File.ReadAllBytes(RedBackup(mod)));
    }

    [Fact]
    [Trait("Plan", "EDGE-issue-sweep-a-27")]
    public void An_archived_backup_survives_a_failed_record_write_and_the_next_undo_finishes()
    {
        using var kit = new Kit();
        var mod = kit.Dress("A", Kit.FormA());
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
        File.WriteAllBytes(RedPath(mod), EditColour(Kit.Get(mod, Red), 0.3f));
        var record = Path.Combine(mod, "Proteus", ShaderUpgradeWriter.RecordFile);
        var archive = Path.Combine(Superseded(mod), "red", "top.mtrl");
        File.SetAttributes(record, FileAttributes.ReadOnly);
        try
        {
            Assert.Equal(ShaderUpgradeWriter.Undone.Failed, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
            Assert.Equal(Kit.FormA(), File.ReadAllBytes(archive));
            Assert.Single(ShaderUpgradeWriter.ReadRecord(mod)!.Files);
        }
        finally { File.SetAttributes(record, FileAttributes.Normal); }
        Assert.Equal(ShaderUpgradeWriter.Undone.Forgotten, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        Assert.Equal(Kit.FormA(), File.ReadAllBytes(archive));
        Assert.Empty(ShaderUpgradeWriter.ReadRecord(mod)?.Files ?? []);
    }

    [Fact]
    [Trait("Plan", "EDGE-issue-sweep-a-9")]
    public void The_archive_survives_folder_cleanup_and_blocks_no_other_feature()
    {
        using var kit = new Kit();
        var mod = kit.Dress("A", Kit.FormA());
        Assert.True(kit.Upgrade(mod, WornRed(mod)).ChangedAny);
        File.WriteAllBytes(RedPath(mod), EditColour(Kit.Get(mod, Red), 0.3f));
        Assert.Equal(ShaderUpgradeWriter.Undone.Forgotten, ShaderUpgradeWriter.RevertOrForget(mod, Red, false, out _));
        Assert.False(Directory.Exists(Path.Combine(mod, "Proteus", ShaderUpgradeWriter.BackupSubdir)));
        var archive = Path.Combine(Superseded(mod), "red", "top.mtrl");
        Assert.True(File.Exists(archive));
        File.SetLastWriteTimeUtc(archive, DateTime.UtcNow.AddMinutes(5));
        // A brush backup of the same file, older than the archive: were the archive read as a feature's backup, it would
        // count as a later feature and block the brush's undo.
        var brush = Path.Combine(mod, "Proteus", MeshVolumeService.BackupSubdir, "red", "top.mtrl");
        Directory.CreateDirectory(Path.GetDirectoryName(brush)!);
        File.WriteAllBytes(brush, Kit.FormA());
        File.SetLastWriteTimeUtc(brush, DateTime.UtcNow.AddMinutes(-5));
        Assert.Null(ModelBackupOrder.LaterFeature(mod, MeshVolumeService.BackupSubdir, Red));
    }
}
