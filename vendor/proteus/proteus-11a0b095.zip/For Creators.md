
## For Mod Authors

### How It Works

EZ Mode to just start creating: https://github.com/solona-m/substance-proteus-packager will give you one click mod publishing. Install the mod. Set your colorset rows in the /proteus editor and reexport the mod from penumbra.

Proteus scans for Penumbra mods that contain a `Proteus/` subfolder. At composite time it:

1. Resolves which of your character's textures are active (respecting all other mods in your load order).
2. Loads those textures as a base.
3. Alpha-composites your overlay PNGs on top.
4. Writes the result to Proteus's own internal managed mod and reloads it via Penumbra.

Your mod does **not** need any Penumbra file redirects for the composited textures — Proteus handles that automatically.

### Sidecar Structure

Inside your Penumbra mod folder, create a `Proteus/` subfolder:

```
YourMod/
  meta.json               ← Penumbra mod metadata: default option + any
                            option groups (you already have this)
  Proteus/
    metadata.json         ← Proteus sidecar — required
    OptionA/
      diffuse.png
      normal.png
    OptionB/
      diffuse.png
```

### metadata.json

#### Minimal example — unconditional overlay

```json
{
  "FormatVersion": 1,
  "Name": "My Tattoo",
  "Author": "YourName",
  "Overlays": [
    {
      "MaterialGamePath": "chara/human/c0201/obj/body/b0001/material/v0001/mt_c0201b0001_bibo.mtrl",
      "Diffuse": "overlays/diffuse.png",
      "Normal":  "overlays/normal.png"
    }
  ],
  "ColorTableRows": [
    { "Row": 16, "SubRowA": { "Diffuse": "#FFFFFF", "Emissive": 0.0 } }
  ]
}
```

#### Overlay descriptor fields

| Field | Required | Description |
|-------|----------|-------------|
| `MaterialGamePath` | Yes | The game path of the `.mtrl` file this overlay targets. Proteus reads the material to find the actual texture game paths. |
| `Diffuse` | No | Path to your diffuse overlay PNG, relative to the `Proteus/` folder. |
| `Normal` | No | Path to your normal map overlay PNG. Its relief is added to the normal beneath, wherever the overlay covers; its alpha sets how strongly. On a normal-only overlay the alpha is also the coverage — see [Normal-only overlays](#normal-only-overlays). |
| `NormalMode` | No | `"Compound"` (the default) adds your relief to the relief beneath, so both show. `"Replace"` overwrites the relief beneath wherever the overlay covers — for an overlay that *is* the whole skin — and also writes your blue channel, which the skin shader reads as skin-colour influence. |
| `Mask` | No | Path to your mask/specular overlay PNG. |
| `Index` | No | Path to your index texture PNG. Enables per-region coloring. See below. |
| `GenerateDiffuse` | No | Currently has no effect: normal-only overlays no longer tint the skin. Still read, so existing packs keep loading. |
| `SkinToneMask` | No | `0`–`1`. How strongly to keep the character's skin tone out of this overlay (so an opaque overlay looks the same on any skin tone). Omitted = full masking (the default). Set `0` to let skin tone show through fully — use for tattoos/decals that should take the skin's color. Editable in Colors → Advanced. See [Skin-tone masking](#skin-tone-masking). |

All paths are relative to the `Proteus/` folder. Subfolders and spaces in names are fine.

#### ColorTableRows

Color table rows control how Proteus tints and illuminates the overlay. Rows are numbered 1–16 to match FFXIV's colorset numbering. Any row not specified defaults to white diffuse and zero emissive (pass-through).

```json
"ColorTableRows": [
  {
    "Row": 16,
    "SubRowA": { "Diffuse": "#FF8844", "Emissive": 0.0 },
    "SubRowB": { "Diffuse": "#FFFFFF", "Emissive": 0.0 }
  }
]
```

- **Diffuse**: hex color (`#RRGGBB` or `#RGB`). Multiplied against the overlay pixel. White = natural colors. Black = invisible. Any other color tints.
- **Emissive**: glow intensity 0–1. Skin cannot glow, so any row with emissive > 0 promotes the overlay to a cloth layer — a shell with its own material — and it renders there. The promotion happens automatically, whether you declare it here or the user sets it in the editor.
- **LightResponse**: 0–1, how much the scene's light takes this row's glow away. Omitted or 0 is the unconditional glow every row had before — the same brightness in a lit street as in a cellar. 1 is dark-only: full brightness with no light on the wearer, nothing at all in daylight. It only means something where `Emissive` is above zero. Because it is per sub-row, one region of a tattoo can be dark-only while another is always on; the two are told apart by your `_id` texture, the same way their colours are.
- **HideInLight**: `true` makes the row's *opacity follow its glow* — as the light takes the glow away it takes the surface with it, so where the row has stopped glowing there is nothing left but skin. Without it a dark-only row still leaves the shell's own colour behind, usually the near-black a glowing material wants, and the art reads as a dark silhouette at noon rather than vanishing. Per row, like `LightResponse`, because the opacity it moves is the shell normal's blue channel and your `_id` says which texel belongs to which row: one region can vanish in daylight while the region beside it stays. A `HideInLight` with no `LightResponse` follows the glow all the way; with one, it fades only as far as the glow does.

- **Blend**: how the row combines with what your mod has already painted. `"Paint"` (the default, and what every row did before this existed) lays the art on top. Anything else makes the row a **print** — see below.

None of these are baked into anything: Proteus applies them to the live material each frame, so the light changing costs no recomposite and nothing on disk is rebuilt. Users can switch the whole behaviour off, or pin the light level by hand, under **Settings → Light-sensitive glow**.

##### The fabric weave — `"Tile"`

- **Tile**: which of the game's 64 fabric weaves tiles over this row, `0`–`63`. This is what makes a second skin read as *cloth* rather than skin, and it costs no texture of your own — the patterns are the game's, shared by every gear material. Proteus leaves it off by default, because the weave a gear template ships with looks like grain over bare skin. Note `0` is a real weave, not "off": omit the field for no weave. Like glow, it needs the gear shader, so setting it promotes a skin overlay to a cloth layer.
- **TileStrength**: `0`–`1`, how strongly the weave shows. Omitted means full strength.
- **TileScaleU** / **TileScaleV**: how many times the weave repeats across each axis of the texture. Omitted is the game's own default of `16`; higher is finer. Setting the two apart stretches the weave in one direction.

Both only mean something alongside a `Tile`, and are ignored without one. On their own they would re-arm whatever weave the material already happens to name — the gear template's on a shell, the author's on an imported pack — which is never a pattern anyone picked.

```json
"ColorTableRows": [
  { "Row": 16, "SubRowA": { "Diffuse": "#FFFFFF", "Tile": 12, "TileScaleU": 24.0, "TileScaleV": 24.0 } }
]
```

Unlike the light settings above, the weave is written into the shell's material when the look is composited, not applied per frame.

##### Prints — `"Blend"`

A print colours the fabric your other layers painted, instead of covering it. Give a fishnet stocking a rainbow print and the *threads* come out rainbow while the holes stay skin — which a plain overlay cannot do, because it would paint over the holes too.

```json
"ColorTableRows": [
  { "Row": 16, "SubRowA": { "Diffuse": "#FFFFFF", "Blend": "Multiply" } }
]
```

| Mode | What it does |
|---|---|
| `Paint` | Alpha-over, the default. The row brings its own colour and lays it on top. |
| `Multiply` | Darkens. White is invisible, black is opaque. What a printed pattern usually wants — ink on cloth takes the cloth's shading with it. |
| `Screen` | Lightens. The complement of `Multiply`, and what a bright print on dark fabric needs. |
| `Overlay` | `Multiply` in the fabric's shadows, `Screen` in its highlights. Keeps the weave's contrast, so the print reads as dyed *into* the cloth. |
| `Add` | Purely additive — a sheen, or a dusting of glitter. Saturates to white. |
| `Replace` | Takes the row's colour outright, keeping the fabric's shape. Flat, and loses the fabric's own shading. |

Three rules worth knowing before you author one:

- **A print only reaches your own mod's layers.** It never touches another mod's clothing, so a print cannot be shipped as a way to recolour someone else's work.
- **On bare skin a print paints nothing.** Selected on its own it shows nothing at all — there is nothing there to print on. This is deliberate, not a failure; the plugin log says so at debug level.
- **A print is never promoted to a cloth layer.** It has no coverage of its own to cut a shell from, and a shell would take it away from the very layers it exists to colour. Put glow on the fabric, not on the print.
- **A print contributes colour and nothing else.** Its `Normal` and `Mask` are clipped to the same coverage its colour is, so a row that prints everywhere adds no relief, no gloss, no ambient occlusion and no skin-tone suppression. Relief belongs on the fabric, which is the thing that actually has a surface. If your print ships a normal map intending it to apply on its own, make the row `Paint` instead.

If a row prints but its option also declares an `Index` that fails to load, Proteus cannot tell which texel belongs to which row, so the rows fall back to painting and a warning naming the mod goes to the log — the print will look like it simply stopped working.

Because `Blend` is per sub-row, one region of a print can multiply while the region beside it screens — your `_id` texture tells them apart exactly as it does their colours. Mixing a printing row and a painting row in one option is allowed; the option then still counts as a surface (it casts ambient occlusion, and can still be promoted).

The row's `Diffuse` still tints the art, and its `Opacity` is the print's strength.

Users can override these values at any time from the Proteus status window. Their changes are written back to your `metadata.json` inside their local mod installation.

#### Normal-only overlays

If you provide a `Normal` but no `Diffuse`, there is no colour art to say where the overlay is, so Proteus reads its shape from the normal's **alpha**: 255 is fully covered, 0 is not there at all. The relief is applied only where alpha has value, and the skin's colour is left untouched. It suits lace, fabric texture or wetness — relief that follows the shape of a garment.

The **blue channel is not coverage** on a skin overlay. The skin shader reads a normal's blue as skin-colour influence, so Proteus leaves it out of the question of where your overlay is. In the default `Compound` mode your blue is not used at all; in `Replace` mode it is written as skin-colour influence. (A gear layer is different: on a second-skin shell the normal's blue *is* its transparency, and Proteus writes it from the shell's coverage.)

A normal-only overlay hides the normals beneath it in the same mod only **where it has relief** — near texels whose red and green are away from flat. So a normal exported the usual way, opaque and flat over most of the sheet, hides nothing where it is flat, and the layers beneath keep their relief there (see [How layers stack](#how-layers-stack)).

> In earlier versions a normal-only skin overlay took its coverage from the blue channel instead, so a normal exported the usual way (blue ≈ 255 everywhere) covered the whole body and hid every normal beneath it. A pack that shaped its normal with blue and left alpha opaque should move that shape into alpha.

```json
{
  "MaterialGamePath": "chara/human/c0201/obj/body/b0001/material/v0001/mt_c0201b0001_bibo.mtrl",
  "Normal": "Wet/normal.png",
  "Mask":   "Wet/mask.png"
}
```

> Normal-only overlays used to tint the skin diffuse with Row 16's colour, switched off per overlay by `"GenerateDiffuse": false`. They no longer do; the flag is still accepted and has no effect.

> A `Mask`-only overlay (no `Diffuse` **and** no `Normal`) is also supported: the mask PNG's own alpha defines where it applies. Useful for effects carried entirely in the mask/multi map, like wetness specular.

**Men's bodies.** You don't need to list men's races. An overlay made for women (saved as bibo, or naming only women's bibo or gen3 body materials) is also painted on a man wearing TBSE or the men's vanilla body. It is moved into his own layout through the men's body maps (see [docs/uvmaps.md](docs/uvmaps.md)), and its gear and mask shells are moved with it. An overlay saved as gen3 or gen2 counts as a man's own art and is never moved. Players can switch this off per mod with **Overlay on men**.

### Skin-tone masking

The skin shader (`skin.shpk`, used by Bibo+ bodies) multiplies the diffuse by the character's **skin tone**. Because Proteus composites your overlay into that diffuse, an opaque overlay would otherwise be darkened/tinted by skin tone — most visible as a bright/white overlay turning beige on darker skin. Proteus masks the skin tone out of opaque overlay pixels so they render at their authored color on any skin tone. The masking is automatically scaled by pixel brightness (bright pixels are fully de-tinted; dark pixels are left alone, since skin tone is invisible on dark color and masking it would slightly increase shine).

Most overlays want this and need no setting. Use `SkinToneMask` when an overlay should instead **take the skin's color** — a tattoo, freckles, blush, a decal, or anything that sits *on* the skin rather than covering it:

```json
{
  "MaterialGamePath": "chara/human/c0201/obj/body/b0001/material/v0001/mt_c0201b0001_bibo.mtrl",
  "Diffuse": "Tattoo/diffuse.png",
  "SkinToneMask": 0
}
```

`0` lets skin tone through fully; `1` (or omitting it) is full masking; values between blend. Users also have a global "Skin-tint suppression" slider in `/proteus` that scales this — your `SkinToneMask: 0` always wins (the skin tone is never masked for that overlay).

You don't have to write it by hand. **Colors → Advanced** has a per-option "Skin-tint suppression" slider that edits this same field: it writes back to `metadata.json` (so it's how you author the value in the first place), and it's captured by Glamourer design bindings, so a design can carry a different value than the mod ships with. The slider appears only on options rendering as **Skin** — a cloth or glow shell is on its own material and never reads it. Setting it to exactly `1` removes the key rather than writing `"SkinToneMask": 1`, so an untouched sidecar stays clean.

One thing worth knowing before you set `0` on a **diffuse-only** overlay: skin-tone masking is the only reason Proteus rewrites the normal map for such an overlay, so turning it off means the mod stops publishing a normal texture at all. That's the intended behavior (it's also what the global slider at `0` does), but it means `0` is slightly more than a color tweak. Overlays that ship their own `Normal` are unaffected.

### Index Textures

An index texture lets different regions of your overlay use different color table rows. This is how you support recolorable multi-region overlays (e.g. separate colors for bow, lace, and ribbon on the same stocking).

**Channel encoding:**

| Channel | Meaning |
|---------|---------|
| Red | Which color table row pair to use. Value ÷ 17 → row index 0–15. So red=0 → row 1, red=17 → row 2, …, red=255 → row 16. |
| Green | Blend between sub-row A and sub-row B within that pair. 255 = 100% A, 0 = 100% B, 128 = 50/50. |

Pixels not mapped to a row that exists in `ColorTableRows` use the default white pass-through.

Create your index texture as you would for any gear mod.

### Penumbra Option Groups

If your mod has multiple options (style variants, independent pieces, etc.) you need both a Penumbra group in `meta.json` **and** the matching `OptionGroups` in your Proteus `metadata.json`. The `PenumbraGroupName` must exactly match the group's `Name`.

**Penumbra `meta.json`** — since Penumbra's FileVersion 4 the whole mod layout lives in this one file at the mod root. Groups are entries in the `Groups` array (they used to be separate `group_001_style.json` files), and the default option is the `DefaultData` object (it used to be `default_mod.json`):
```json
{
  "FileVersion": 4,
  "Identifier": "a1b2c3d4-0000-4000-8000-000000000001",
  "Name": "My Stockings",
  "Author": "YourName",
  "Description": "",
  "Version": "1.0",
  "Website": "",
  "ModTags": [],
  "DefaultData": { "Files": {}, "FileSwaps": {}, "Manipulations": [] },
  "Groups": [
    {
      "Type": "Single",
      "Id": "a1b2c3d4-0000-4000-8000-000000000002",
      "Name": "Style",
      "Description": "",
      "Image": "",
      "Page": 0,
      "DefaultSettings": 0,
      "Options": [
        { "Id": "a1b2c3d4-0000-4000-8000-000000000003", "Name": "Roses",   "Description": "", "Files": {}, "FileSwaps": {}, "Manipulations": [] },
        { "Id": "a1b2c3d4-0000-4000-8000-000000000004", "Name": "Stripes", "Description": "", "Files": {}, "FileSwaps": {}, "Manipulations": [] }
      ]
    }
  ]
}
```

`"Type": "Single"` means only one option is active at a time. The options list just needs the names — all texture work is handled by Proteus, so `Files` stays empty. `Id` values are GUIDs Penumbra uses to keep a user's saved selections stable across mod updates; keep them the same when you re-export.

**Group order is the `Groups` array order.** Where two groups overlay the same skin, the one earlier in the array starts on top — it draws over the later one, and it hides the later one wherever it is opaque. (Before FileVersion 4 this was the `group_NNN` filename number — same meaning, new home. Proteus still reads the old layout for mods that were never migrated.)

This is only the **default**. The array order decides nothing once the wearer rearranges the option tabs in Proteus: their stack then sets both what draws on top and what covers what, and your `Groups` order is just the arrangement they start from. The full set of rules is in [How layers stack](#how-layers-stack).

**`DefaultSettings` is what a brand-new installer sees.** It is a bitmask over the option list — `0` selects nothing, `1` the first option, `2` the second, `3` the first two, and so on. Penumbra only consults it for a collection that has never seen your mod, so it does nothing for anyone who already has it installed, and it is not a substitute for telling people what to tick.

A `Multi` group shipping `0` means everyone who installs your pack sees a mod that is enabled and does nothing at all until they go and tick something — the single most common "it's installed but not appearing" report. Unless your groups are genuinely all-optional extras, give the primary group a bitmask that selects one sensible option so the pack looks like something the moment it goes on. If your garment's shape comes from a `Masks` group, that group is the one that needs a default: without a mask there is nothing to build the garment from, so a pack with fabric selected and no mask still renders nothing.

Proteus will now say so rather than leaving you to guess: a mod that is switched on and contributes nothing gets an amber `!` in the Mods tab naming the reason, and one line in the log — `… is enabled but contributes nothing: nothing is ticked in Penumbra …`.

The easiest way to get all this right is to build the group in Penumbra's own mod editor, or let the Substance Painter packager write it for you.

**Proteus metadata.json:**
```json
{
  "FormatVersion": 1,
  "Name": "My Stockings",
  "Author": "YourName",
  "OptionGroups": [
    {
      "PenumbraGroupName": "Style",
      "Options": [
        {
          "Name": "Roses",
          "Overlays": [
            {
              "MaterialGamePath": "chara/human/c0201/obj/body/b0001/material/v0001/mt_c0201b0001_bibo.mtrl",
              "Diffuse": "Roses/diffuse.png",
              "Normal":  "Roses/normal.png",
              "Index":   "Roses/index.png"
            }
          ],
          "ColorTableRows": [
            { "Row": 16, "SubRowA": { "Diffuse": "#FFFFFF" } }
          ]
        },
        {
          "Name": "Stripes",
          "Overlays": [
            {
              "MaterialGamePath": "chara/human/c0201/obj/body/b0001/material/v0001/mt_c0201b0001_bibo.mtrl",
              "Diffuse": "Stripes/diffuse.png"
            }
          ],
          "ColorTableRows": [
            { "Row": 16, "SubRowA": { "Diffuse": "#FFFFFF" } }
          ]
        }
      ]
    }
  ]
}
```

Each option can have its own `ColorTableRows`. If an option omits `ColorTableRows`, it inherits the top-level `ColorTableRows` if present.

#### Shipping presets — starter looks

A pack with a lot of groups is a blank page to whoever installs it. A **preset** is a named set of option
ticks, colours and layer settings that a wearer applies in one click, and you can ship as many as you like
in a top-level `Presets` array:

```json
{
  "FormatVersion": 1,
  "Name": "My Stockings",
  "Presets": [
    {
      "Name": "Sheer",
      "Description": "Barely-there, for a lighter skin tone.",
      "Options": {
        "Style": ["Roses"],
        "Welt":  ["None"]
      },
      "Colors": {
        "Options": {
          "Style": { "Roses": [ { "Row": 16, "SubRowA": { "Diffuse": "#F3E2DA", "Opacity": -45 } } ] }
        }
      }
    },
    {
      "Name": "Full coverage",
      "Options": { "Style": ["Roses"], "Welt": ["Wide"] }
    }
  ]
}
```

- `Options` maps a **Penumbra group name** to the option names ticked in it — the same names as in
  `meta.json`. A single-select group takes a one-element list.
- `Colors` and `Gear` take the same shapes the colour editor writes: `Top` for the mod-wide colorset,
  `Mask` for the Masks tab, and `Options[group][option]` for one option's. Every part is optional — a
  preset that only sets `Options` is perfectly good, and is the easiest kind to write by hand.
- `StackOrder` is optional and rarely worth setting; omit it and the wearer's own stacking stands.
- You don't need to write any of this by hand. Set the mod up the way you want it in game, press
  **+ Save…** in the Colors panel, then use the preset's **Export** button and paste the file's contents
  into your `Presets` array — dropping `Id`, which is per-machine.

Presets you ship are marked with a `*` and are **read-only** in the UI: editing one makes the wearer an
editable copy instead. That is deliberate, and it is what makes it safe for you to change or remove them
in an update — nothing anyone saved is ever silently rewritten.

Applying a preset does not touch your `metadata.json`. The option ticks go to Penumbra; the colours and
layer settings ride on top only while the preset is worn, so **No preset** always gets your own colours
back exactly as shipped.

#### Independent toggleable pieces

To let users enable pieces independently (e.g. top and bottom separately), use **two separate groups**, each with a `"None"` first option:

```json
"OptionGroups": [
  {
    "PenumbraGroupName": "Bra",
    "Options": [
      { "Name": "None", "Overlays": [] },
      { "Name": "Bra",  "Overlays": [ { ... } ] }
    ]
  },
  {
    "PenumbraGroupName": "Panties",
    "Options": [
      { "Name": "None",    "Overlays": [] },
      { "Name": "Panties", "Overlays": [ { ... } ] }
    ]
  }
]
```

Create a matching Penumbra group JSON for each group.

### How layers stack

Every selected option becomes a layer, and the layers are painted bottom to top. The wearer sees the stack as the row of option tabs in the Colors panel, **leftmost on top**.

#### What decides the order

From the strongest rule to the weakest:

1. **Between mods, Penumbra priority.** A higher-priority mod's layers go on top of a lower one's.
2. **Prints go above painted layers.** An option with any `Blend` row other than `Paint` sits above every painting option of the same mod, since its job is to colour what they painted.
3. **The wearer's tab order.** Dragging the tabs (or using the arrows) restacks the mod, and the order is saved in *their* Proteus settings — or on the design binding or preset they are wearing. It survives restarts and updates, but it is theirs: it is not part of your pack.
4. **Your group order.** The group earliest in `meta.json`'s `Groups` array goes on top.
5. **Your option order.** In a multi-select group, the option earliest in its `Options` list goes on top.
6. **Your overlay order.** Within one option, the overlay earliest in its `Overlays` list goes on top.

The `Masks` group is not a layer in this sense; it is applied to the whole mod, on top of everything.

To make a layer start on top for everyone — scales over a base skin, say — put its group first in `Groups`. The wearer can still restack it. A shipped preset can also carry a `StackOrder`, which applies while that preset is worn.

#### What covers what

Across mods, layers simply paint over one another. **Inside one mod, a layer also hides what is beneath it**, wherever it is opaque: a fully opaque bodysuit option erases the options under it rather than being blended with them, and a half-opaque one erases them by half. That is what lets a pack ship a base skin and a garment that replaces it.

Hiding is per channel. A layer hides only the channels it ships art in:

- a `Diffuse` hides diffuses beneath it,
- a `Normal` hides normals beneath it,
- a `Mask` hides masks beneath it.

So an opaque full-body diffuse in one group and a full-body normal in another both show: neither can hide the other's channel.

How much a layer covers comes from one silhouette, whichever channel it has first:

| The overlay has… | Its coverage is… |
|---|---|
| a `Diffuse` | the diffuse's alpha — for *every* channel it ships, including its normal |
| a `Normal` and no `Diffuse` | the normal's alpha |
| only a `Mask` | the mask's alpha |

The `Masks` group and the row `Opacity` are then applied to that silhouette, so a layer faded to half opacity also covers only half.

One exception, for relief: a normal-only layer in the default `Compound` mode adds its relief to what is beneath, and a flat texel adds nothing, so it hides the normals beneath it only **where it has relief** — near texels whose red and green are away from flat, within about 16 texels on a 4K sheet. The flat tops of scales and the gaps in lace still count as the pattern's own; a wide flat area does not. A `Replace` layer hides by its full coverage, because overwriting is what it is for.

Proteus says when a layer is hidden. Search `dalamud.log` for **`adds no relief`**; a layer that was hidden logs a line ending `its relief is fully covered by <option> above it in the stack`, naming the layer that hid it.

#### Different opacity for each texture of one option

`ColorTableRows` belong to the option, and an overlay's opacity scales everything that overlay ships. So one overlay with both a `Diffuse` and a `Normal` cannot be half-opaque in colour and fully opaque in relief.

Split it into two overlays in the same option, each with its own `Index` texture choosing a different row:

```json
{
  "Name": "Scales",
  "Overlays": [
    {
      "MaterialGamePath": "chara/human/c0201/obj/body/b0001/material/v0001/mt_c0201b0001_bibo.mtrl",
      "Diffuse": "Scales/diffuse.png",
      "Index":   "Scales/row1.png"
    },
    {
      "MaterialGamePath": "chara/human/c0201/obj/body/b0001/material/v0001/mt_c0201b0001_bibo.mtrl",
      "Normal":  "Scales/normal.png",
      "Index":   "Scales/row2.png"
    }
  ],
  "ColorTableRows": [
    { "Row": 1, "SubRowA": { "Diffuse": "#FFFFFF", "Opacity": -50 } },
    { "Row": 2, "SubRowA": { "Diffuse": "#FFFFFF" } }
  ]
}
```

- `row1.png` is solid red 0, green 255 (row 1, sub-row A); `row2.png` is solid red 17, green 255 (row 2, sub-row A). See [Index Textures](#index-textures).
- `Opacity` runs from −100 to 100 and `0` means unchanged, so `-50` halves the diffuse and row 2 leaves the normal at full strength.
- The two overlays do not hide each other, because they ship art in different channels. The normal-only one takes its coverage from its alpha, so leave it transparent wherever the scales are not.

If the two don't need to be one option, the simpler route is two options, each with its own `ColorTableRows`.

### Simple Unconditional Overlay

If your mod has no options at all, use the top-level `Overlays` field instead of `OptionGroups`. The overlays apply unconditionally whenever the mod is enabled.

### Masks

Masks let users **carve away** parts of your overlays so the skin underneath (or a lower-priority mod) shows through — for example, a bodysuit that can hide its sleeves, gloves, or a chest panel.

Masks are **convention-based** — there is nothing to add to `metadata.json`. You need two things:

1. A Penumbra **multi-select** group named exactly **`Masks`** (a `Groups` entry in `meta.json` with `"Type": "Multi"`).
2. A `Proteus/Masks/` subfolder containing one **grayscale PNG per option**, named to match the option exactly: option `Sleeves` → `Proteus/Masks/Sleeves.png`.

```
YourMod/
  meta.json                ← contains a Multi group named "Masks"
  Proteus/
    metadata.json
    Masks/
      Sleeves.png
      Chest.png
```

How a mask image is read — a mask sets the overlay's opacity **explicitly**, using two channels:

- **RGB (grayscale) = the target opacity.** Where the mask takes effect, the overlay's coverage is *set to* this value: black (0) → fully transparent (skin shows), white (255) → fully opaque, grays → that exact opacity. It's an explicit set, not a fade of the existing coverage — so a white patch can **add** opacity, forcing an opaque band even where the overlay was sheer.
- **Alpha = how strongly the target is applied.** White alpha (255) → fully apply the target opacity above; black alpha (0) → the mask does nothing there and the overlay keeps its own coverage; grays blend between the two. Think of alpha as "where this mask has any say at all," and RGB as "what opacity it forces there."

So to punch a clean hole, paint the hole region **alpha = white, RGB = black**; to force a patch fully opaque, paint it **alpha = white, RGB = white**; leave everywhere else **alpha = black**.

- **A mask only acts where the overlay is already visible.** The added opacity is gated by the overlay's own coverage: where the overlay is fully transparent (above where a stocking ends, or the holes of a fishnet) the mask has no effect — it can boost a sheer area to opaque, but it can never paint opacity onto bare skin. You don't need to carefully avoid those areas in your mask.
- A mask applies to **every overlay in the same mod** (all groups/options), at full UV resolution. Author your mask in the same UV space as your overlays.
- When a user selects **several masks at once**, masks **earlier in the group's `Options` list win** where they overlap — the top mask sets the opacity in its alpha region, and lower masks only show through where the higher one's alpha leaves room.

Because `Masks` is just a Penumbra group, the user's selection is saved and restored by Glamourer designs automatically, and toggling a mask re-composites immediately.

### Content Packs (packs that ship their own meshes)

Everything above describes an *overlay* pack: art Proteus composites onto the character's own geometry. A
**content pack** is the other kind — a normal Penumbra `.pmp` that ships its own `.mdl`, `.mtrl` and `.tex`
files. Proteus imports one through **Import → Browse for a mod pack**, and from then on the meshes of every
option the user has selected in Penumbra are appended onto their carrier accessory.

The reason to ship one this way is that Penumbra can only apply **one** file per game path. Two options in a
multi-select group that both redirect `chara/equipment/e0000/model/c0201e0000_top.mdl` can never both be
worn — the higher-priority one wins and the other silently does nothing. Appending removes that limit:
every selected option contributes its own meshes at once.

**What the import changes.** Your pack is copied into Penumbra's mod directory as an ordinary mod, with two
edits:

1. Every `.mdl` entry is removed from the manifest's `Files` maps. The files stay on disk — Proteus's
   sidecar names them instead — so Penumbra no longer publishes your models and cannot pick just one.
2. A `Proteus/metadata.json` sidecar is written, mirroring your groups and naming each option's model.

Your `.mtrl` and `.tex` redirects are left exactly as you wrote them, so your own colour/texture option
groups keep working untouched.

**The one rule: a mesh must name a material your pack ships.** Binding is by name and is never guessed —
Proteus takes the material name your model declares (`/mt_…​.mtrl`) and looks for a `.mtrl` your pack
redirects under that leaf name, anywhere in the pack (a shared material in an always-on group is the normal
arrangement). A mesh whose material you don't ship is listed in the Import tab and skipped, because the only
alternative would be binding it to whatever else is lying around — and a metal piercing bound to a skin
material renders as skin.

Meshes with **zero vertices** are ignored entirely, so the usual workflow — start from a stock model, empty
its vanilla meshes, add your own — needs no cleanup. Only meshes that actually draw need a binding.

**Choosing a shader.** The material is published verbatim (bar colour rows), under the carrier accessory's
own path, so whatever you authored is what renders. `character.shpk` with norm/mask/index samplers and a
colour set is the natural choice; a *skin* material will render as skin, which is almost never what a
separate mesh wants.

**Colour tables.** If your material carries a Dawntrail colour set, the user can edit its rows in Proteus's
Colors panel — one tab per selected option. Only the rows they actually change are written; everything else
stays exactly as you authored it.

**Budget.** Each distinct material an option contributes costs one of the ten material slots on the host
accessory, shared with any second-skin shells. Options that bind the same material and are left at the same
colours share a single slot.

**Sidecar shape**, written by the importer — worth knowing if you want to hand-tune it:

```jsonc
{
  "Name": "Neolithe Piercings",
  "ContentGroups": [
    {
      "PenumbraGroupName": "Top",          // must match the Penumbra group name exactly
      "Options": [
        {
          "Name": "Belly Button Heart",    // must match the Penumbra option name exactly
          "Pieces": [
            {
              "Model": "top/heart/chara/equipment/e0000/model/c0201e0000_top.mdl",
              "Materials": {
                // model material name -> the .mtrl backing it, both relative to the MOD ROOT
                "mt_c0201b0001_neolithe_piercings.mtrl": "common/1/mt_c0201b0001_neolithe_piercings.mtrl"
              },
              "Surface": "Body"            // Body (default), Face, Hair, Tail or Ear
            }
          ],
          "ColorTableRows": []             // optional, same shape as an overlay option's
        }
      ]
    }
  ]
}
```

`Surface` decides which space the piece is authored in, and therefore where it can ride. `Body` is cut in the
shared equipment space and is deformed onto the wearer exactly as a second skin is. `Face`, `Hair`, `Tail`
and `Ear` are authored at the character's own race and must **not** be deformed, so they can only ride a slot
Proteus can replace outright — a free ring, or the facewear slot. Add `"SurfaceId": "f0001"` for those.

### Gear shader upgrade (what it changes in a user's copy of your mod)

Users can turn on **Settings > Gear shaders > "Upgrade old gear to Dawntrail shaders"**. With it on, when they put on
gear your mod draws with the pre-Dawntrail `characterlegacy.shpk` shader, Proteus rewrites **their installed copy** of
your mod:

- Each worn old-shader gear `.mtrl` is rewritten in place to Dawntrail's `character.shpk`. Index/mask materials get the
  gear mode; old diffuse/specular materials (`_d`/`_n`/`_s`/`_id`) get the game's monster diffuse mode.
- For a diffuse/specular material, a Dawntrail mask derived from your `_s` is added under `Shader Upgrade/`, and a
  redirect for it is added inside the options (or default data) that already ship that material. No group is added,
  moved or reordered, and your `_s` is never changed.
- Every rewritten file is backed up first, in `Proteus/shaderupgrade-backup/`, and the changes are recorded in
  `Proteus/shaderupgrade.json`.

All of it lives inside the mod folder, so it travels with a Penumbra export. **If you wear your own source mods with
the setting on, your working copy is rewritten too** — leave the setting off while you work on a mod, or undo it before
you pack.

To put your files back, a user wears the pieces and presses **"Undo for what I'm wearing"** (those pieces are then
left alone until "Upgrade what I'm wearing now"). For a piece that can no longer be worn, copy each file from
`Proteus/shaderupgrade-backup/` back over the mod's own, delete `Shader Upgrade/`, `Proteus/shaderupgrade.json` and
the backup folder, then remove the redirects that pointed into `Shader Upgrade/` (Penumbra's Advanced Editing >
"Remove Missing Files" does it once the folder is gone). An update you ship later is never overwritten by an old backup: Proteus keeps the new file, and
upgrades it again only if it is still old-shader.

### Gear variants (what it changes in a user's copy of your mod)

**Settings > Gear variants > "Point every variant of worn gear at its mod's material"** is **on by default** (users can
turn it off). It is for a
mod that ships one variant's material folder (say `material/v0001/`) for an item: worn in a variant whose IMC entry
uses another folder, the game loads that folder's material onto your model — the game's own, or nothing for a
material name the game does not have, or a competing outfit's material for that folder. When a user puts on such a
piece, Proteus fixes **their installed copy** of your mod — like TexTools' metadata tab "Apply to All Variants", but
for the material only:

- Your material redirects are **copied** to the other variant folders the item's variants use: for each option (or
  default data, or combining container) that redirects `…/material/v0001/<name>`, the same option gains
  `…/material/v0002/<name>` (and so on) pointing at **the same file**. Every option keeps its own file, so a colour
  choice still works on every variant.
- **No IMC entry is written.** Each variant keeps its own visible parts, VFX and sound. Because the copies are plain
  redirects inside your mod, Penumbra resolves them at your mod's priority — the same ordering that decides your model.
  Where another outfit outranks yours, its model and material show; a copy can still serve a variant folder no higher
  mod covers.
- Nothing you set on purpose is overridden: a variant your own IMC data sends to another material folder is left
  alone, a key you already wrote is never replaced, and a mod that ships several variant folders is left as it is. No
  group is added, moved or reordered, and every other option and setting is left as it is.
- What was written is recorded in `Proteus/variantrepoint.json`. If that file is lost, the copies look like your own
  redirects and Proteus no longer touches them.

All of it lives inside the mod folder, so it travels with a Penumbra export. **Because the setting is on by default,
wearing your own source mods changes your working copy too** — turn it off while you work on a mod, or undo it before
you pack.

To take the copies out, a user wears the pieces and presses **"Undo for what I'm wearing"** (those pieces are then
left alone until "Repoint what I'm wearing now"). A copy someone repointed since is theirs and kept. When you ship an
update, Proteus notices that its copies are gone and the mod changed, and looks at the pieces afresh.

### Distributing Your Mod

Pack your mod folder as a `.zip` and rename the extension to `.pmp`. Penumbra imports `.pmp` files directly. Include everything in the mod root:

```
YourMod.pmp (rename from .zip)
  meta.json               ← including "Groups", if you have option groups
  Proteus/
    metadata.json
    OptionA/
      diffuse.png
      ...
```

### Sample Mods

The `samples/` directory in this repository contains two ready-to-study examples:

- **ExampleOverlayMod** — simple unconditional overlay with diffuse, normal, and mask.
- **MultiOptionOverlayMod** — single-select style picker plus an independently toggleable piece, demonstrating `OptionGroups`, per-option `ColorTableRows`, index textures, and the normal-only overlay pattern.

There is no sample content pack: one is just an ordinary Penumbra `.pmp` whose models name materials it also
ships. Any mesh mod that follows that rule imports as one.
